% porcentaje_100 = load('datos\100_por_ciento_2.mat');
% porcentaje_100 = porcentaje_100.data{1}.Values;
% porcentaje_90  = load('datos\90_por_ciento_2.mat');
% porcentaje_90  = porcentaje_90.data{1}.Values;
% porcentaje_80  = load('datos\80_por_ciento_3.mat');
% porcentaje_80  = porcentaje_80.data{1}.Values;
% porcentaje_70  = load('datos\70_por_ciento_3.mat');
% porcentaje_70  = porcentaje_70.data{1}.Values;
% porcentaje_60  = load('datos\60_por_ciento_3.mat');
% porcentaje_60  = porcentaje_60.data{1}.Values;
% porcentaje_50  = load('datos\50_por_ciento_3.mat');
% porcentaje_50  = porcentaje_50.data{1}.Values;
% porcentaje_40  = load('datos\40_por_ciento_2.mat');
% porcentaje_40  = porcentaje_40.data{1}.Values;
% porcentaje_30  = load('datos\30_por_ciento_2.mat');
% porcentaje_30  = porcentaje_30.data{1}.Values;
% porcentaje_20  = load('datos\20_por_ciento_2.mat');
% porcentaje_20  = porcentaje_20.data{1}.Values;
% porcentaje_10  = load('datos\10_por_ciento_2.mat');
% porcentaje_10  = porcentaje_10.data{1}.Values;
% 
% 
% datos_100   = porcentaje_100.Data;
% tiempos_100 = porcentaje_100.Time;
% datos_90    = porcentaje_90.Data;
% tiempos_90  = porcentaje_90.Time;
% datos_80    = porcentaje_80.Data;
% tiempos_80  = porcentaje_80.Time;
% datos_70    = porcentaje_70.Data;
% tiempos_70  = porcentaje_70.Time;
% datos_60    = porcentaje_60.Data;
% tiempos_60  = porcentaje_60.Time;
% datos_50    = porcentaje_50.Data;
% tiempos_50  = porcentaje_50.Time;
% datos_40    = porcentaje_40.Data;
% tiempos_40  = porcentaje_40.Time;
% datos_30    = porcentaje_30.Data;
% tiempos_30  = porcentaje_30.Time;
% datos_20    = porcentaje_20.Data;
% tiempos_20  = porcentaje_20.Time;
% datos_10    = porcentaje_10.Data;
% tiempos_10  = porcentaje_10.Time;
% 
% 
% coeficientes_100 = polyfit(tiempos_100, datos_100,1);
% coeficientes_90  = polyfit(tiempos_90, datos_90,1);
% coeficientes_80  = polyfit(tiempos_80, datos_80,1);
% coeficientes_70  = polyfit(tiempos_70, datos_70,1);
% coeficientes_60  = polyfit(tiempos_60, datos_60,1);
% coeficientes_50  = polyfit(tiempos_50, datos_50,1);
% coeficientes_40  = polyfit(tiempos_40, datos_40,1);
% coeficientes_30  = polyfit(tiempos_30, datos_30,1);
% coeficientes_20  = polyfit(tiempos_20, datos_20,1);
% coeficientes_10  = polyfit(tiempos_10, datos_10,1);
% 
% p_100 = -coeficientes_100(1)/coeficientes_100(2);
% p_90  = -coeficientes_90(1)/coeficientes_90(2);
% p_80  = -coeficientes_80(1)/coeficientes_80(2);
% p_70  = -coeficientes_70(1)/coeficientes_70(2);
% p_60  = -coeficientes_60(1)/coeficientes_60(2);
% p_50  = -coeficientes_50(1)/coeficientes_50(2);
% p_40  = -coeficientes_40(1)/coeficientes_40(2);
% p_30  = -coeficientes_30(1)/coeficientes_30(2);
% p_20  = -coeficientes_20(1)/coeficientes_20(2);
% p_10  = -coeficientes_10(1)/coeficientes_10(2);
% 
% p_vector = [p_10, p_20, p_30, p_40, p_50, p_60, p_70, p_80, p_90, p_100];
% potencias = (10:10:100);
% 
% k_100 = coeficientes_100(1)*p_100/(1*12);
% k_90  = coeficientes_90(1)*p_90/(0.9*12);
% k_80  = coeficientes_80(1)*p_80/(0.8*12);
% k_70  = coeficientes_70(1)*p_70/(0.7*12);
% k_60  = coeficientes_60(1)*p_60/(0.6*12);
% k_50  = coeficientes_50(1)*p_50/(0.5*12);
% k_40  = coeficientes_40(1)*p_40/(0.4*12);
% k_30  = coeficientes_30(1)*p_30/(0.3*12);
% k_20  = coeficientes_20(1)*p_20/(0.2*12);
% k_10  = coeficientes_10(1)*p_10/(0.1*12);
% 
% k_vector = [k_10, k_20, k_30, k_40, k_50, k_60, k_70, k_80, k_90, k_100];
% 
% 
% p_media = mean(p_vector(2:end));
% k_media = mean(k_vector(2:end));
% 
% 
% figure
% plot(potencias(2:end), p_vector(2:end), 'k*')
% ylabel("p")
% xlabel("Potencia del motor [%]")
% 
% figure
% plot(potencias(2:end), k_vector(2:end), 'r*')
% ylabel("k_e")
% xlabel("Potencia del motor [%]")

k_media = 6000
p_media = 60


%--------------------------------------------------------------------------

A = [0, 1; 0, -p_media];
B = [0; k_media];
C = [1, 0];
D = 0;

motors = ss(A, B, C, D);

AI = [A [0;0]; C 0];
BI = [B; 0];
P = [-p_media/2, -p_media/2, -1.5*p_media];


k_estimador_completo = acker(AI, BI, P);

PL = [-1.2*p_media, -1.2*p_media];

L_estimador = (acker(A', C', PL))';


k_i = k_estimador_completo(end);

k_estimador = k_estimador_completo(1:2);



%------------------------------------
% sistema completo

Aam = [A, -B*k_estimador, -B*k_i; C, 0, 0, 0; L_estimador*C, A-B*k_estimador-L_estimador*C,-B*k_i];

F = inv(C*inv(B*k_estimador(1:2)-A)*B);

Bam = [B*F; -1; B*F];
Cam = [C 0 0 0];


sysobsF = ss(Aam, Bam, Cam, D);


T = 1e-4;


motorz = c2d(motors, T);

Fz = motorz.A;
Gz = motorz.B;
Cz = motorz.C;


FzI = [Fz, [0;0]; T*Cz, 1];
GzI = [Gz; 0];
kz = acker(FzI, GzI, [exp(P(1)*T), exp(P(2)*T), exp(P(3)*T)]);
L_z = acker(Fz', Cz', [exp(PL(1)*T), exp(PL(2)*T)])';


k_iz = kz(end);
k_z = kz(1:2);



Fam = [Fz, -Gz*k_iz, -Gz*k_z; T*Cz, 1, 0, 0; L_z*Cz, - Gz*k_iz, Fz-Gz*k_z-L_z*Cz];

f = -inv(Cz*inv(eye(size(Fz))-(Fz-Gz*k_z))*Gz)*C*inv(A-B*k_estimador)*B*F;


Gam = [Gz*f; -T; Gz*f];
Camz = [Cz 0 0 0];
f2 = inv(Cz*inv(eye(size(Fz))-(Fz-Gz*k_z))*Gz);




k_awp = 0.1;

