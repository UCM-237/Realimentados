function [y,t] = euler(fun, ya, a, b, h)
if a>=b
    y = 'el intervalo debe ser creciente'
return
end


paso = 1;
y(paso) = ya ;
t(paso) = a;
while t(paso)<b
    t(paso+1) = t(paso)+h;
    y(paso+1) = y(paso)+h*fun(y(paso));
    paso = paso+1;
end
%plot(t, y)
end