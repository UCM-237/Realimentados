/*
 * MotorLazoAbierto.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "MotorLazoAbierto".
 *
 * Model version              : 1.8
 * Simulink Coder version : 9.1 (R2019a) 23-Nov-2018
 * C source code generated on : Fri Sep 27 14:40:09 2019
 *
 * Target selection: ert.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "MotorLazoAbierto.h"
#include "MotorLazoAbierto_private.h"

/* Block signals (default storage) */
B_MotorLazoAbierto_T MotorLazoAbierto_B;

/* Block states (default storage) */
DW_MotorLazoAbierto_T MotorLazoAbierto_DW;

/* Previous zero-crossings (trigger) states */
PrevZCX_MotorLazoAbierto_T MotorLazoAbierto_PrevZCX;

/* Real-time model */
RT_MODEL_MotorLazoAbierto_T MotorLazoAbierto_M_;
RT_MODEL_MotorLazoAbierto_T *const MotorLazoAbierto_M = &MotorLazoAbierto_M_;

/* Forward declaration for local functions */
static void MotorLa_SystemCore_release_i25o(const
  mbed_DigitalRead_MotorLazoAbi_T *obj);
static void MotorLaz_SystemCore_delete_i25o(const
  mbed_DigitalRead_MotorLazoAbi_T *obj);
static void matlabCodegenHandle_matlab_i25o(mbed_DigitalRead_MotorLazoAbi_T *obj);
static void MotorLazo_SystemCore_release_i2(const
  mbed_PWMOutput_MotorLazoAbier_T *obj);
static void MotorLazoA_SystemCore_delete_i2(const
  mbed_PWMOutput_MotorLazoAbier_T *obj);
static void matlabCodegenHandle_matlabCo_i2(mbed_PWMOutput_MotorLazoAbier_T *obj);
static void MotorLazoAbi_SystemCore_release(const
  mbed_DigitalWrite_MotorLazoAb_T *obj);
static void MotorLazoAbie_SystemCore_delete(const
  mbed_DigitalWrite_MotorLazoAb_T *obj);
static void matlabCodegenHandle_matlabCodeg(mbed_DigitalWrite_MotorLazoAb_T *obj);
static void rate_monotonic_scheduler(void);

/*
 * Set which subrates need to run this base step (base rate always runs).
 * This function must be called prior to calling the model step function
 * in order to "remember" which rates need to run this base step.  The
 * buffering of events allows for overlapping preemption.
 */
void MotorLazoAbierto_SetEventsForThisBaseStep(boolean_T *eventFlags)
{
  /* Task runs when its counter is zero, computed via rtmStepTask macro */
  eventFlags[2] = ((boolean_T)rtmStepTask(MotorLazoAbierto_M, 2));
}

/*
 *   This function updates active task flag for each subrate
 * and rate transition flags for tasks that exchange data.
 * The function assumes rate-monotonic multitasking scheduler.
 * The function must be called at model base rate so that
 * the generated code self-manages all its subrates and rate
 * transition flags.
 */
static void rate_monotonic_scheduler(void)
{
  /* To ensure a deterministic data transfer between two rates,
   * data is transferred at the priority of a fast task and the frequency
   * of the slow task.  The following flags indicate when the data transfer
   * happens.  That is, a rate interaction flag is set true when both rates
   * will run, and false otherwise.
   */

  /* tid 1 shares data with slower tid rate: 2 */
  if (MotorLazoAbierto_M->Timing.TaskCounters.TID[1] == 0) {
    MotorLazoAbierto_M->Timing.RateInteraction.TID1_2 =
      (MotorLazoAbierto_M->Timing.TaskCounters.TID[2] == 0);
  }

  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (MotorLazoAbierto_M->Timing.TaskCounters.TID[2])++;
  if ((MotorLazoAbierto_M->Timing.TaskCounters.TID[2]) > 99) {/* Sample time: [0.01s, 0.0s] */
    MotorLazoAbierto_M->Timing.TaskCounters.TID[2] = 0;
  }
}

static void MotorLa_SystemCore_release_i25o(const
  mbed_DigitalRead_MotorLazoAbi_T *obj)
{
  if ((obj->isInitialized == 1) && obj->isSetupComplete) {
    MW_digitalIO_close(obj->MW_DIGITALIO_HANDLE);
  }
}

static void MotorLaz_SystemCore_delete_i25o(const
  mbed_DigitalRead_MotorLazoAbi_T *obj)
{
  MotorLa_SystemCore_release_i25o(obj);
}

static void matlabCodegenHandle_matlab_i25o(mbed_DigitalRead_MotorLazoAbi_T *obj)
{
  if (!obj->matlabCodegenIsDeleted) {
    obj->matlabCodegenIsDeleted = true;
    MotorLaz_SystemCore_delete_i25o(obj);
  }
}

static void MotorLazo_SystemCore_release_i2(const
  mbed_PWMOutput_MotorLazoAbier_T *obj)
{
  if ((obj->isInitialized == 1) && obj->isSetupComplete) {
    MW_PWM_Stop(obj->MW_PWM_HANDLE);
    MW_PWM_Close(obj->MW_PWM_HANDLE);
  }
}

static void MotorLazoA_SystemCore_delete_i2(const
  mbed_PWMOutput_MotorLazoAbier_T *obj)
{
  MotorLazo_SystemCore_release_i2(obj);
}

static void matlabCodegenHandle_matlabCo_i2(mbed_PWMOutput_MotorLazoAbier_T *obj)
{
  if (!obj->matlabCodegenIsDeleted) {
    obj->matlabCodegenIsDeleted = true;
    MotorLazoA_SystemCore_delete_i2(obj);
  }
}

static void MotorLazoAbi_SystemCore_release(const
  mbed_DigitalWrite_MotorLazoAb_T *obj)
{
  if ((obj->isInitialized == 1) && obj->isSetupComplete) {
    MW_digitalIO_close(obj->MW_DIGITALIO_HANDLE);
  }
}

static void MotorLazoAbie_SystemCore_delete(const
  mbed_DigitalWrite_MotorLazoAb_T *obj)
{
  MotorLazoAbi_SystemCore_release(obj);
}

static void matlabCodegenHandle_matlabCodeg(mbed_DigitalWrite_MotorLazoAb_T *obj)
{
  if (!obj->matlabCodegenIsDeleted) {
    obj->matlabCodegenIsDeleted = true;
    MotorLazoAbie_SystemCore_delete(obj);
  }
}

/* Model step function for TID0 */
void MotorLazoAbierto_step0(void)      /* Sample time: [0.0s, 0.0s] */
{
  /* local block i/o variables */
  real_T rtb_Sum1;
  real_T rtb_Step;
  real_T rtb_DirectLookupTablenD;
  ZCEventType zcEvent;

  {                                    /* Sample time: [0.0s, 0.0s] */
    rate_monotonic_scheduler();
  }

  /* Reset subsysRan breadcrumbs */
  srClearBC(MotorLazoAbierto_DW.TriggeredSubsystem_SubsysRanBC);

  /* MATLABSystem: '<S1>/Hall 1' */
  if (MotorLazoAbierto_DW.obj.SampleTime != MotorLazoAbierto_P.Hall1_SampleTime)
  {
    MotorLazoAbierto_DW.obj.SampleTime = MotorLazoAbierto_P.Hall1_SampleTime;
  }

  MotorLazoAbierto_B.Hall1 = MW_digitalIO_read
    (MotorLazoAbierto_DW.obj.MW_DIGITALIO_HANDLE);

  /* End of MATLABSystem: '<S1>/Hall 1' */

  /* MATLABSystem: '<S1>/Hall 2' */
  if (MotorLazoAbierto_DW.obj_i.SampleTime !=
      MotorLazoAbierto_P.Hall2_SampleTime) {
    MotorLazoAbierto_DW.obj_i.SampleTime = MotorLazoAbierto_P.Hall2_SampleTime;
  }

  MotorLazoAbierto_B.Hall2 = MW_digitalIO_read
    (MotorLazoAbierto_DW.obj_i.MW_DIGITALIO_HANDLE);

  /* End of MATLABSystem: '<S1>/Hall 2' */

  /* LookupNDDirect: '<S2>/Direct Lookup Table (n-D)' incorporates:
   *  Gain: '<S2>/Gain'
   *  Gain: '<S2>/Gain1'
   *  Gain: '<S2>/Gain2'
   *  Gain: '<S2>/Gain3'
   *  Sum: '<S2>/Sum'
   *  UnitDelay: '<S2>/Unit Delay'
   *  UnitDelay: '<S2>/Unit Delay1'
   *
   * About '<S2>/Direct Lookup Table (n-D)':
   *  1-dimensional Direct Look-Up returning a Scalar,
   */
  rtb_Step = (((real_T)(MotorLazoAbierto_DW.UnitDelay_DSTATE ? (int32_T)
                        MotorLazoAbierto_P.Gain3_Gain : 0) * 0.0625 + (real_T)
               (MotorLazoAbierto_B.Hall1 ? (int32_T)
                MotorLazoAbierto_P.Gain2_Gain : 0) * 0.03125) + (real_T)
              (MotorLazoAbierto_DW.UnitDelay1_DSTATE ? (int32_T)
               MotorLazoAbierto_P.Gain1_Gain : 0) * 0.015625) + (real_T)
    (MotorLazoAbierto_B.Hall2 ? (int32_T)MotorLazoAbierto_P.Gain_Gain : 0) *
    0.0078125;
  if (rtb_Step > 15.0) {
    rtb_Step = 15.0;
  }

  rtb_DirectLookupTablenD = MotorLazoAbierto_P.DirectLookupTablenD_table
    [(int32_T)rtb_Step];

  /* End of LookupNDDirect: '<S2>/Direct Lookup Table (n-D)' */

  /* UnitDelay: '<S2>/Posicion (deg)' */
  MotorLazoAbierto_B.Posiciondeg = MotorLazoAbierto_DW.Posiciondeg_DSTATE;

  /* Sum: '<S2>/Sum1' */
  rtb_Sum1 = rtb_DirectLookupTablenD + MotorLazoAbierto_B.Posiciondeg;

  /* ZeroOrderHold: '<S2>/Zero-Order Hold' */
  if (MotorLazoAbierto_M->Timing.RateInteraction.TID1_2) {
    MotorLazoAbierto_B.ZeroOrderHold = MotorLazoAbierto_B.Posiciondeg;
  }

  /* End of ZeroOrderHold: '<S2>/Zero-Order Hold' */
  /* Clock: '<S2>/Clock' */
  MotorLazoAbierto_B.Clock = MotorLazoAbierto_M->Timing.t[0];

  /* Outputs for Triggered SubSystem: '<S2>/Triggered Subsystem' incorporates:
   *  TriggerPort: '<S3>/Trigger'
   */
  /* Abs: '<S2>/Abs1' */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                     &MotorLazoAbierto_PrevZCX.TriggeredSubsystem_Trig_ZCE,
                     (fabs(rtb_DirectLookupTablenD)));
  if (zcEvent != NO_ZCEVENT) {
    /* Inport: '<S3>/In1' */
    MotorLazoAbierto_B.In1 = MotorLazoAbierto_B.Clock;

    /* Sum: '<S3>/Sum' incorporates:
     *  Memory: '<S3>/Memory'
     */
    rtb_Step = MotorLazoAbierto_B.In1 - MotorLazoAbierto_DW.Memory_PreviousInput;

    /* Product: '<S3>/Product2' incorporates:
     *  Constant: '<S5>/Constant'
     *  Memory: '<S3>/Memory1'
     *  Product: '<S3>/Product1'
     *  RelationalOperator: '<S5>/Compare'
     */
    MotorLazoAbierto_B.Product2 = (real_T)(rtb_DirectLookupTablenD *
      MotorLazoAbierto_DW.Memory1_PreviousInput >
      MotorLazoAbierto_P.Constant_Value) * rtb_Step;

    /* Product: '<S3>/Product' */
    MotorLazoAbierto_B.Product = rtb_Step * rtb_DirectLookupTablenD;

    /* Update for Memory: '<S3>/Memory1' */
    MotorLazoAbierto_DW.Memory1_PreviousInput = rtb_DirectLookupTablenD;

    /* Update for Memory: '<S3>/Memory' */
    MotorLazoAbierto_DW.Memory_PreviousInput = MotorLazoAbierto_B.In1;
    MotorLazoAbierto_DW.TriggeredSubsystem_SubsysRanBC = 4;
  }

  /* End of Outputs for SubSystem: '<S2>/Triggered Subsystem' */

  /* Signum: '<S2>/Sign1' */
  if (MotorLazoAbierto_B.Product < 0.0) {
    MotorLazoAbierto_B.Sign1 = -1.0;
  } else if (MotorLazoAbierto_B.Product > 0.0) {
    MotorLazoAbierto_B.Sign1 = 1.0;
  } else if (MotorLazoAbierto_B.Product == 0.0) {
    MotorLazoAbierto_B.Sign1 = 0.0;
  } else {
    MotorLazoAbierto_B.Sign1 = (rtNaN);
  }

  /* End of Signum: '<S2>/Sign1' */

  /* Switch: '<S2>/Switch1' incorporates:
   *  Constant: '<S2>/Constant2'
   *  Math: '<S2>/pul//s'
   *
   * About '<S2>/pul//s':
   *  Operator: reciprocal
   */
  if (MotorLazoAbierto_B.Product2 > MotorLazoAbierto_P.Switch1_Threshold) {
    /* Product: '<S2>/Product' incorporates:
     *  Sum: '<S2>/Sum2'
     */
    rtb_Step = (MotorLazoAbierto_B.Clock - MotorLazoAbierto_B.In1) *
      MotorLazoAbierto_B.Sign1;

    /* Switch: '<S2>/Switch' incorporates:
     *  Abs: '<S2>/Abs2'
     *  RelationalOperator: '<S2>/Relational Operator'
     */
    if (fabs(rtb_Step) < MotorLazoAbierto_B.Product2) {
      rtb_Step = MotorLazoAbierto_B.Product;
    }

    /* End of Switch: '<S2>/Switch' */
    MotorLazoAbierto_B.Switch1 = 1.0 / rtb_Step;
  } else {
    MotorLazoAbierto_B.Switch1 = MotorLazoAbierto_P.Constant2_Value;
  }

  /* End of Switch: '<S2>/Switch1' */
  /* Step: '<Root>/Step' */
  if ((((MotorLazoAbierto_M->Timing.clockTick1+
         MotorLazoAbierto_M->Timing.clockTickH1* 4294967296.0)) * 0.0001) <
      MotorLazoAbierto_P.Step_Time) {
    rtb_Step = MotorLazoAbierto_P.Step_Y0;
  } else {
    rtb_Step = MotorLazoAbierto_P.Step_YFinal;
  }

  /* End of Step: '<Root>/Step' */

  /* ManualSwitch: '<S1>/Manual Switch1' incorporates:
   *  Constant: '<S1>/Constant2'
   */
  if (MotorLazoAbierto_P.ManualSwitch1_CurrentSetting == 1) {
    rtb_DirectLookupTablenD = MotorLazoAbierto_P.Constant2_Value_i;
  } else {
    rtb_DirectLookupTablenD = rtb_Step;
  }

  /* End of ManualSwitch: '<S1>/Manual Switch1' */

  /* MATLABSystem: '<S1>/PWM Output' */
  MW_PWM_SetDutyCycle(MotorLazoAbierto_DW.obj_b.MW_PWM_HANDLE,
                      rtb_DirectLookupTablenD);

  /* ManualSwitch: '<S1>/Manual Switch' incorporates:
   *  Constant: '<S1>/Constant2'
   */
  if (MotorLazoAbierto_P.ManualSwitch_CurrentSetting != 1) {
    rtb_Step = MotorLazoAbierto_P.Constant2_Value_i;
  }

  /* End of ManualSwitch: '<S1>/Manual Switch' */

  /* MATLABSystem: '<S1>/PWM Output1' */
  MW_PWM_SetDutyCycle(MotorLazoAbierto_DW.obj_n.MW_PWM_HANDLE, rtb_Step);

  /* MATLABSystem: '<S1>/Digital Write' incorporates:
   *  Constant: '<S1>/Constant'
   */
  MW_digitalIO_write(MotorLazoAbierto_DW.obj_p.MW_DIGITALIO_HANDLE,
                     MotorLazoAbierto_P.Constant_Value_m != 0.0);

  /* MATLABSystem: '<S1>/Digital Write2' incorporates:
   *  Constant: '<S1>/Constant1'
   */
  MW_digitalIO_write(MotorLazoAbierto_DW.obj_m.MW_DIGITALIO_HANDLE,
                     MotorLazoAbierto_P.Constant1_Value != 0.0);

  /* Update for UnitDelay: '<S2>/Unit Delay' */
  MotorLazoAbierto_DW.UnitDelay_DSTATE = MotorLazoAbierto_B.Hall1;

  /* Update for UnitDelay: '<S2>/Unit Delay1' */
  MotorLazoAbierto_DW.UnitDelay1_DSTATE = MotorLazoAbierto_B.Hall2;

  /* Update for UnitDelay: '<S2>/Posicion (deg)' */
  MotorLazoAbierto_DW.Posiciondeg_DSTATE = rtb_Sum1;

  /* External mode */
  rtExtModeUploadCheckTrigger(3);
  rtExtModeUpload(1, (real_T)MotorLazoAbierto_M->Timing.t[0]);

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.0s, 0.0s] */
    if ((rtmGetTFinal(MotorLazoAbierto_M)!=-1) &&
        !((rtmGetTFinal(MotorLazoAbierto_M)-MotorLazoAbierto_M->Timing.t[0]) >
          MotorLazoAbierto_M->Timing.t[0] * (DBL_EPSILON))) {
      rtmSetErrorStatus(MotorLazoAbierto_M, "Simulation finished");
    }

    if (rtmGetStopRequested(MotorLazoAbierto_M)) {
      rtmSetErrorStatus(MotorLazoAbierto_M, "Simulation finished");
    }
  }

  /* Update absolute time */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++MotorLazoAbierto_M->Timing.clockTick0)) {
    ++MotorLazoAbierto_M->Timing.clockTickH0;
  }

  MotorLazoAbierto_M->Timing.t[0] = MotorLazoAbierto_M->Timing.clockTick0 *
    MotorLazoAbierto_M->Timing.stepSize0 +
    MotorLazoAbierto_M->Timing.clockTickH0 *
    MotorLazoAbierto_M->Timing.stepSize0 * 4294967296.0;

  /* Update absolute time */
  /* The "clockTick1" counts the number of times the code of this task has
   * been executed. The resolution of this integer timer is 0.0001, which is the step size
   * of the task. Size of "clockTick1" ensures timer will not overflow during the
   * application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick1 and the high bits
   * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
   */
  MotorLazoAbierto_M->Timing.clockTick1++;
  if (!MotorLazoAbierto_M->Timing.clockTick1) {
    MotorLazoAbierto_M->Timing.clockTickH1++;
  }
}

/* Model step function for TID2 */
void MotorLazoAbierto_step2(void)      /* Sample time: [0.01s, 0.0s] */
{
  /* local block i/o variables */
  real_T rtb_TSamp;

  /* SampleTimeMath: '<S4>/TSamp'
   *
   * About '<S4>/TSamp':
   *  y = u * K where K = 1 / ( w * Ts )
   */
  rtb_TSamp = MotorLazoAbierto_B.ZeroOrderHold * MotorLazoAbierto_P.TSamp_WtEt;

  /* Sum: '<S4>/Diff' incorporates:
   *  UnitDelay: '<S4>/UD'
   */
  MotorLazoAbierto_B.Diff = rtb_TSamp - MotorLazoAbierto_DW.UD_DSTATE;

  /* Update for UnitDelay: '<S4>/UD' */
  MotorLazoAbierto_DW.UD_DSTATE = rtb_TSamp;
  rtExtModeUpload(2, (real_T)(((MotorLazoAbierto_M->Timing.clockTick2+
    MotorLazoAbierto_M->Timing.clockTickH2* 4294967296.0)) * 0.01));

  /* Update absolute time */
  /* The "clockTick2" counts the number of times the code of this task has
   * been executed. The resolution of this integer timer is 0.01, which is the step size
   * of the task. Size of "clockTick2" ensures timer will not overflow during the
   * application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick2 and the high bits
   * Timing.clockTickH2. When the low bit overflows to 0, the high bits increment.
   */
  MotorLazoAbierto_M->Timing.clockTick2++;
  if (!MotorLazoAbierto_M->Timing.clockTick2) {
    MotorLazoAbierto_M->Timing.clockTickH2++;
  }
}

/* Model initialize function */
void MotorLazoAbierto_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)MotorLazoAbierto_M, 0,
                sizeof(RT_MODEL_MotorLazoAbierto_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&MotorLazoAbierto_M->solverInfo,
                          &MotorLazoAbierto_M->Timing.simTimeStep);
    rtsiSetTPtr(&MotorLazoAbierto_M->solverInfo, &rtmGetTPtr(MotorLazoAbierto_M));
    rtsiSetStepSizePtr(&MotorLazoAbierto_M->solverInfo,
                       &MotorLazoAbierto_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&MotorLazoAbierto_M->solverInfo, (&rtmGetErrorStatus
      (MotorLazoAbierto_M)));
    rtsiSetRTModelPtr(&MotorLazoAbierto_M->solverInfo, MotorLazoAbierto_M);
  }

  rtsiSetSimTimeStep(&MotorLazoAbierto_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetSolverName(&MotorLazoAbierto_M->solverInfo,"FixedStepDiscrete");
  rtmSetTPtr(MotorLazoAbierto_M, &MotorLazoAbierto_M->Timing.tArray[0]);
  rtmSetTFinal(MotorLazoAbierto_M, 40.0);
  MotorLazoAbierto_M->Timing.stepSize0 = 0.0001;

  /* External mode info */
  MotorLazoAbierto_M->Sizes.checksums[0] = (67521342U);
  MotorLazoAbierto_M->Sizes.checksums[1] = (901614307U);
  MotorLazoAbierto_M->Sizes.checksums[2] = (249747328U);
  MotorLazoAbierto_M->Sizes.checksums[3] = (2773328400U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[9];
    MotorLazoAbierto_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = &rtAlwaysEnabled;
    systemRan[3] = &rtAlwaysEnabled;
    systemRan[4] = &rtAlwaysEnabled;
    systemRan[5] = &rtAlwaysEnabled;
    systemRan[6] = &rtAlwaysEnabled;
    systemRan[7] = &rtAlwaysEnabled;
    systemRan[8] = (sysRanDType *)
      &MotorLazoAbierto_DW.TriggeredSubsystem_SubsysRanBC;
    rteiSetModelMappingInfoPtr(MotorLazoAbierto_M->extModeInfo,
      &MotorLazoAbierto_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(MotorLazoAbierto_M->extModeInfo,
                        MotorLazoAbierto_M->Sizes.checksums);
    rteiSetTPtr(MotorLazoAbierto_M->extModeInfo, rtmGetTPtr(MotorLazoAbierto_M));
  }

  /* block I/O */
  (void) memset(((void *) &MotorLazoAbierto_B), 0,
                sizeof(B_MotorLazoAbierto_T));

  /* states (dwork) */
  (void) memset((void *)&MotorLazoAbierto_DW, 0,
                sizeof(DW_MotorLazoAbierto_T));

  {
    mbed_DigitalRead_MotorLazoAbi_T *obj;
    uint32_T pinname;
    mbed_PWMOutput_MotorLazoAbier_T *obj_0;
    mbed_DigitalWrite_MotorLazoAb_T *obj_1;

    /* Start for MATLABSystem: '<S1>/Hall 1' */
    MotorLazoAbierto_DW.obj.matlabCodegenIsDeleted = true;
    MotorLazoAbierto_DW.obj.isInitialized = 0;
    MotorLazoAbierto_DW.obj.SampleTime = -1.0;
    MotorLazoAbierto_DW.obj.matlabCodegenIsDeleted = false;
    MotorLazoAbierto_DW.objisempty = true;
    MotorLazoAbierto_DW.obj.SampleTime = MotorLazoAbierto_P.Hall1_SampleTime;
    obj = &MotorLazoAbierto_DW.obj;
    MotorLazoAbierto_DW.obj.isSetupComplete = false;
    MotorLazoAbierto_DW.obj.isInitialized = 1;
    pinname = D13;
    obj->MW_DIGITALIO_HANDLE = MW_digitalIO_open(pinname, 0);
    MotorLazoAbierto_DW.obj.isSetupComplete = true;

    /* Start for MATLABSystem: '<S1>/Hall 2' */
    MotorLazoAbierto_DW.obj_i.matlabCodegenIsDeleted = true;
    MotorLazoAbierto_DW.obj_i.isInitialized = 0;
    MotorLazoAbierto_DW.obj_i.SampleTime = -1.0;
    MotorLazoAbierto_DW.obj_i.matlabCodegenIsDeleted = false;
    MotorLazoAbierto_DW.objisempty_h = true;
    MotorLazoAbierto_DW.obj_i.SampleTime = MotorLazoAbierto_P.Hall2_SampleTime;
    obj = &MotorLazoAbierto_DW.obj_i;
    MotorLazoAbierto_DW.obj_i.isSetupComplete = false;
    MotorLazoAbierto_DW.obj_i.isInitialized = 1;
    pinname = D12;
    obj->MW_DIGITALIO_HANDLE = MW_digitalIO_open(pinname, 0);
    MotorLazoAbierto_DW.obj_i.isSetupComplete = true;

    /* Start for MATLABSystem: '<S1>/PWM Output' */
    MotorLazoAbierto_DW.obj_b.matlabCodegenIsDeleted = true;
    MotorLazoAbierto_DW.obj_b.isInitialized = 0;
    MotorLazoAbierto_DW.obj_b.matlabCodegenIsDeleted = false;
    MotorLazoAbierto_DW.objisempty_hs = true;
    obj_0 = &MotorLazoAbierto_DW.obj_b;
    MotorLazoAbierto_DW.obj_b.isSetupComplete = false;
    MotorLazoAbierto_DW.obj_b.isInitialized = 1;
    pinname = D5;
    obj_0->MW_PWM_HANDLE = MW_PWM_Open(pinname, 5000.0, 50.0);
    MW_PWM_Start(MotorLazoAbierto_DW.obj_b.MW_PWM_HANDLE);
    MotorLazoAbierto_DW.obj_b.isSetupComplete = true;

    /* Start for MATLABSystem: '<S1>/PWM Output1' */
    MotorLazoAbierto_DW.obj_n.matlabCodegenIsDeleted = true;
    MotorLazoAbierto_DW.obj_n.isInitialized = 0;
    MotorLazoAbierto_DW.obj_n.matlabCodegenIsDeleted = false;
    MotorLazoAbierto_DW.objisempty_o = true;
    obj_0 = &MotorLazoAbierto_DW.obj_n;
    MotorLazoAbierto_DW.obj_n.isSetupComplete = false;
    MotorLazoAbierto_DW.obj_n.isInitialized = 1;
    pinname = D4;
    obj_0->MW_PWM_HANDLE = MW_PWM_Open(pinname, 5000.0, 50.0);
    MW_PWM_Start(MotorLazoAbierto_DW.obj_n.MW_PWM_HANDLE);
    MotorLazoAbierto_DW.obj_n.isSetupComplete = true;

    /* Start for MATLABSystem: '<S1>/Digital Write' */
    MotorLazoAbierto_DW.obj_p.matlabCodegenIsDeleted = true;
    MotorLazoAbierto_DW.obj_p.isInitialized = 0;
    MotorLazoAbierto_DW.obj_p.matlabCodegenIsDeleted = false;
    MotorLazoAbierto_DW.objisempty_k = true;
    obj_1 = &MotorLazoAbierto_DW.obj_p;
    MotorLazoAbierto_DW.obj_p.isSetupComplete = false;
    MotorLazoAbierto_DW.obj_p.isInitialized = 1;
    pinname = D2;
    obj_1->MW_DIGITALIO_HANDLE = MW_digitalIO_open(pinname, 1);
    MotorLazoAbierto_DW.obj_p.isSetupComplete = true;

    /* Start for MATLABSystem: '<S1>/Digital Write2' */
    MotorLazoAbierto_DW.obj_m.matlabCodegenIsDeleted = true;
    MotorLazoAbierto_DW.obj_m.isInitialized = 0;
    MotorLazoAbierto_DW.obj_m.matlabCodegenIsDeleted = false;
    MotorLazoAbierto_DW.objisempty_j = true;
    obj_1 = &MotorLazoAbierto_DW.obj_m;
    MotorLazoAbierto_DW.obj_m.isSetupComplete = false;
    MotorLazoAbierto_DW.obj_m.isInitialized = 1;
    pinname = A4;
    obj_1->MW_DIGITALIO_HANDLE = MW_digitalIO_open(pinname, 1);
    MotorLazoAbierto_DW.obj_m.isSetupComplete = true;
  }

  MotorLazoAbierto_PrevZCX.TriggeredSubsystem_Trig_ZCE = UNINITIALIZED_ZCSIG;

  /* InitializeConditions for UnitDelay: '<S2>/Unit Delay' */
  MotorLazoAbierto_DW.UnitDelay_DSTATE =
    MotorLazoAbierto_P.UnitDelay_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S2>/Unit Delay1' */
  MotorLazoAbierto_DW.UnitDelay1_DSTATE =
    MotorLazoAbierto_P.UnitDelay1_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S2>/Posicion (deg)' */
  MotorLazoAbierto_DW.Posiciondeg_DSTATE =
    MotorLazoAbierto_P.Posiciondeg_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S4>/UD' */
  MotorLazoAbierto_DW.UD_DSTATE =
    MotorLazoAbierto_P.Velocidaddegs_ICPrevScaledInput;

  /* SystemInitialize for Triggered SubSystem: '<S2>/Triggered Subsystem' */
  /* InitializeConditions for Memory: '<S3>/Memory1' */
  MotorLazoAbierto_DW.Memory1_PreviousInput =
    MotorLazoAbierto_P.Memory1_InitialCondition;

  /* InitializeConditions for Memory: '<S3>/Memory' */
  MotorLazoAbierto_DW.Memory_PreviousInput =
    MotorLazoAbierto_P.Memory_InitialCondition;

  /* SystemInitialize for Outport: '<S3>/T*sing ' */
  MotorLazoAbierto_B.Product = MotorLazoAbierto_P.Tsing_Y0;

  /* SystemInitialize for Outport: '<S3>/dT ultimo p ' */
  MotorLazoAbierto_B.Product2 = MotorLazoAbierto_P.dTultimop_Y0;

  /* SystemInitialize for Outport: '<S3>/T actual' */
  MotorLazoAbierto_B.In1 = MotorLazoAbierto_P.Tactual_Y0;

  /* End of SystemInitialize for SubSystem: '<S2>/Triggered Subsystem' */
}

/* Model terminate function */
void MotorLazoAbierto_terminate(void)
{
  /* Terminate for MATLABSystem: '<S1>/Hall 1' */
  matlabCodegenHandle_matlab_i25o(&MotorLazoAbierto_DW.obj);

  /* Terminate for MATLABSystem: '<S1>/Hall 2' */
  matlabCodegenHandle_matlab_i25o(&MotorLazoAbierto_DW.obj_i);

  /* Terminate for MATLABSystem: '<S1>/PWM Output' */
  matlabCodegenHandle_matlabCo_i2(&MotorLazoAbierto_DW.obj_b);

  /* Terminate for MATLABSystem: '<S1>/PWM Output1' */
  matlabCodegenHandle_matlabCo_i2(&MotorLazoAbierto_DW.obj_n);

  /* Terminate for MATLABSystem: '<S1>/Digital Write' */
  matlabCodegenHandle_matlabCodeg(&MotorLazoAbierto_DW.obj_p);

  /* Terminate for MATLABSystem: '<S1>/Digital Write2' */
  matlabCodegenHandle_matlabCodeg(&MotorLazoAbierto_DW.obj_m);
}
