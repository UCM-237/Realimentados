%Motor en varibles de estado
clear all
close all
km = 100;
p = 55;
vmotor = tf(km,[1 p]); %velocidad simple
pmotor = tf(1,[1 0])*vmotor;  %posicion motor

%Matrices del sistema x1 es posicion y x2 es velocidad
A = [0 1;0 -p];
B = [0;km];
C = [1 0];
D = 0;
pmotors = ss(A,B,C,D);

step(pmotor)
hold on
step(pmotors)

%ponemos con acker unos polos lentos para empezar
k = acker(A,B,[-40 -40]);
%y unos polos al observador mas rapidos
L =acker(A',C', [-60,-60])';

%monto sistema completo....
Aam = [A -B*k;L*C A-B*k-L*C];
Bam =[B;B];
Cam =[C C];


F = inv(C*inv(B*k-A)*B);
sysobsF = ss(Aam,Bam*F,Cam,D);
[y,t,x] = step(sysobsF);
figure
plot(t,x)
hold on
%calculamos


%Discretizamos
T = 1e-4;
pmotorz =c2d(pmotors,T);
Gz = pmotorz.A;
Hz = pmotorz.B;
Cz = pmotorz.C;
kz = acker(Gz,Hz,[exp(-40*T),exp(-40*T)]);
Lz =acker(Gz',Cz',[exp(-60*T),exp(-60*T)])';
Fam = [Gz -Hz*kz;Lz*Cz Gz-Hz*kz-Lz*Cz];
Gam =[Hz;Hz] ;
Camz =[Cz Cz];
F = inv(Cz*inv(eye(size(Gz))-(Gz-Hz*kz))*Hz);

sysobsz = ss(Fam,Gam*F,Camz,D,T);
[yz,tz,xz]=step(sysobsz);
plot(tz,xz,'.')


figure(1)
step(pmotorz)




