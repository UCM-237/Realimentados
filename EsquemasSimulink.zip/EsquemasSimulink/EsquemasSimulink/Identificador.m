

%archivo para identificar datos de las simulaciones del motor
%los datos de entrada deben ser times series

close all
clear all
load pos_motor
%para datos cargados en el work space con nombre de variable con fromato
%posxx, donde xx el porcentaje del voltaje maxinmo con 
%que se ha alimentado el motor. V maximo = 12V
%creamos una lista de variables
c = who;

for i =1:size(c,1)
    V(i) =str2num(c{i}(3:end))*0.01*12; %voltaje aplicado % de 12 V
    %extraigo el tiempo:
    t = eval([c{i} '.Time']);
    %extraigo la posicion;
    x = eval([c{i} '.Data']) - eval([c{i} '.Data(1)']);
    %calculo una regresion lineal
    recta = polyfit(t(floor(length(t)/100):length(t)),x(floor(length(t)/100):length(t))*pi/180,1);
    polo(i) = -recta(1)/recta(2);
    Ganancia(i) = recta(1)*polo(i)/V(i);
    %plot(t,x*pi/180)
    %hold on
end
figure,plot(V,Ganancia,'o'),hold on
GananciaMx=vec2mat(Ganancia,21);
GananciaMedia=mean(GananciaMx);
plot(V(1:21),GananciaMedia),hold off
grid;ylabel('Valor de la ganancia');xlabel('Voltaje (V)')
figure,plot(V,polo,'^'),hold on
poloMx=vec2mat(polo,21);
poloMedia=mean(poloMx);
plot(V(1:21),poloMedia),hold off
grid,ylabel('Valor del polo'),xlabel('Voltaje (V)')