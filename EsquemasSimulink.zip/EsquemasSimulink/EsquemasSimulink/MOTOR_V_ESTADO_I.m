%MOtorcillo en varibles de estado
clear all
%close all
km = 4000 %100
p = 55
vmotor = tf(km,[1 p]) %velocidad simple
pmotor = tf(1,[1 0])*vmotor  %posicion motor

%Matrices del sistema x1 es posicion y x2 es velocidad
A = [0 1;0 -p]
B = [0;km]
C = [1 0]
D = 0
pmotors = ss(A,B,C,D)

% step(pmotor)
% hold on
% step(pmotors)

%ampliamos para añadir acción integral
AI = [A [0;0]; C 0]
BI = [B;0]
P = [-15 -15 -20]%*0.1 %el factor es para hacerlos mas pequeñso
%ponemos con acker unos polos lentitos para empezar
ka = acker(AI,BI,P) %el tercer polo es para la acc integral
%y unos polos al observador mas rapidillos
PL = [-20 -20]%*0.1 
L =acker(A',C',PL)'
%separo las ganancias para elegir o no la accion integral
ki = ka(end)
k = ka(1:2)
%monto sistema completo....
Aam = [A -B*ki -B*k; C 0 0 0; L*C -B*ki A-B*k-L*C]
%calculamos feedforward
F = inv(C*inv(B*k(1:2)-A)*B) %originalmente estaba *10
Bam =[B*F;-1;B*F] 
Cam =[C 0 0 0]
sysobsF = ss(Aam,Bam,Cam,D)
%[y,t,x] = step(sysobsF)
%figure
%step(sysobsF)
t =0:1e-6:1;
u = 10*ones(size(t));
[y,t,x]=lsim(sysobsF,u,t);
plot(t,y)
legend
hold on

%Discretizamos
T =1e-4
%Discretizamos a lo cafre
pmotorz =c2d(pmotors,T)
Fz = pmotorz.A
G = pmotorz.B
Cz = pmotorz.C
%ampliamos para añadir acción integral
FzI = [Fz [0;0]; T*Cz 1]
GI = [G;0]
kz = acker(FzI,GI,[exp(P(1)*T),exp(P(2)*T), exp(P(3)*T)])
Lz =acker(Fz',Cz',[exp(PL(1)*T),exp(PL(2)*T)])'
%separo ganancia accion integral
kiz =  kz(end)
kz = kz(1:2)
%monto sistema completo....
Fam = [Fz -G*kiz -G*kz; T*Cz 1 0 0; Lz*Cz -G*kiz Fz-G*kz-Lz*Cz]
%calulamos feedforward (si metemos el mismo valor no calculado en continuo
%y en discreto, las dinámicas no seran las mismas aunque si el resultado
%final. Habria que ajustar la relacion si se quiere reproducir un
%comportamiento del modelo continuo al discreto
%f = inv(Cz*inv(eye(size(Fz))-(Fz-G*kz))*G)
%Forma alternativa basada en obtenre f para que iguale la salida del modelo
%continuo. La similitud se perdera si el muestreo es muy lento...
f= - inv(Cz*inv(eye(size(Fz))-(Fz-G*kz))*G)*C*inv(A-B*k)*B*F
%f = 0
Gam =[G*f;-T;G*f] 
Camz =[Cz 0 0 0]
f2 =  inv(Cz*inv(eye(size(Fz))-(Fz-G*kz))*G)

sysobsz = ss(Fam,Gam,Camz,D,T)
tz = 0:T:1
uz = 10*ones(size(tz));
[yz,t,x]=lsim(sysobsz,uz,tz);
%step(sysobsz)
%plot(t,f + kiz*x(:,4))
plot(t,yz)

%añadimos una constante para el antiwind-up
kawp =0.1








