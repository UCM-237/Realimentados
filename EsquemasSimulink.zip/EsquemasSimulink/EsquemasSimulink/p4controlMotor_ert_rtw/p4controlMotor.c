/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: p4controlMotor.c
 *
 * Code generated for Simulink model 'p4controlMotor'.
 *
 * Model version                  : 1.4
 * Simulink Coder version         : 9.1 (R2019a) 23-Nov-2018
 * C/C++ source code generated on : Thu Dec 17 09:44:42 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "p4controlMotor.h"
#include "p4controlMotor_private.h"

/* Block signals (default storage) */
B_p4controlMotor_T p4controlMotor_B;

/* Block states (default storage) */
DW_p4controlMotor_T p4controlMotor_DW;

/* Real-time model */
RT_MODEL_p4controlMotor_T p4controlMotor_M_;
RT_MODEL_p4controlMotor_T *const p4controlMotor_M = &p4controlMotor_M_;

/* Forward declaration for local functions */
static void p4contro_SystemCore_release_kci(const
  mbed_DigitalWrite_p4controlMo_T *obj);
static void p4control_SystemCore_delete_kci(const
  mbed_DigitalWrite_p4controlMo_T *obj);
static void matlabCodegenHandle_matlabC_kci(mbed_DigitalWrite_p4controlMo_T *obj);
static void p4controlM_SystemCore_release_k(const
  mbed_DigitalRead_p4controlMot_T *obj);
static void p4controlMo_SystemCore_delete_k(const
  mbed_DigitalRead_p4controlMot_T *obj);
static void matlabCodegenHandle_matlabCod_k(mbed_DigitalRead_p4controlMot_T *obj);
static void p4controlMot_SystemCore_release(const
  mbed_PWMOutput_p4controlMotor_T *obj);
static void p4controlMoto_SystemCore_delete(const
  mbed_PWMOutput_p4controlMotor_T *obj);
static void matlabCodegenHandle_matlabCodeg(mbed_PWMOutput_p4controlMotor_T *obj);
static void p4contro_SystemCore_release_kci(const
  mbed_DigitalWrite_p4controlMo_T *obj)
{
  if ((obj->isInitialized == 1) && obj->isSetupComplete) {
    MW_digitalIO_close(obj->MW_DIGITALIO_HANDLE);
  }
}

static void p4control_SystemCore_delete_kci(const
  mbed_DigitalWrite_p4controlMo_T *obj)
{
  p4contro_SystemCore_release_kci(obj);
}

static void matlabCodegenHandle_matlabC_kci(mbed_DigitalWrite_p4controlMo_T *obj)
{
  if (!obj->matlabCodegenIsDeleted) {
    obj->matlabCodegenIsDeleted = true;
    p4control_SystemCore_delete_kci(obj);
  }
}

static void p4controlM_SystemCore_release_k(const
  mbed_DigitalRead_p4controlMot_T *obj)
{
  if ((obj->isInitialized == 1) && obj->isSetupComplete) {
    MW_digitalIO_close(obj->MW_DIGITALIO_HANDLE);
  }
}

static void p4controlMo_SystemCore_delete_k(const
  mbed_DigitalRead_p4controlMot_T *obj)
{
  p4controlM_SystemCore_release_k(obj);
}

static void matlabCodegenHandle_matlabCod_k(mbed_DigitalRead_p4controlMot_T *obj)
{
  if (!obj->matlabCodegenIsDeleted) {
    obj->matlabCodegenIsDeleted = true;
    p4controlMo_SystemCore_delete_k(obj);
  }
}

static void p4controlMot_SystemCore_release(const
  mbed_PWMOutput_p4controlMotor_T *obj)
{
  if ((obj->isInitialized == 1) && obj->isSetupComplete) {
    MW_PWM_Stop(obj->MW_PWM_HANDLE);
    MW_PWM_Close(obj->MW_PWM_HANDLE);
  }
}

static void p4controlMoto_SystemCore_delete(const
  mbed_PWMOutput_p4controlMotor_T *obj)
{
  p4controlMot_SystemCore_release(obj);
}

static void matlabCodegenHandle_matlabCodeg(mbed_PWMOutput_p4controlMotor_T *obj)
{
  if (!obj->matlabCodegenIsDeleted) {
    obj->matlabCodegenIsDeleted = true;
    p4controlMoto_SystemCore_delete(obj);
  }
}

/* Model step function */
void p4controlMotor_step(void)
{
  /* local block i/o variables */
  real_T rtb_TSamp;
  uint8_T rtb_Gain2;
  uint8_T rtb_Gain;
  real_T u0;

  /* MATLABSystem: '<Root>/Digital Write2' incorporates:
   *  Constant: '<Root>/Constant'
   */
  MW_digitalIO_write(p4controlMotor_DW.obj_h.MW_DIGITALIO_HANDLE,
                     p4controlMotor_P.Constant_Value != 0.0);

  /* MATLABSystem: '<Root>/Digital Write' incorporates:
   *  Constant: '<Root>/Constant1'
   */
  MW_digitalIO_write(p4controlMotor_DW.obj_g.MW_DIGITALIO_HANDLE,
                     p4controlMotor_P.Constant1_Value != 0.0);

  /* MATLABSystem: '<Root>/Digital Write1' incorporates:
   *  Constant: '<Root>/Constant2'
   */
  MW_digitalIO_write(p4controlMotor_DW.obj_h5.MW_DIGITALIO_HANDLE,
                     p4controlMotor_P.Constant2_Value != 0.0);

  /* UnitDelay: '<S1>/Unit Delay2' */
  p4controlMotor_B.UnitDelay2 = p4controlMotor_DW.UnitDelay2_DSTATE;

  /* SampleTimeMath: '<S2>/TSamp'
   *
   * About '<S2>/TSamp':
   *  y = u * K where K = 1 / ( w * Ts )
   */
  rtb_TSamp = p4controlMotor_B.UnitDelay2 * p4controlMotor_P.TSamp_WtEt;

  /* Sum: '<S2>/Diff' incorporates:
   *  UnitDelay: '<S2>/UD'
   *
   * Block description for '<S2>/Diff':
   *
   *  Add in CPU
   *
   * Block description for '<S2>/UD':
   *
   *  Store in Global RAM
   */
  p4controlMotor_B.Diff = rtb_TSamp - p4controlMotor_DW.UD_DSTATE;

  /* Gain: '<S1>/Gain' incorporates:
   *  UnitDelay: '<S1>/Unit Delay'
   */
  rtb_Gain = (uint8_T)(p4controlMotor_DW.UnitDelay_DSTATE ? (int32_T)
                       p4controlMotor_P.Gain_Gain : 0);

  /* MATLABSystem: '<Root>/Digital Read' incorporates:
   *  UnitDelay: '<S1>/Unit Delay'
   */
  if (p4controlMotor_DW.obj.SampleTime !=
      p4controlMotor_P.DigitalRead_SampleTime) {
    p4controlMotor_DW.obj.SampleTime = p4controlMotor_P.DigitalRead_SampleTime;
  }

  p4controlMotor_DW.UnitDelay_DSTATE = MW_digitalIO_read
    (p4controlMotor_DW.obj.MW_DIGITALIO_HANDLE);

  /* End of MATLABSystem: '<Root>/Digital Read' */

  /* Gain: '<S1>/Gain2' incorporates:
   *  UnitDelay: '<S1>/Unit Delay1'
   */
  rtb_Gain2 = (uint8_T)(p4controlMotor_DW.UnitDelay1_DSTATE ? (int32_T)
                        p4controlMotor_P.Gain2_Gain : 0);

  /* MATLABSystem: '<Root>/Digital Read1' incorporates:
   *  UnitDelay: '<S1>/Unit Delay1'
   */
  if (p4controlMotor_DW.obj_b.SampleTime !=
      p4controlMotor_P.DigitalRead1_SampleTime) {
    p4controlMotor_DW.obj_b.SampleTime =
      p4controlMotor_P.DigitalRead1_SampleTime;
  }

  p4controlMotor_DW.UnitDelay1_DSTATE = MW_digitalIO_read
    (p4controlMotor_DW.obj_b.MW_DIGITALIO_HANDLE);

  /* End of MATLABSystem: '<Root>/Digital Read1' */

  /* LookupNDDirect: '<S1>/Direct Lookup Table (n-D)' incorporates:
   *  Gain: '<S1>/Gain1'
   *  Gain: '<S1>/Gain3'
   *  Sum: '<S1>/Subtract'
   *  UnitDelay: '<S1>/Unit Delay'
   *  UnitDelay: '<S1>/Unit Delay1'
   *
   * About '<S1>/Direct Lookup Table (n-D)':
   *  1-dimensional Direct Look-Up returning a Scalar,
   */
  u0 = (((real_T)rtb_Gain * 0.0625 + (real_T)(p4controlMotor_DW.UnitDelay_DSTATE
          ? (int32_T)p4controlMotor_P.Gain1_Gain : 0) * 0.03125) + (real_T)
        rtb_Gain2 * 0.015625) + (real_T)(p4controlMotor_DW.UnitDelay1_DSTATE ?
    (int32_T)p4controlMotor_P.Gain3_Gain : 0) * 0.0078125;
  if (u0 > 14.0) {
    u0 = 14.0;
  }

  /* Sum: '<S1>/Sum' incorporates:
   *  LookupNDDirect: '<S1>/Direct Lookup Table (n-D)'
   *  UnitDelay: '<S1>/Unit Delay2'
   *
   * About '<S1>/Direct Lookup Table (n-D)':
   *  1-dimensional Direct Look-Up returning a Scalar,
   */
  p4controlMotor_DW.UnitDelay2_DSTATE =
    p4controlMotor_P.DirectLookupTablenD_table[(int32_T)u0] +
    p4controlMotor_B.UnitDelay2;

  /* Step: '<Root>/Step' */
  if (p4controlMotor_M->Timing.t[0] < p4controlMotor_P.Step_Time) {
    u0 = p4controlMotor_P.Step_Y0;
  } else {
    u0 = p4controlMotor_P.Step_YFinal;
  }

  /* End of Step: '<Root>/Step' */

  /* MATLABSystem: '<Root>/PWM Output' */
  MW_PWM_SetDutyCycle(p4controlMotor_DW.obj_p.MW_PWM_HANDLE, u0);

  /* Update for UnitDelay: '<S2>/UD'
   *
   * Block description for '<S2>/UD':
   *
   *  Store in Global RAM
   */
  p4controlMotor_DW.UD_DSTATE = rtb_TSamp;

  /* External mode */
  rtExtModeUploadCheckTrigger(2);

  {                                    /* Sample time: [0.0s, 0.0s] */
    rtExtModeUpload(0, (real_T)p4controlMotor_M->Timing.t[0]);
  }

  {                                    /* Sample time: [0.2s, 0.0s] */
    rtExtModeUpload(1, (real_T)((p4controlMotor_M->Timing.clockTick1) * 0.2));
  }

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.0s, 0.0s] */
    if ((rtmGetTFinal(p4controlMotor_M)!=-1) &&
        !((rtmGetTFinal(p4controlMotor_M)-p4controlMotor_M->Timing.t[0]) >
          p4controlMotor_M->Timing.t[0] * (DBL_EPSILON))) {
      rtmSetErrorStatus(p4controlMotor_M, "Simulation finished");
    }

    if (rtmGetStopRequested(p4controlMotor_M)) {
      rtmSetErrorStatus(p4controlMotor_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  p4controlMotor_M->Timing.t[0] =
    (++p4controlMotor_M->Timing.clockTick0) * p4controlMotor_M->Timing.stepSize0;

  {
    /* Update absolute timer for sample time: [0.2s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The resolution of this integer timer is 0.2, which is the step size
     * of the task. Size of "clockTick1" ensures timer will not overflow during the
     * application lifespan selected.
     */
    p4controlMotor_M->Timing.clockTick1++;
  }
}

/* Model initialize function */
void p4controlMotor_initialize(void)
{
  /* Registration code */

  /* initialize real-time model */
  (void) memset((void *)p4controlMotor_M, 0,
                sizeof(RT_MODEL_p4controlMotor_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&p4controlMotor_M->solverInfo,
                          &p4controlMotor_M->Timing.simTimeStep);
    rtsiSetTPtr(&p4controlMotor_M->solverInfo, &rtmGetTPtr(p4controlMotor_M));
    rtsiSetStepSizePtr(&p4controlMotor_M->solverInfo,
                       &p4controlMotor_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&p4controlMotor_M->solverInfo, (&rtmGetErrorStatus
      (p4controlMotor_M)));
    rtsiSetRTModelPtr(&p4controlMotor_M->solverInfo, p4controlMotor_M);
  }

  rtsiSetSimTimeStep(&p4controlMotor_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetSolverName(&p4controlMotor_M->solverInfo,"FixedStepDiscrete");
  rtmSetTPtr(p4controlMotor_M, &p4controlMotor_M->Timing.tArray[0]);
  rtmSetTFinal(p4controlMotor_M, 10.0);
  p4controlMotor_M->Timing.stepSize0 = 0.2;

  /* External mode info */
  p4controlMotor_M->Sizes.checksums[0] = (1233582957U);
  p4controlMotor_M->Sizes.checksums[1] = (1664463758U);
  p4controlMotor_M->Sizes.checksums[2] = (412161358U);
  p4controlMotor_M->Sizes.checksums[3] = (4078574884U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[7];
    p4controlMotor_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = &rtAlwaysEnabled;
    systemRan[3] = &rtAlwaysEnabled;
    systemRan[4] = &rtAlwaysEnabled;
    systemRan[5] = &rtAlwaysEnabled;
    systemRan[6] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(p4controlMotor_M->extModeInfo,
      &p4controlMotor_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(p4controlMotor_M->extModeInfo,
                        p4controlMotor_M->Sizes.checksums);
    rteiSetTPtr(p4controlMotor_M->extModeInfo, rtmGetTPtr(p4controlMotor_M));
  }

  /* block I/O */
  (void) memset(((void *) &p4controlMotor_B), 0,
                sizeof(B_p4controlMotor_T));

  /* states (dwork) */
  (void) memset((void *)&p4controlMotor_DW, 0,
                sizeof(DW_p4controlMotor_T));

  {
    mbed_DigitalWrite_p4controlMo_T *obj;
    uint32_T pinname;
    mbed_DigitalRead_p4controlMot_T *obj_0;
    mbed_PWMOutput_p4controlMotor_T *obj_1;

    /* Start for MATLABSystem: '<Root>/Digital Write2' */
    p4controlMotor_DW.obj_h.matlabCodegenIsDeleted = true;
    p4controlMotor_DW.obj_h.isInitialized = 0;
    p4controlMotor_DW.obj_h.matlabCodegenIsDeleted = false;
    obj = &p4controlMotor_DW.obj_h;
    p4controlMotor_DW.obj_h.isSetupComplete = false;
    p4controlMotor_DW.obj_h.isInitialized = 1;
    pinname = D3;
    obj->MW_DIGITALIO_HANDLE = MW_digitalIO_open(pinname, 1);
    p4controlMotor_DW.obj_h.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Digital Write' */
    p4controlMotor_DW.obj_g.matlabCodegenIsDeleted = true;
    p4controlMotor_DW.obj_g.isInitialized = 0;
    p4controlMotor_DW.obj_g.matlabCodegenIsDeleted = false;
    obj = &p4controlMotor_DW.obj_g;
    p4controlMotor_DW.obj_g.isSetupComplete = false;
    p4controlMotor_DW.obj_g.isInitialized = 1;
    pinname = D11;
    obj->MW_DIGITALIO_HANDLE = MW_digitalIO_open(pinname, 1);
    p4controlMotor_DW.obj_g.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Digital Write1' */
    p4controlMotor_DW.obj_h5.matlabCodegenIsDeleted = true;
    p4controlMotor_DW.obj_h5.isInitialized = 0;
    p4controlMotor_DW.obj_h5.matlabCodegenIsDeleted = false;
    obj = &p4controlMotor_DW.obj_h5;
    p4controlMotor_DW.obj_h5.isSetupComplete = false;
    p4controlMotor_DW.obj_h5.isInitialized = 1;
    pinname = D2;
    obj->MW_DIGITALIO_HANDLE = MW_digitalIO_open(pinname, 1);
    p4controlMotor_DW.obj_h5.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Digital Read' */
    p4controlMotor_DW.obj.matlabCodegenIsDeleted = true;
    p4controlMotor_DW.obj.isInitialized = 0;
    p4controlMotor_DW.obj.SampleTime = -1.0;
    p4controlMotor_DW.obj.matlabCodegenIsDeleted = false;
    p4controlMotor_DW.obj.SampleTime = p4controlMotor_P.DigitalRead_SampleTime;
    obj_0 = &p4controlMotor_DW.obj;
    p4controlMotor_DW.obj.isSetupComplete = false;
    p4controlMotor_DW.obj.isInitialized = 1;
    pinname = A1;
    obj_0->MW_DIGITALIO_HANDLE = MW_digitalIO_open(pinname, 0);
    p4controlMotor_DW.obj.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/Digital Read1' */
    p4controlMotor_DW.obj_b.matlabCodegenIsDeleted = true;
    p4controlMotor_DW.obj_b.isInitialized = 0;
    p4controlMotor_DW.obj_b.SampleTime = -1.0;
    p4controlMotor_DW.obj_b.matlabCodegenIsDeleted = false;
    p4controlMotor_DW.obj_b.SampleTime =
      p4controlMotor_P.DigitalRead1_SampleTime;
    obj_0 = &p4controlMotor_DW.obj_b;
    p4controlMotor_DW.obj_b.isSetupComplete = false;
    p4controlMotor_DW.obj_b.isInitialized = 1;
    pinname = A0;
    obj_0->MW_DIGITALIO_HANDLE = MW_digitalIO_open(pinname, 0);
    p4controlMotor_DW.obj_b.isSetupComplete = true;

    /* Start for MATLABSystem: '<Root>/PWM Output' */
    p4controlMotor_DW.obj_p.matlabCodegenIsDeleted = true;
    p4controlMotor_DW.obj_p.isInitialized = 0;
    p4controlMotor_DW.obj_p.matlabCodegenIsDeleted = false;
    obj_1 = &p4controlMotor_DW.obj_p;
    p4controlMotor_DW.obj_p.isSetupComplete = false;
    p4controlMotor_DW.obj_p.isInitialized = 1;
    pinname = D5;
    obj_1->MW_PWM_HANDLE = MW_PWM_Open(pinname, 5000.0, 0.0);
    MW_PWM_Start(p4controlMotor_DW.obj_p.MW_PWM_HANDLE);
    p4controlMotor_DW.obj_p.isSetupComplete = true;

    /* InitializeConditions for UnitDelay: '<S1>/Unit Delay2' */
    p4controlMotor_DW.UnitDelay2_DSTATE =
      p4controlMotor_P.UnitDelay2_InitialCondition;

    /* InitializeConditions for UnitDelay: '<S2>/UD'
     *
     * Block description for '<S2>/UD':
     *
     *  Store in Global RAM
     */
    p4controlMotor_DW.UD_DSTATE =
      p4controlMotor_P.DiscreteDerivative_ICPrevScaled;

    /* InitializeConditions for UnitDelay: '<S1>/Unit Delay' */
    p4controlMotor_DW.UnitDelay_DSTATE =
      p4controlMotor_P.UnitDelay_InitialCondition;

    /* InitializeConditions for UnitDelay: '<S1>/Unit Delay1' */
    p4controlMotor_DW.UnitDelay1_DSTATE =
      p4controlMotor_P.UnitDelay1_InitialCondition;
  }
}

/* Model terminate function */
void p4controlMotor_terminate(void)
{
  /* Terminate for MATLABSystem: '<Root>/Digital Write2' */
  matlabCodegenHandle_matlabC_kci(&p4controlMotor_DW.obj_h);

  /* Terminate for MATLABSystem: '<Root>/Digital Write' */
  matlabCodegenHandle_matlabC_kci(&p4controlMotor_DW.obj_g);

  /* Terminate for MATLABSystem: '<Root>/Digital Write1' */
  matlabCodegenHandle_matlabC_kci(&p4controlMotor_DW.obj_h5);

  /* Terminate for MATLABSystem: '<Root>/Digital Read' */
  matlabCodegenHandle_matlabCod_k(&p4controlMotor_DW.obj);

  /* Terminate for MATLABSystem: '<Root>/Digital Read1' */
  matlabCodegenHandle_matlabCod_k(&p4controlMotor_DW.obj_b);

  /* Terminate for MATLABSystem: '<Root>/PWM Output' */
  matlabCodegenHandle_matlabCodeg(&p4controlMotor_DW.obj_p);
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
