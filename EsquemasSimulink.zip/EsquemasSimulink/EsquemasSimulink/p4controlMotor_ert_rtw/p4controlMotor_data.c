/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: p4controlMotor_data.c
 *
 * Code generated for Simulink model 'p4controlMotor'.
 *
 * Model version                  : 1.4
 * Simulink Coder version         : 9.1 (R2019a) 23-Nov-2018
 * C/C++ source code generated on : Thu Dec 17 09:44:42 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "p4controlMotor.h"
#include "p4controlMotor_private.h"

/* Block parameters (default storage) */
P_p4controlMotor_T p4controlMotor_P = {
  /* Mask Parameter: DiscreteDerivative_ICPrevScaled
   * Referenced by: '<S2>/UD'
   */
  0.0,

  /* Expression: -1
   * Referenced by: '<Root>/Digital Read1'
   */
  -1.0,

  /* Expression: -1
   * Referenced by: '<Root>/Digital Read'
   */
  -1.0,

  /* Expression: 0
   * Referenced by: '<Root>/Constant'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<Root>/Constant1'
   */
  1.0,

  /* Expression: 1
   * Referenced by: '<Root>/Constant2'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S1>/Unit Delay2'
   */
  0.0,

  /* Computed Parameter: TSamp_WtEt
   * Referenced by: '<S2>/TSamp'
   */
  5.0,

  /* Expression: [0,-1,1,0,1,0,-1,-1,0,0,1,0,1,-1,0]
   * Referenced by: '<S1>/Direct Lookup Table (n-D)'
   */
  { 0.0, -1.0, 1.0, 0.0, 1.0, 0.0, -1.0, -1.0, 0.0, 0.0, 1.0, 0.0, 1.0, -1.0,
    0.0 },

  /* Expression: 1
   * Referenced by: '<Root>/Step'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<Root>/Step'
   */
  0.0,

  /* Expression: 50
   * Referenced by: '<Root>/Step'
   */
  50.0,

  /* Computed Parameter: UnitDelay_InitialCondition
   * Referenced by: '<S1>/Unit Delay'
   */
  0,

  /* Computed Parameter: UnitDelay1_InitialCondition
   * Referenced by: '<S1>/Unit Delay1'
   */
  0,

  /* Computed Parameter: Gain_Gain
   * Referenced by: '<S1>/Gain'
   */
  128U,

  /* Computed Parameter: Gain1_Gain
   * Referenced by: '<S1>/Gain1'
   */
  128U,

  /* Computed Parameter: Gain2_Gain
   * Referenced by: '<S1>/Gain2'
   */
  128U,

  /* Computed Parameter: Gain3_Gain
   * Referenced by: '<S1>/Gain3'
   */
  128U
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
