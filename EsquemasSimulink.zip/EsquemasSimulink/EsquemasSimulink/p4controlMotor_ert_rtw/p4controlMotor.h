/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: p4controlMotor.h
 *
 * Code generated for Simulink model 'p4controlMotor'.
 *
 * Model version                  : 1.4
 * Simulink Coder version         : 9.1 (R2019a) 23-Nov-2018
 * C/C++ source code generated on : Thu Dec 17 09:44:42 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_p4controlMotor_h_
#define RTW_HEADER_p4controlMotor_h_
#include <float.h>
#include <string.h>
#include <stddef.h>
#ifndef p4controlMotor_COMMON_INCLUDES_
# define p4controlMotor_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "ext_work.h"
#include "MW_MbedPinInterface.h"
#include "MW_PWM.h"
#include "MW_digitalIO.h"
#endif                                 /* p4controlMotor_COMMON_INCLUDES_ */

#include "p4controlMotor_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "MW_target_hardware_resources.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWExtModeInfo
# define rtmGetRTWExtModeInfo(rtm)     ((rtm)->extModeInfo)
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               ((rtm)->Timing.t)
#endif

/* Block signals (default storage) */
typedef struct {
  real_T UnitDelay2;                   /* '<S1>/Unit Delay2' */
  real_T Diff;                         /* '<S2>/Diff' */
} B_p4controlMotor_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  mbed_DigitalRead_p4controlMot_T obj; /* '<Root>/Digital Read' */
  mbed_DigitalRead_p4controlMot_T obj_b;/* '<Root>/Digital Read1' */
  mbed_DigitalWrite_p4controlMo_T obj_h;/* '<Root>/Digital Write2' */
  mbed_DigitalWrite_p4controlMo_T obj_g;/* '<Root>/Digital Write' */
  mbed_DigitalWrite_p4controlMo_T obj_h5;/* '<Root>/Digital Write1' */
  mbed_PWMOutput_p4controlMotor_T obj_p;/* '<Root>/PWM Output' */
  real_T UnitDelay2_DSTATE;            /* '<S1>/Unit Delay2' */
  real_T UD_DSTATE;                    /* '<S2>/UD' */
  struct {
    void *LoggedData;
  } Scope_PWORK;                       /* '<Root>/Scope' */

  struct {
    void *LoggedData;
  } Scope1_PWORK;                      /* '<Root>/Scope1' */

  boolean_T UnitDelay_DSTATE;          /* '<S1>/Unit Delay' */
  boolean_T UnitDelay1_DSTATE;         /* '<S1>/Unit Delay1' */
} DW_p4controlMotor_T;

/* Parameters (default storage) */
struct P_p4controlMotor_T_ {
  real_T DiscreteDerivative_ICPrevScaled;
                              /* Mask Parameter: DiscreteDerivative_ICPrevScaled
                               * Referenced by: '<S2>/UD'
                               */
  real_T DigitalRead1_SampleTime;      /* Expression: -1
                                        * Referenced by: '<Root>/Digital Read1'
                                        */
  real_T DigitalRead_SampleTime;       /* Expression: -1
                                        * Referenced by: '<Root>/Digital Read'
                                        */
  real_T Constant_Value;               /* Expression: 0
                                        * Referenced by: '<Root>/Constant'
                                        */
  real_T Constant1_Value;              /* Expression: 1
                                        * Referenced by: '<Root>/Constant1'
                                        */
  real_T Constant2_Value;              /* Expression: 1
                                        * Referenced by: '<Root>/Constant2'
                                        */
  real_T UnitDelay2_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S1>/Unit Delay2'
                                        */
  real_T TSamp_WtEt;                   /* Computed Parameter: TSamp_WtEt
                                        * Referenced by: '<S2>/TSamp'
                                        */
  real_T DirectLookupTablenD_table[15];
                              /* Expression: [0,-1,1,0,1,0,-1,-1,0,0,1,0,1,-1,0]
                               * Referenced by: '<S1>/Direct Lookup Table (n-D)'
                               */
  real_T Step_Time;                    /* Expression: 1
                                        * Referenced by: '<Root>/Step'
                                        */
  real_T Step_Y0;                      /* Expression: 0
                                        * Referenced by: '<Root>/Step'
                                        */
  real_T Step_YFinal;                  /* Expression: 50
                                        * Referenced by: '<Root>/Step'
                                        */
  boolean_T UnitDelay_InitialCondition;
                               /* Computed Parameter: UnitDelay_InitialCondition
                                * Referenced by: '<S1>/Unit Delay'
                                */
  boolean_T UnitDelay1_InitialCondition;
                              /* Computed Parameter: UnitDelay1_InitialCondition
                               * Referenced by: '<S1>/Unit Delay1'
                               */
  uint8_T Gain_Gain;                   /* Computed Parameter: Gain_Gain
                                        * Referenced by: '<S1>/Gain'
                                        */
  uint8_T Gain1_Gain;                  /* Computed Parameter: Gain1_Gain
                                        * Referenced by: '<S1>/Gain1'
                                        */
  uint8_T Gain2_Gain;                  /* Computed Parameter: Gain2_Gain
                                        * Referenced by: '<S1>/Gain2'
                                        */
  uint8_T Gain3_Gain;                  /* Computed Parameter: Gain3_Gain
                                        * Referenced by: '<S1>/Gain3'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_p4controlMotor_T {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;
  RTWSolverInfo solverInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    time_T tFinal;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Block parameters (default storage) */
extern P_p4controlMotor_T p4controlMotor_P;

/* Block signals (default storage) */
extern B_p4controlMotor_T p4controlMotor_B;

/* Block states (default storage) */
extern DW_p4controlMotor_T p4controlMotor_DW;

/* Model entry point functions */
extern void p4controlMotor_initialize(void);
extern void p4controlMotor_step(void);
extern void p4controlMotor_terminate(void);

/* Real-time Model object */
extern RT_MODEL_p4controlMotor_T *const p4controlMotor_M;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S2>/Data Type Duplicate' : Unused code path elimination
 * Block '<S1>/Zero-Order Hold' : Eliminated since input and output rates are identical
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'p4controlMotor'
 * '<S1>'   : 'p4controlMotor/Subsystem'
 * '<S2>'   : 'p4controlMotor/Subsystem/Discrete Derivative'
 */
#endif                                 /* RTW_HEADER_p4controlMotor_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
