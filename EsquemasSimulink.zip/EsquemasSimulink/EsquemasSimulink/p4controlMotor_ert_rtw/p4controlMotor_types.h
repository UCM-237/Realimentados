/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: p4controlMotor_types.h
 *
 * Code generated for Simulink model 'p4controlMotor'.
 *
 * Model version                  : 1.4
 * Simulink Coder version         : 9.1 (R2019a) 23-Nov-2018
 * C/C++ source code generated on : Thu Dec 17 09:44:42 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_p4controlMotor_types_h_
#define RTW_HEADER_p4controlMotor_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"

/* Custom Type definition for MATLABSystem: '<Root>/Digital Write2' */
#include "MW_SVD.h"
#ifndef typedef_mbed_PWMOutput_p4controlMotor_T
#define typedef_mbed_PWMOutput_p4controlMotor_T

typedef struct {
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  MW_Handle_Type MW_PWM_HANDLE;
} mbed_PWMOutput_p4controlMotor_T;

#endif                               /*typedef_mbed_PWMOutput_p4controlMotor_T*/

#ifndef typedef_mbed_DigitalRead_p4controlMot_T
#define typedef_mbed_DigitalRead_p4controlMot_T

typedef struct {
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  MW_Handle_Type MW_DIGITALIO_HANDLE;
  real_T SampleTime;
} mbed_DigitalRead_p4controlMot_T;

#endif                               /*typedef_mbed_DigitalRead_p4controlMot_T*/

#ifndef typedef_mbed_DigitalWrite_p4controlMo_T
#define typedef_mbed_DigitalWrite_p4controlMo_T

typedef struct {
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  MW_Handle_Type MW_DIGITALIO_HANDLE;
} mbed_DigitalWrite_p4controlMo_T;

#endif                               /*typedef_mbed_DigitalWrite_p4controlMo_T*/

/* Parameters (default storage) */
typedef struct P_p4controlMotor_T_ P_p4controlMotor_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_p4controlMotor_T RT_MODEL_p4controlMotor_T;

#endif                                 /* RTW_HEADER_p4controlMotor_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
