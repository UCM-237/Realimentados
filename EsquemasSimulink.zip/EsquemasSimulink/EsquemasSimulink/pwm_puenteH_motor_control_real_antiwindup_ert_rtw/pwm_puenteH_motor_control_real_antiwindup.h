/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: pwm_puenteH_motor_control_real_antiwindup.h
 *
 * Code generated for Simulink model 'pwm_puenteH_motor_control_real_antiwindup'.
 *
 * Model version                  : 1.14
 * Simulink Coder version         : 9.1 (R2019a) 23-Nov-2018
 * C/C++ source code generated on : Thu Jan 16 14:51:07 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_pwm_puenteH_motor_control_real_antiwindup_h_
#define RTW_HEADER_pwm_puenteH_motor_control_real_antiwindup_h_
#include <math.h>
#include <float.h>
#include <string.h>
#include <stddef.h>
#ifndef pwm_puenteH_motor_control_real_antiwindup_COMMON_INCLUDES_
# define pwm_puenteH_motor_control_real_antiwindup_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "ext_work.h"
#include "MW_MbedPinInterface.h"
#include "MW_digitalIO.h"
#include "MW_PWM.h"
#endif          /* pwm_puenteH_motor_control_real_antiwindup_COMMON_INCLUDES_ */

#include "pwm_puenteH_motor_control_real_antiwindup_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "MW_target_hardware_resources.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWExtModeInfo
# define rtmGetRTWExtModeInfo(rtm)     ((rtm)->extModeInfo)
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmStepTask
# define rtmStepTask(rtm, idx)         ((rtm)->Timing.TaskCounters.TID[(idx)] == 0)
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               (&(rtm)->Timing.taskTime0)
#endif

#ifndef rtmTaskCounter
# define rtmTaskCounter(rtm, idx)      ((rtm)->Timing.TaskCounters.TID[(idx)])
#endif

#define pwm_puenteH_motor_control_real_antiwindup_M (pwm_puenteH_motor_control_re_M)

/* Block signals (default storage) */
typedef struct {
  real_T EenzPcontinua[2];             /* '<Root>/E en z P continua' */
  real_T Posiciondeg;                  /* '<S3>/Posicion (deg)' */
  real_T x_r;                          /* '<Root>/x_r' */
  real_T Gain1;                        /* '<Root>/Gain1' */
  real_T ZeroOrderHold;                /* '<Root>/Zero-Order Hold' */
  real_T ZeroOrderHold_c;              /* '<S3>/Zero-Order Hold' */
  real_T Diff;                         /* '<S4>/Diff' */
  boolean_T EncoderA;                  /* '<S2>/Encoder A' */
  boolean_T EncoderB;                  /* '<S2>/EncoderB' */
} B_pwm_puenteH_motor_control_r_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  mbed_DigitalRead_pwm_puenteH__T obj; /* '<S2>/Encoder A' */
  mbed_DigitalRead_pwm_puenteH__T obj_p;/* '<S2>/EncoderB' */
  mbed_DigitalWrite_pwm_puenteH_T obj_d;/* '<S2>/PHA' */
  mbed_DigitalWrite_pwm_puenteH_T obj_a;/* '<S2>/ENA' */
  mbed_DigitalWrite_pwm_puenteH_T obj_h;/* '<S2>/ENB' */
  mbed_PWMOutput_pwm_puenteH_mo_T obj_c;/* '<S2>/PWDA' */
  real_T EenzPcontinua_DSTATE[2];      /* '<Root>/E en z P continua' */
  real_T Posiciondeg_DSTATE;           /* '<S3>/Posicion (deg)' */
  real_T IenPCZ_DSTATE;                /* '<Root>/I  en P. C Z' */
  real_T UD_DSTATE;                    /* '<S4>/UD' */
  struct {
    void *AQHandles;
    void *SlioLTF;
  } HiddenToAsyncQueue_InsertedFor_;   /* synthesized block */

  struct {
    void *AQHandles;
    void *SlioLTF;
  } HiddenToAsyncQueue_InsertedFo_m;   /* synthesized block */

  struct {
    void *AQHandles;
    void *SlioLTF;
  } HiddenToAsyncQueue_InsertedFo_j;   /* synthesized block */

  struct {
    void *AQHandles;
    void *SlioLTF;
  } HiddenToAsyncQueue_InsertedFo_o;   /* synthesized block */

  struct {
    void *AQHandles;
    void *SlioLTF;
  } HiddenToAsyncQueue_InsertedF_o5;   /* synthesized block */

  struct {
    void *AQHandles;
    void *SlioLTF;
  } HiddenToAsyncQueue_InsertedFo_g;   /* synthesized block */

  struct {
    void *AQHandles;
    void *SlioLTF;
  } HiddenToAsyncQueue_InsertedF_ji;   /* synthesized block */

  struct {
    void *AQHandles;
    void *SlioLTF;
  } HiddenToAsyncQueue_InsertedFo_e;   /* synthesized block */

  boolean_T UnitDelay_DSTATE;          /* '<S3>/Unit Delay' */
  boolean_T UnitDelay1_DSTATE;         /* '<S3>/Unit Delay1' */
} DW_pwm_puenteH_motor_control__T;

/* Parameters (default storage) */
struct P_pwm_puenteH_motor_control_r_T_ {
  real_T Fz[4];                        /* Variable: Fz
                                        * Referenced by: '<Root>/Gain34'
                                        */
  real_T G[2];                         /* Variable: G
                                        * Referenced by: '<Root>/Gain36'
                                        */
  real_T Lz[2];                        /* Variable: Lz
                                        * Referenced by: '<Root>/Gain28'
                                        */
  real_T T;                            /* Variable: T
                                        * Referenced by: '<Root>/Gain35'
                                        */
  real_T f;                            /* Variable: f
                                        * Referenced by: '<Root>/Gain30'
                                        */
  real_T kawp;                         /* Variable: kawp
                                        * Referenced by: '<Root>/Gain1'
                                        */
  real_T kiz;                          /* Variable: kiz
                                        * Referenced by: '<Root>/Gain44'
                                        */
  real_T kz[2];                        /* Variable: kz
                                        * Referenced by: '<Root>/Gain29'
                                        */
  real_T Velocidaddegs_ICPrevScaledInput;
                              /* Mask Parameter: Velocidaddegs_ICPrevScaledInput
                               * Referenced by: '<S4>/UD'
                               */
  real_T Step_Time;                    /* Expression: 0
                                        * Referenced by: '<Root>/Step'
                                        */
  real_T Step_Y0;                      /* Expression: 0
                                        * Referenced by: '<Root>/Step'
                                        */
  real_T Step_YFinal;                  /* Expression: 6
                                        * Referenced by: '<Root>/Step'
                                        */
  real_T EncoderB_SampleTime;          /* Expression: 0.0001
                                        * Referenced by: '<S2>/EncoderB'
                                        */
  real_T EncoderA_SampleTime;          /* Expression: 0.0001
                                        * Referenced by: '<S2>/Encoder A'
                                        */
  real_T EenzPcontinua_InitialCondition;/* Expression: 0
                                         * Referenced by: '<Root>/E en z P continua'
                                         */
  real_T Posiciondeg_InitialCondition; /* Expression: 0
                                        * Referenced by: '<S3>/Posicion (deg)'
                                        */
  real_T x_r_Value;                    /* Expression: 360
                                        * Referenced by: '<Root>/x_r'
                                        */
  real_T IenPCZ_InitialCondition;      /* Expression: 0
                                        * Referenced by: '<Root>/I  en P. C Z'
                                        */
  real_T Saturation_UpperSat;          /* Expression: 12
                                        * Referenced by: '<Root>/Saturation'
                                        */
  real_T Saturation_LowerSat;          /* Expression: -12
                                        * Referenced by: '<Root>/Saturation'
                                        */
  real_T Gain43_Gain;                  /* Expression: 1
                                        * Referenced by: '<Root>/Gain43'
                                        */
  real_T Gain_Gain;                    /* Expression: 100/12
                                        * Referenced by: '<Root>/Gain'
                                        */
  real_T Constant_Value;               /* Expression: 0
                                        * Referenced by: '<S1>/Constant'
                                        */
  real_T TSamp_WtEt;                   /* Computed Parameter: TSamp_WtEt
                                        * Referenced by: '<S4>/TSamp'
                                        */
  real_T DirectLookupTablenD_table[16];
                            /* Expression: [0,-1,1,0,1,0,0,-1,-1,0,0,1,0,1,-1,0]
                             * Referenced by: '<S3>/Direct Lookup Table (n-D)'
                             */
  real_T Constant_Value_n;             /* Expression: 1
                                        * Referenced by: '<S2>/Constant'
                                        */
  real_T Constant1_Value;              /* Expression: 1
                                        * Referenced by: '<S2>/Constant1'
                                        */
  boolean_T UnitDelay_InitialCondition;
                               /* Computed Parameter: UnitDelay_InitialCondition
                                * Referenced by: '<S3>/Unit Delay'
                                */
  boolean_T UnitDelay1_InitialCondition;
                              /* Computed Parameter: UnitDelay1_InitialCondition
                               * Referenced by: '<S3>/Unit Delay1'
                               */
  uint8_T Gain3_Gain;                  /* Computed Parameter: Gain3_Gain
                                        * Referenced by: '<S3>/Gain3'
                                        */
  uint8_T Gain2_Gain;                  /* Computed Parameter: Gain2_Gain
                                        * Referenced by: '<S3>/Gain2'
                                        */
  uint8_T Gain1_Gain;                  /* Computed Parameter: Gain1_Gain
                                        * Referenced by: '<S3>/Gain1'
                                        */
  uint8_T Gain_Gain_o;                 /* Computed Parameter: Gain_Gain_o
                                        * Referenced by: '<S3>/Gain'
                                        */
  uint8_T ManualSwitch_CurrentSetting;
                              /* Computed Parameter: ManualSwitch_CurrentSetting
                               * Referenced by: '<Root>/Manual Switch'
                               */
};

/* Real-time Model Data Structure */
struct tag_RTM_pwm_puenteH_motor_con_T {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    struct {
      uint8_T TID[2];
    } TaskCounters;

    struct {
      boolean_T TID0_1;
    } RateInteraction;

    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block parameters (default storage) */
extern P_pwm_puenteH_motor_control_r_T pwm_puenteH_motor_control_rea_P;

/* Block signals (default storage) */
extern B_pwm_puenteH_motor_control_r_T pwm_puenteH_motor_control_rea_B;

/* Block states (default storage) */
extern DW_pwm_puenteH_motor_control__T pwm_puenteH_motor_control_re_DW;

/* External function called from main */
extern void pwm_puenteH_motor_control_real_antiwindup_SetEventsForThisBaseStep
  (boolean_T *eventFlags);

/* Model entry point functions */
extern void pwm_puenteH_motor_control_real_antiwindup_SetEventsForThisBaseStep
  (boolean_T *eventFlags);
extern void pwm_puenteH_motor_control_real_antiwindup_initialize(void);
extern void pwm_puenteH_motor_control_real_antiwindup_step0(void);
extern void pwm_puenteH_motor_control_real_antiwindup_step1(void);
extern void pwm_puenteH_motor_control_real_antiwindup_terminate(void);

/* Real-time Model object */
extern RT_MODEL_pwm_puenteH_motor_co_T *const pwm_puenteH_motor_control_re_M;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S4>/Data Type Duplicate' : Unused code path elimination
 * Block '<Root>/Zero-Order Hold2' : Eliminated since input and output rates are identical
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'pwm_puenteH_motor_control_real_antiwindup'
 * '<S1>'   : 'pwm_puenteH_motor_control_real_antiwindup/Compare To Zero'
 * '<S2>'   : 'pwm_puenteH_motor_control_real_antiwindup/Motor'
 * '<S3>'   : 'pwm_puenteH_motor_control_real_antiwindup/Motor/Lector encoder'
 * '<S4>'   : 'pwm_puenteH_motor_control_real_antiwindup/Motor/Lector encoder/Velocidad (deg//s)'
 */
#endif             /* RTW_HEADER_pwm_puenteH_motor_control_real_antiwindup_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
