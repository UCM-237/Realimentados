/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: pwm_puenteH_motor_control_real_antiwindup_types.h
 *
 * Code generated for Simulink model 'pwm_puenteH_motor_control_real_antiwindup'.
 *
 * Model version                  : 1.14
 * Simulink Coder version         : 9.1 (R2019a) 23-Nov-2018
 * C/C++ source code generated on : Thu Jan 16 14:51:07 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_pwm_puenteH_motor_control_real_antiwindup_types_h_
#define RTW_HEADER_pwm_puenteH_motor_control_real_antiwindup_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"

/* Custom Type definition for MATLABSystem: '<S2>/PHA' */
#include "MW_SVD.h"
#ifndef typedef_mbed_DigitalWrite_pwm_puenteH_T
#define typedef_mbed_DigitalWrite_pwm_puenteH_T

typedef struct {
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  MW_Handle_Type MW_DIGITALIO_HANDLE;
} mbed_DigitalWrite_pwm_puenteH_T;

#endif                               /*typedef_mbed_DigitalWrite_pwm_puenteH_T*/

#ifndef typedef_mbed_DigitalRead_pwm_puenteH__T
#define typedef_mbed_DigitalRead_pwm_puenteH__T

typedef struct {
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  MW_Handle_Type MW_DIGITALIO_HANDLE;
  real_T SampleTime;
} mbed_DigitalRead_pwm_puenteH__T;

#endif                               /*typedef_mbed_DigitalRead_pwm_puenteH__T*/

#ifndef typedef_mbed_PWMOutput_pwm_puenteH_mo_T
#define typedef_mbed_PWMOutput_pwm_puenteH_mo_T

typedef struct {
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  MW_Handle_Type MW_PWM_HANDLE;
} mbed_PWMOutput_pwm_puenteH_mo_T;

#endif                               /*typedef_mbed_PWMOutput_pwm_puenteH_mo_T*/

/* Parameters (default storage) */
typedef struct P_pwm_puenteH_motor_control_r_T_ P_pwm_puenteH_motor_control_r_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_pwm_puenteH_motor_con_T RT_MODEL_pwm_puenteH_motor_co_T;

#endif       /* RTW_HEADER_pwm_puenteH_motor_control_real_antiwindup_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
