/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: pwm_puenteH_motor_control_real_antiwindup_data.c
 *
 * Code generated for Simulink model 'pwm_puenteH_motor_control_real_antiwindup'.
 *
 * Model version                  : 1.14
 * Simulink Coder version         : 9.1 (R2019a) 23-Nov-2018
 * C/C++ source code generated on : Thu Jan 16 14:51:07 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "pwm_puenteH_motor_control_real_antiwindup.h"
#include "pwm_puenteH_motor_control_real_antiwindup_private.h"

/* Block parameters (default storage) */
P_pwm_puenteH_motor_control_r_T pwm_puenteH_motor_control_rea_P = {
  /* Variable: Fz
   * Referenced by: '<Root>/Gain34'
   */
  { 1.0, 0.0, 9.9750416146353731E-5, 0.99501247919268232 },

  /* Variable: G
   * Referenced by: '<Root>/Gain36'
   */
  { 2.5956720779211778E-5, 0.51870216396103941 },

  /* Variable: Lz
   * Referenced by: '<Root>/Gain28'
   */
  { -0.00099151814198391946, 0.089595883750914845 },

  /* Variable: T
   * Referenced by: '<Root>/Gain35'
   */
  0.0001,

  /* Variable: f
   * Referenced by: '<Root>/Gain30'
   */
  0.1587402754774502,

  /* Variable: kawp
   * Referenced by: '<Root>/Gain1'
   */
  0.1,

  /* Variable: kiz
   * Referenced by: '<Root>/Gain44'
   */
  0.86538398763478719,

  /* Variable: kz
   * Referenced by: '<Root>/Gain29'
   */
  { 0.15874027547744535, 7.92607628423995E-6 },

  /* Mask Parameter: Velocidaddegs_ICPrevScaledInput
   * Referenced by: '<S4>/UD'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<Root>/Step'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<Root>/Step'
   */
  0.0,

  /* Expression: 6
   * Referenced by: '<Root>/Step'
   */
  6.0,

  /* Expression: 0.0001
   * Referenced by: '<S2>/EncoderB'
   */
  0.0001,

  /* Expression: 0.0001
   * Referenced by: '<S2>/Encoder A'
   */
  0.0001,

  /* Expression: 0
   * Referenced by: '<Root>/E en z P continua'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S3>/Posicion (deg)'
   */
  0.0,

  /* Expression: 360
   * Referenced by: '<Root>/x_r'
   */
  360.0,

  /* Expression: 0
   * Referenced by: '<Root>/I  en P. C Z'
   */
  0.0,

  /* Expression: 12
   * Referenced by: '<Root>/Saturation'
   */
  12.0,

  /* Expression: -12
   * Referenced by: '<Root>/Saturation'
   */
  -12.0,

  /* Expression: 1
   * Referenced by: '<Root>/Gain43'
   */
  1.0,

  /* Expression: 100/12
   * Referenced by: '<Root>/Gain'
   */
  8.3333333333333339,

  /* Expression: 0
   * Referenced by: '<S1>/Constant'
   */
  0.0,

  /* Computed Parameter: TSamp_WtEt
   * Referenced by: '<S4>/TSamp'
   */
  100.0,

  /* Expression: [0,-1,1,0,1,0,0,-1,-1,0,0,1,0,1,-1,0]
   * Referenced by: '<S3>/Direct Lookup Table (n-D)'
   */
  { 0.0, -1.0, 1.0, 0.0, 1.0, 0.0, 0.0, -1.0, -1.0, 0.0, 0.0, 1.0, 0.0, 1.0,
    -1.0, 0.0 },

  /* Expression: 1
   * Referenced by: '<S2>/Constant'
   */
  1.0,

  /* Expression: 1
   * Referenced by: '<S2>/Constant1'
   */
  1.0,

  /* Computed Parameter: UnitDelay_InitialCondition
   * Referenced by: '<S3>/Unit Delay'
   */
  0,

  /* Computed Parameter: UnitDelay1_InitialCondition
   * Referenced by: '<S3>/Unit Delay1'
   */
  0,

  /* Computed Parameter: Gain3_Gain
   * Referenced by: '<S3>/Gain3'
   */
  128U,

  /* Computed Parameter: Gain2_Gain
   * Referenced by: '<S3>/Gain2'
   */
  128U,

  /* Computed Parameter: Gain1_Gain
   * Referenced by: '<S3>/Gain1'
   */
  128U,

  /* Computed Parameter: Gain_Gain_o
   * Referenced by: '<S3>/Gain'
   */
  128U,

  /* Computed Parameter: ManualSwitch_CurrentSetting
   * Referenced by: '<Root>/Manual Switch'
   */
  0U
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
