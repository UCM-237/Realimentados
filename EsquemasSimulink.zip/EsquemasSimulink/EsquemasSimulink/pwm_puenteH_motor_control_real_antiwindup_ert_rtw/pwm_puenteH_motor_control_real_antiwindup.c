/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: pwm_puenteH_motor_control_real_antiwindup.c
 *
 * Code generated for Simulink model 'pwm_puenteH_motor_control_real_antiwindup'.
 *
 * Model version                  : 1.14
 * Simulink Coder version         : 9.1 (R2019a) 23-Nov-2018
 * C/C++ source code generated on : Thu Jan 16 14:51:07 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "pwm_puenteH_motor_control_real_antiwindup.h"
#include "pwm_puenteH_motor_control_real_antiwindup_private.h"

/* Block signals (default storage) */
B_pwm_puenteH_motor_control_r_T pwm_puenteH_motor_control_rea_B;

/* Block states (default storage) */
DW_pwm_puenteH_motor_control__T pwm_puenteH_motor_control_re_DW;

/* Real-time model */
RT_MODEL_pwm_puenteH_motor_co_T pwm_puenteH_motor_control_re_M_;
RT_MODEL_pwm_puenteH_motor_co_T *const pwm_puenteH_motor_control_re_M =
  &pwm_puenteH_motor_control_re_M_;

/* Forward declaration for local functions */
static void pwm_puenteH__SystemCore_release(const
  mbed_DigitalWrite_pwm_puenteH_T *obj);
static void pwm_puenteH_m_SystemCore_delete(const
  mbed_DigitalWrite_pwm_puenteH_T *obj);
static void matlabCodegenHandle_matlabCodeg(mbed_DigitalWrite_pwm_puenteH_T *obj);
static void pwm_pue_SystemCore_release_ghed(const
  mbed_PWMOutput_pwm_puenteH_mo_T *obj);
static void pwm_puen_SystemCore_delete_ghed(const
  mbed_PWMOutput_pwm_puenteH_mo_T *obj);
static void matlabCodegenHandle_matlab_ghed(mbed_PWMOutput_pwm_puenteH_mo_T *obj);
static void pwm_puent_SystemCore_release_gh(const
  mbed_DigitalRead_pwm_puenteH__T *obj);
static void pwm_puente_SystemCore_delete_gh(const
  mbed_DigitalRead_pwm_puenteH__T *obj);
static void matlabCodegenHandle_matlabCo_gh(mbed_DigitalRead_pwm_puenteH__T *obj);
static void rate_monotonic_scheduler(void);

/*
 * Set which subrates need to run this base step (base rate always runs).
 * This function must be called prior to calling the model step function
 * in order to "remember" which rates need to run this base step.  The
 * buffering of events allows for overlapping preemption.
 */
void pwm_puenteH_motor_control_real_antiwindup_SetEventsForThisBaseStep
  (boolean_T *eventFlags)
{
  /* Task runs when its counter is zero, computed via rtmStepTask macro */
  eventFlags[1] = ((boolean_T)rtmStepTask(pwm_puenteH_motor_control_re_M, 1));
}

/*
 *   This function updates active task flag for each subrate
 * and rate transition flags for tasks that exchange data.
 * The function assumes rate-monotonic multitasking scheduler.
 * The function must be called at model base rate so that
 * the generated code self-manages all its subrates and rate
 * transition flags.
 */
static void rate_monotonic_scheduler(void)
{
  /* To ensure a deterministic data transfer between two rates,
   * data is transferred at the priority of a fast task and the frequency
   * of the slow task.  The following flags indicate when the data transfer
   * happens.  That is, a rate interaction flag is set true when both rates
   * will run, and false otherwise.
   */

  /* tid 0 shares data with slower tid rate: 1 */
  pwm_puenteH_motor_control_re_M->Timing.RateInteraction.TID0_1 =
    (pwm_puenteH_motor_control_re_M->Timing.TaskCounters.TID[1] == 0);

  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (pwm_puenteH_motor_control_re_M->Timing.TaskCounters.TID[1])++;
  if ((pwm_puenteH_motor_control_re_M->Timing.TaskCounters.TID[1]) > 99) {/* Sample time: [0.01s, 0.0s] */
    pwm_puenteH_motor_control_re_M->Timing.TaskCounters.TID[1] = 0;
  }
}

static void pwm_puenteH__SystemCore_release(const
  mbed_DigitalWrite_pwm_puenteH_T *obj)
{
  if ((obj->isInitialized == 1) && obj->isSetupComplete) {
    MW_digitalIO_close(obj->MW_DIGITALIO_HANDLE);
  }
}

static void pwm_puenteH_m_SystemCore_delete(const
  mbed_DigitalWrite_pwm_puenteH_T *obj)
{
  pwm_puenteH__SystemCore_release(obj);
}

static void matlabCodegenHandle_matlabCodeg(mbed_DigitalWrite_pwm_puenteH_T *obj)
{
  if (!obj->matlabCodegenIsDeleted) {
    obj->matlabCodegenIsDeleted = true;
    pwm_puenteH_m_SystemCore_delete(obj);
  }
}

static void pwm_pue_SystemCore_release_ghed(const
  mbed_PWMOutput_pwm_puenteH_mo_T *obj)
{
  if ((obj->isInitialized == 1) && obj->isSetupComplete) {
    MW_PWM_Stop(obj->MW_PWM_HANDLE);
    MW_PWM_Close(obj->MW_PWM_HANDLE);
  }
}

static void pwm_puen_SystemCore_delete_ghed(const
  mbed_PWMOutput_pwm_puenteH_mo_T *obj)
{
  pwm_pue_SystemCore_release_ghed(obj);
}

static void matlabCodegenHandle_matlab_ghed(mbed_PWMOutput_pwm_puenteH_mo_T *obj)
{
  if (!obj->matlabCodegenIsDeleted) {
    obj->matlabCodegenIsDeleted = true;
    pwm_puen_SystemCore_delete_ghed(obj);
  }
}

static void pwm_puent_SystemCore_release_gh(const
  mbed_DigitalRead_pwm_puenteH__T *obj)
{
  if ((obj->isInitialized == 1) && obj->isSetupComplete) {
    MW_digitalIO_close(obj->MW_DIGITALIO_HANDLE);
  }
}

static void pwm_puente_SystemCore_delete_gh(const
  mbed_DigitalRead_pwm_puenteH__T *obj)
{
  pwm_puent_SystemCore_release_gh(obj);
}

static void matlabCodegenHandle_matlabCo_gh(mbed_DigitalRead_pwm_puenteH__T *obj)
{
  if (!obj->matlabCodegenIsDeleted) {
    obj->matlabCodegenIsDeleted = true;
    pwm_puente_SystemCore_delete_gh(obj);
  }
}

/* Model step function for TID0 */
void pwm_puenteH_motor_control_real_antiwindup_step0(void) /* Sample time: [0.0001s, 0.0s] */
{
  real_T rtb_DirectLookupTablenD;

  {                                    /* Sample time: [0.0001s, 0.0s] */
    rate_monotonic_scheduler();
  }

  /* UnitDelay: '<Root>/E en z P continua' */
  pwm_puenteH_motor_control_rea_B.EenzPcontinua[0] =
    pwm_puenteH_motor_control_re_DW.EenzPcontinua_DSTATE[0];
  pwm_puenteH_motor_control_rea_B.EenzPcontinua[1] =
    pwm_puenteH_motor_control_re_DW.EenzPcontinua_DSTATE[1];

  /* UnitDelay: '<S3>/Posicion (deg)' */
  pwm_puenteH_motor_control_rea_B.Posiciondeg =
    pwm_puenteH_motor_control_re_DW.Posiciondeg_DSTATE;

  /* Constant: '<Root>/x_r' */
  pwm_puenteH_motor_control_rea_B.x_r =
    pwm_puenteH_motor_control_rea_P.x_r_Value;

  /* Sum: '<Root>/Sum14' incorporates:
   *  Gain: '<Root>/Gain29'
   *  Gain: '<Root>/Gain30'
   *  Gain: '<Root>/Gain44'
   *  Sum: '<Root>/Sum25'
   *  UnitDelay: '<Root>/I  en P. C Z'
   */
  pwm_puenteH_motor_control_rea_B.ZeroOrderHold =
    (pwm_puenteH_motor_control_rea_P.f * pwm_puenteH_motor_control_rea_B.x_r -
     pwm_puenteH_motor_control_rea_P.kiz *
     pwm_puenteH_motor_control_re_DW.IenPCZ_DSTATE) -
    (pwm_puenteH_motor_control_rea_P.kz[0] *
     pwm_puenteH_motor_control_rea_B.EenzPcontinua[0] +
     pwm_puenteH_motor_control_rea_P.kz[1] *
     pwm_puenteH_motor_control_rea_B.EenzPcontinua[1]);

  /* Sum: '<Root>/Sum13' incorporates:
   *  Gain: '<Root>/Gain28'
   *  Gain: '<Root>/Gain34'
   *  Gain: '<Root>/Gain36'
   *  UnitDelay: '<Root>/E en z P continua'
   */
  pwm_puenteH_motor_control_re_DW.EenzPcontinua_DSTATE[0] =
    ((pwm_puenteH_motor_control_rea_P.Fz[0] - -0.00099151814198391946) *
     pwm_puenteH_motor_control_rea_B.EenzPcontinua[0] +
     pwm_puenteH_motor_control_rea_P.Fz[2] *
     pwm_puenteH_motor_control_rea_B.EenzPcontinua[1]) +
    (pwm_puenteH_motor_control_rea_P.G[0] *
     pwm_puenteH_motor_control_rea_B.ZeroOrderHold +
     pwm_puenteH_motor_control_rea_P.Lz[0] *
     pwm_puenteH_motor_control_rea_B.Posiciondeg);
  pwm_puenteH_motor_control_re_DW.EenzPcontinua_DSTATE[1] =
    ((pwm_puenteH_motor_control_rea_P.Fz[1] - 0.089595883750914845) *
     pwm_puenteH_motor_control_rea_B.EenzPcontinua[0] +
     pwm_puenteH_motor_control_rea_P.Fz[3] *
     pwm_puenteH_motor_control_rea_B.EenzPcontinua[1]) +
    (pwm_puenteH_motor_control_rea_P.G[1] *
     pwm_puenteH_motor_control_rea_B.ZeroOrderHold +
     pwm_puenteH_motor_control_rea_P.Lz[1] *
     pwm_puenteH_motor_control_rea_B.Posiciondeg);

  /* Saturate: '<Root>/Saturation' */
  if (pwm_puenteH_motor_control_rea_B.ZeroOrderHold >
      pwm_puenteH_motor_control_rea_P.Saturation_UpperSat) {
    rtb_DirectLookupTablenD =
      pwm_puenteH_motor_control_rea_P.Saturation_UpperSat;
  } else if (pwm_puenteH_motor_control_rea_B.ZeroOrderHold <
             pwm_puenteH_motor_control_rea_P.Saturation_LowerSat) {
    rtb_DirectLookupTablenD =
      pwm_puenteH_motor_control_rea_P.Saturation_LowerSat;
  } else {
    rtb_DirectLookupTablenD = pwm_puenteH_motor_control_rea_B.ZeroOrderHold;
  }

  /* End of Saturate: '<Root>/Saturation' */

  /* Gain: '<Root>/Gain1' incorporates:
   *  Sum: '<Root>/Sum1'
   */
  pwm_puenteH_motor_control_rea_B.Gain1 = (rtb_DirectLookupTablenD -
    pwm_puenteH_motor_control_rea_B.ZeroOrderHold) *
    pwm_puenteH_motor_control_rea_P.kawp;

  /* Sum: '<Root>/Sum27' incorporates:
   *  Gain: '<Root>/Gain35'
   *  Gain: '<Root>/Gain43'
   *  Sum: '<Root>/Sum26'
   *  UnitDelay: '<Root>/I  en P. C Z'
   */
  pwm_puenteH_motor_control_re_DW.IenPCZ_DSTATE =
    ((pwm_puenteH_motor_control_rea_B.Posiciondeg -
      pwm_puenteH_motor_control_rea_B.x_r) -
     pwm_puenteH_motor_control_rea_B.Gain1) * pwm_puenteH_motor_control_rea_P.T
    + pwm_puenteH_motor_control_rea_P.Gain43_Gain *
    pwm_puenteH_motor_control_re_DW.IenPCZ_DSTATE;

  /* ManualSwitch: '<Root>/Manual Switch' */
  if (pwm_puenteH_motor_control_rea_P.ManualSwitch_CurrentSetting == 1) {
    /* Step: '<Root>/Step' */
    if (pwm_puenteH_motor_control_re_M->Timing.taskTime0 <
        pwm_puenteH_motor_control_rea_P.Step_Time) {
      pwm_puenteH_motor_control_rea_B.ZeroOrderHold =
        pwm_puenteH_motor_control_rea_P.Step_Y0;
    } else {
      pwm_puenteH_motor_control_rea_B.ZeroOrderHold =
        pwm_puenteH_motor_control_rea_P.Step_YFinal;
    }

    /* End of Step: '<Root>/Step' */
  }

  /* End of ManualSwitch: '<Root>/Manual Switch' */
  /* Gain: '<Root>/Gain' */
  rtb_DirectLookupTablenD = pwm_puenteH_motor_control_rea_P.Gain_Gain *
    pwm_puenteH_motor_control_rea_B.ZeroOrderHold;

  /* MATLABSystem: '<S2>/PHA' incorporates:
   *  Constant: '<S1>/Constant'
   *  RelationalOperator: '<S1>/Compare'
   */
  MW_digitalIO_write(pwm_puenteH_motor_control_re_DW.obj_d.MW_DIGITALIO_HANDLE,
                     rtb_DirectLookupTablenD >=
                     pwm_puenteH_motor_control_rea_P.Constant_Value);

  /* MATLABSystem: '<S2>/PWDA' incorporates:
   *  Abs: '<Root>/Abs'
   */
  MW_PWM_SetDutyCycle(pwm_puenteH_motor_control_re_DW.obj_c.MW_PWM_HANDLE, fabs
                      (rtb_DirectLookupTablenD));

  /* ZeroOrderHold: '<S3>/Zero-Order Hold' */
  if (pwm_puenteH_motor_control_re_M->Timing.RateInteraction.TID0_1) {
    pwm_puenteH_motor_control_rea_B.ZeroOrderHold_c =
      pwm_puenteH_motor_control_rea_B.Posiciondeg;
  }

  /* End of ZeroOrderHold: '<S3>/Zero-Order Hold' */

  /* MATLABSystem: '<S2>/Encoder A' */
  if (pwm_puenteH_motor_control_re_DW.obj.SampleTime !=
      pwm_puenteH_motor_control_rea_P.EncoderA_SampleTime) {
    pwm_puenteH_motor_control_re_DW.obj.SampleTime =
      pwm_puenteH_motor_control_rea_P.EncoderA_SampleTime;
  }

  pwm_puenteH_motor_control_rea_B.EncoderA = MW_digitalIO_read
    (pwm_puenteH_motor_control_re_DW.obj.MW_DIGITALIO_HANDLE);

  /* End of MATLABSystem: '<S2>/Encoder A' */

  /* MATLABSystem: '<S2>/EncoderB' */
  if (pwm_puenteH_motor_control_re_DW.obj_p.SampleTime !=
      pwm_puenteH_motor_control_rea_P.EncoderB_SampleTime) {
    pwm_puenteH_motor_control_re_DW.obj_p.SampleTime =
      pwm_puenteH_motor_control_rea_P.EncoderB_SampleTime;
  }

  pwm_puenteH_motor_control_rea_B.EncoderB = MW_digitalIO_read
    (pwm_puenteH_motor_control_re_DW.obj_p.MW_DIGITALIO_HANDLE);

  /* End of MATLABSystem: '<S2>/EncoderB' */

  /* LookupNDDirect: '<S3>/Direct Lookup Table (n-D)' incorporates:
   *  Gain: '<S3>/Gain'
   *  Gain: '<S3>/Gain1'
   *  Gain: '<S3>/Gain2'
   *  Gain: '<S3>/Gain3'
   *  Sum: '<S3>/Sum'
   *  UnitDelay: '<S3>/Unit Delay'
   *  UnitDelay: '<S3>/Unit Delay1'
   *
   * About '<S3>/Direct Lookup Table (n-D)':
   *  1-dimensional Direct Look-Up returning a Scalar,
   */
  rtb_DirectLookupTablenD = (((real_T)
    (pwm_puenteH_motor_control_re_DW.UnitDelay_DSTATE ? (int32_T)
     pwm_puenteH_motor_control_rea_P.Gain3_Gain : 0) * 0.0625 + (real_T)
    (pwm_puenteH_motor_control_rea_B.EncoderA ? (int32_T)
     pwm_puenteH_motor_control_rea_P.Gain2_Gain : 0) * 0.03125) + (real_T)
    (pwm_puenteH_motor_control_re_DW.UnitDelay1_DSTATE ? (int32_T)
     pwm_puenteH_motor_control_rea_P.Gain1_Gain : 0) * 0.015625) + (real_T)
    (pwm_puenteH_motor_control_rea_B.EncoderB ? (int32_T)
     pwm_puenteH_motor_control_rea_P.Gain_Gain_o : 0) * 0.0078125;
  if (rtb_DirectLookupTablenD > 15.0) {
    rtb_DirectLookupTablenD = 15.0;
  }

  /* Sum: '<S3>/Sum1' incorporates:
   *  LookupNDDirect: '<S3>/Direct Lookup Table (n-D)'
   *  UnitDelay: '<S3>/Posicion (deg)'
   *
   * About '<S3>/Direct Lookup Table (n-D)':
   *  1-dimensional Direct Look-Up returning a Scalar,
   */
  pwm_puenteH_motor_control_re_DW.Posiciondeg_DSTATE =
    pwm_puenteH_motor_control_rea_P.DirectLookupTablenD_table[(int32_T)
    rtb_DirectLookupTablenD] + pwm_puenteH_motor_control_rea_B.Posiciondeg;

  /* MATLABSystem: '<S2>/ENA' incorporates:
   *  Constant: '<S2>/Constant'
   */
  MW_digitalIO_write(pwm_puenteH_motor_control_re_DW.obj_a.MW_DIGITALIO_HANDLE,
                     pwm_puenteH_motor_control_rea_P.Constant_Value_n != 0.0);

  /* MATLABSystem: '<S2>/ENB' incorporates:
   *  Constant: '<S2>/Constant1'
   */
  MW_digitalIO_write(pwm_puenteH_motor_control_re_DW.obj_h.MW_DIGITALIO_HANDLE,
                     pwm_puenteH_motor_control_rea_P.Constant1_Value != 0.0);

  /* Update for UnitDelay: '<S3>/Unit Delay' */
  pwm_puenteH_motor_control_re_DW.UnitDelay_DSTATE =
    pwm_puenteH_motor_control_rea_B.EncoderA;

  /* Update for UnitDelay: '<S3>/Unit Delay1' */
  pwm_puenteH_motor_control_re_DW.UnitDelay1_DSTATE =
    pwm_puenteH_motor_control_rea_B.EncoderB;

  /* External mode */
  rtExtModeUploadCheckTrigger(2);
  rtExtModeUpload(0, (real_T)pwm_puenteH_motor_control_re_M->Timing.taskTime0);

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.0001s, 0.0s] */
    if ((rtmGetTFinal(pwm_puenteH_motor_control_re_M)!=-1) &&
        !((rtmGetTFinal(pwm_puenteH_motor_control_re_M)-
           pwm_puenteH_motor_control_re_M->Timing.taskTime0) >
          pwm_puenteH_motor_control_re_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(pwm_puenteH_motor_control_re_M, "Simulation finished");
    }

    if (rtmGetStopRequested(pwm_puenteH_motor_control_re_M)) {
      rtmSetErrorStatus(pwm_puenteH_motor_control_re_M, "Simulation finished");
    }
  }

  /* Update absolute time */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  pwm_puenteH_motor_control_re_M->Timing.taskTime0 =
    (++pwm_puenteH_motor_control_re_M->Timing.clockTick0) *
    pwm_puenteH_motor_control_re_M->Timing.stepSize0;
}

/* Model step function for TID1 */
void pwm_puenteH_motor_control_real_antiwindup_step1(void) /* Sample time: [0.01s, 0.0s] */
{
  real_T rtb_TSamp;

  /* SampleTimeMath: '<S4>/TSamp'
   *
   * About '<S4>/TSamp':
   *  y = u * K where K = 1 / ( w * Ts )
   */
  rtb_TSamp = pwm_puenteH_motor_control_rea_B.ZeroOrderHold_c *
    pwm_puenteH_motor_control_rea_P.TSamp_WtEt;

  /* Sum: '<S4>/Diff' incorporates:
   *  UnitDelay: '<S4>/UD'
   *
   * Block description for '<S4>/Diff':
   *
   *  Add in CPU
   *
   * Block description for '<S4>/UD':
   *
   *  Store in Global RAM
   */
  pwm_puenteH_motor_control_rea_B.Diff = rtb_TSamp -
    pwm_puenteH_motor_control_re_DW.UD_DSTATE;

  /* Update for UnitDelay: '<S4>/UD'
   *
   * Block description for '<S4>/UD':
   *
   *  Store in Global RAM
   */
  pwm_puenteH_motor_control_re_DW.UD_DSTATE = rtb_TSamp;
  rtExtModeUpload(1, (real_T)((pwm_puenteH_motor_control_re_M->Timing.clockTick1)
    * 0.01));

  /* Update absolute time */
  /* The "clockTick1" counts the number of times the code of this task has
   * been executed. The resolution of this integer timer is 0.01, which is the step size
   * of the task. Size of "clockTick1" ensures timer will not overflow during the
   * application lifespan selected.
   */
  pwm_puenteH_motor_control_re_M->Timing.clockTick1++;
}

/* Model initialize function */
void pwm_puenteH_motor_control_real_antiwindup_initialize(void)
{
  /* Registration code */

  /* initialize real-time model */
  (void) memset((void *)pwm_puenteH_motor_control_re_M, 0,
                sizeof(RT_MODEL_pwm_puenteH_motor_co_T));
  rtmSetTFinal(pwm_puenteH_motor_control_re_M, 5.0);
  pwm_puenteH_motor_control_re_M->Timing.stepSize0 = 0.0001;

  /* External mode info */
  pwm_puenteH_motor_control_re_M->Sizes.checksums[0] = (3060149795U);
  pwm_puenteH_motor_control_re_M->Sizes.checksums[1] = (1253678357U);
  pwm_puenteH_motor_control_re_M->Sizes.checksums[2] = (2355945932U);
  pwm_puenteH_motor_control_re_M->Sizes.checksums[3] = (1522441282U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[8];
    pwm_puenteH_motor_control_re_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = &rtAlwaysEnabled;
    systemRan[3] = &rtAlwaysEnabled;
    systemRan[4] = &rtAlwaysEnabled;
    systemRan[5] = &rtAlwaysEnabled;
    systemRan[6] = &rtAlwaysEnabled;
    systemRan[7] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(pwm_puenteH_motor_control_re_M->extModeInfo,
      &pwm_puenteH_motor_control_re_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(pwm_puenteH_motor_control_re_M->extModeInfo,
                        pwm_puenteH_motor_control_re_M->Sizes.checksums);
    rteiSetTPtr(pwm_puenteH_motor_control_re_M->extModeInfo, rtmGetTPtr
                (pwm_puenteH_motor_control_re_M));
  }

  /* block I/O */
  (void) memset(((void *) &pwm_puenteH_motor_control_rea_B), 0,
                sizeof(B_pwm_puenteH_motor_control_r_T));

  /* states (dwork) */
  (void) memset((void *)&pwm_puenteH_motor_control_re_DW, 0,
                sizeof(DW_pwm_puenteH_motor_control__T));

  {
    mbed_DigitalWrite_pwm_puenteH_T *obj;
    uint32_T pinname;
    mbed_PWMOutput_pwm_puenteH_mo_T *obj_0;
    mbed_DigitalRead_pwm_puenteH__T *obj_1;

    /* Start for MATLABSystem: '<S2>/PHA' */
    pwm_puenteH_motor_control_re_DW.obj_d.matlabCodegenIsDeleted = true;
    pwm_puenteH_motor_control_re_DW.obj_d.isInitialized = 0;
    pwm_puenteH_motor_control_re_DW.obj_d.matlabCodegenIsDeleted = false;
    obj = &pwm_puenteH_motor_control_re_DW.obj_d;
    pwm_puenteH_motor_control_re_DW.obj_d.isSetupComplete = false;
    pwm_puenteH_motor_control_re_DW.obj_d.isInitialized = 1;
    pinname = D3;
    obj->MW_DIGITALIO_HANDLE = MW_digitalIO_open(pinname, 1);
    pwm_puenteH_motor_control_re_DW.obj_d.isSetupComplete = true;

    /* Start for MATLABSystem: '<S2>/PWDA' */
    pwm_puenteH_motor_control_re_DW.obj_c.matlabCodegenIsDeleted = true;
    pwm_puenteH_motor_control_re_DW.obj_c.isInitialized = 0;
    pwm_puenteH_motor_control_re_DW.obj_c.matlabCodegenIsDeleted = false;
    obj_0 = &pwm_puenteH_motor_control_re_DW.obj_c;
    pwm_puenteH_motor_control_re_DW.obj_c.isSetupComplete = false;
    pwm_puenteH_motor_control_re_DW.obj_c.isInitialized = 1;
    pinname = D5;
    obj_0->MW_PWM_HANDLE = MW_PWM_Open(pinname, 10000.0, 0.0);
    MW_PWM_Start(pwm_puenteH_motor_control_re_DW.obj_c.MW_PWM_HANDLE);
    pwm_puenteH_motor_control_re_DW.obj_c.isSetupComplete = true;

    /* Start for MATLABSystem: '<S2>/Encoder A' */
    pwm_puenteH_motor_control_re_DW.obj.matlabCodegenIsDeleted = true;
    pwm_puenteH_motor_control_re_DW.obj.isInitialized = 0;
    pwm_puenteH_motor_control_re_DW.obj.SampleTime = -1.0;
    pwm_puenteH_motor_control_re_DW.obj.matlabCodegenIsDeleted = false;
    pwm_puenteH_motor_control_re_DW.obj.SampleTime =
      pwm_puenteH_motor_control_rea_P.EncoderA_SampleTime;
    obj_1 = &pwm_puenteH_motor_control_re_DW.obj;
    pwm_puenteH_motor_control_re_DW.obj.isSetupComplete = false;
    pwm_puenteH_motor_control_re_DW.obj.isInitialized = 1;
    pinname = D13;
    obj_1->MW_DIGITALIO_HANDLE = MW_digitalIO_open(pinname, 0);
    pwm_puenteH_motor_control_re_DW.obj.isSetupComplete = true;

    /* Start for MATLABSystem: '<S2>/EncoderB' */
    pwm_puenteH_motor_control_re_DW.obj_p.matlabCodegenIsDeleted = true;
    pwm_puenteH_motor_control_re_DW.obj_p.isInitialized = 0;
    pwm_puenteH_motor_control_re_DW.obj_p.SampleTime = -1.0;
    pwm_puenteH_motor_control_re_DW.obj_p.matlabCodegenIsDeleted = false;
    pwm_puenteH_motor_control_re_DW.obj_p.SampleTime =
      pwm_puenteH_motor_control_rea_P.EncoderB_SampleTime;
    obj_1 = &pwm_puenteH_motor_control_re_DW.obj_p;
    pwm_puenteH_motor_control_re_DW.obj_p.isSetupComplete = false;
    pwm_puenteH_motor_control_re_DW.obj_p.isInitialized = 1;
    pinname = D12;
    obj_1->MW_DIGITALIO_HANDLE = MW_digitalIO_open(pinname, 0);
    pwm_puenteH_motor_control_re_DW.obj_p.isSetupComplete = true;

    /* Start for MATLABSystem: '<S2>/ENA' */
    pwm_puenteH_motor_control_re_DW.obj_a.matlabCodegenIsDeleted = true;
    pwm_puenteH_motor_control_re_DW.obj_a.isInitialized = 0;
    pwm_puenteH_motor_control_re_DW.obj_a.matlabCodegenIsDeleted = false;
    obj = &pwm_puenteH_motor_control_re_DW.obj_a;
    pwm_puenteH_motor_control_re_DW.obj_a.isSetupComplete = false;
    pwm_puenteH_motor_control_re_DW.obj_a.isInitialized = 1;
    pinname = D2;
    obj->MW_DIGITALIO_HANDLE = MW_digitalIO_open(pinname, 1);
    pwm_puenteH_motor_control_re_DW.obj_a.isSetupComplete = true;

    /* Start for MATLABSystem: '<S2>/ENB' */
    pwm_puenteH_motor_control_re_DW.obj_h.matlabCodegenIsDeleted = true;
    pwm_puenteH_motor_control_re_DW.obj_h.isInitialized = 0;
    pwm_puenteH_motor_control_re_DW.obj_h.matlabCodegenIsDeleted = false;
    obj = &pwm_puenteH_motor_control_re_DW.obj_h;
    pwm_puenteH_motor_control_re_DW.obj_h.isSetupComplete = false;
    pwm_puenteH_motor_control_re_DW.obj_h.isInitialized = 1;
    pinname = D11;
    obj->MW_DIGITALIO_HANDLE = MW_digitalIO_open(pinname, 1);
    pwm_puenteH_motor_control_re_DW.obj_h.isSetupComplete = true;

    /* InitializeConditions for UnitDelay: '<Root>/E en z P continua' */
    pwm_puenteH_motor_control_re_DW.EenzPcontinua_DSTATE[0] =
      pwm_puenteH_motor_control_rea_P.EenzPcontinua_InitialCondition;
    pwm_puenteH_motor_control_re_DW.EenzPcontinua_DSTATE[1] =
      pwm_puenteH_motor_control_rea_P.EenzPcontinua_InitialCondition;

    /* InitializeConditions for UnitDelay: '<S3>/Posicion (deg)' */
    pwm_puenteH_motor_control_re_DW.Posiciondeg_DSTATE =
      pwm_puenteH_motor_control_rea_P.Posiciondeg_InitialCondition;

    /* InitializeConditions for UnitDelay: '<Root>/I  en P. C Z' */
    pwm_puenteH_motor_control_re_DW.IenPCZ_DSTATE =
      pwm_puenteH_motor_control_rea_P.IenPCZ_InitialCondition;

    /* InitializeConditions for UnitDelay: '<S4>/UD'
     *
     * Block description for '<S4>/UD':
     *
     *  Store in Global RAM
     */
    pwm_puenteH_motor_control_re_DW.UD_DSTATE =
      pwm_puenteH_motor_control_rea_P.Velocidaddegs_ICPrevScaledInput;

    /* InitializeConditions for UnitDelay: '<S3>/Unit Delay' */
    pwm_puenteH_motor_control_re_DW.UnitDelay_DSTATE =
      pwm_puenteH_motor_control_rea_P.UnitDelay_InitialCondition;

    /* InitializeConditions for UnitDelay: '<S3>/Unit Delay1' */
    pwm_puenteH_motor_control_re_DW.UnitDelay1_DSTATE =
      pwm_puenteH_motor_control_rea_P.UnitDelay1_InitialCondition;
  }
}

/* Model terminate function */
void pwm_puenteH_motor_control_real_antiwindup_terminate(void)
{
  /* Terminate for MATLABSystem: '<S2>/PHA' */
  matlabCodegenHandle_matlabCodeg(&pwm_puenteH_motor_control_re_DW.obj_d);

  /* Terminate for MATLABSystem: '<S2>/PWDA' */
  matlabCodegenHandle_matlab_ghed(&pwm_puenteH_motor_control_re_DW.obj_c);

  /* Terminate for MATLABSystem: '<S2>/Encoder A' */
  matlabCodegenHandle_matlabCo_gh(&pwm_puenteH_motor_control_re_DW.obj);

  /* Terminate for MATLABSystem: '<S2>/EncoderB' */
  matlabCodegenHandle_matlabCo_gh(&pwm_puenteH_motor_control_re_DW.obj_p);

  /* Terminate for MATLABSystem: '<S2>/ENA' */
  matlabCodegenHandle_matlabCodeg(&pwm_puenteH_motor_control_re_DW.obj_a);

  /* Terminate for MATLABSystem: '<S2>/ENB' */
  matlabCodegenHandle_matlabCodeg(&pwm_puenteH_motor_control_re_DW.obj_h);
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
