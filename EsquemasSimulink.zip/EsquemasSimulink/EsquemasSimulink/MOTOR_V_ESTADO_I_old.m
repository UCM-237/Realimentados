%Motor en varibles de estado
clear all
close all
km = 100;
p = 55;
vmotor = tf(km,[1 p]); %velocidad simple
pmotor = tf(1,[1 0])*vmotor;  %posicion motor

%Matrices del sistema x1 es posicion y x2 es velocidad
A = [0 1;0 -p];
B = [0;km];
C = [1 0];
D = 0;
pmotors = ss(A,B,C,D);

step(pmotor)
hold on
step(pmotors)

%ampliamos para a�adir acci�n integral
AI = [A [0;0]; C 0];
BI = [B;0];

%ponemos con acker unos polos lentos para empezar
ka = acker(AI,BI,[-40 -40 -3]); %el tercer polo es para la acc integral
%y unos polos al observador mas rapidos
L =acker(A',C', [-60,-60])';
%separo las ganancias para elegir o no la accion integral
ki = ka(end);
k = ka(1:2);
%monto sistema completo....
Aam = [A -B*ki -B*k; C 0 0 0; L*C -B*ki A-B*k-L*C];

%calculamos feedforward
F = inv(C*inv(B*k(1:2)-A)*B);
Bam =[B*F;-1;B*F] ;
Cam =[C 0 0 0];
sysobsF = ss(Aam,Bam,Cam,D);
[y,t,x] = step(sysobsF);
figure
plot(t,x)
legend
hold on

%Discretizamos
T = 1e-4;
pmotorz =c2d(pmotors,T);
Gz = pmotorz.A;
Hz = pmotorz.B;
Cz = pmotorz.C;
%ampliamos para a�adir acci�n integral
FzI = [Gz [0;0]; T*Cz 1];
GI = [Hz;0];
kz = acker(FzI,GI,[exp(-40*T),exp(-40*T), exp(-3*T)]);
Lz =acker(Gz',Cz',[exp(-60*T),exp(-60*T)])';
%separo ganancia accion integral
kiz =  kz(end);
kz = kz(1:2);
%monto sistema completo....
Fam = [Gz -Hz*kiz -Hz*kz; T*Cz 1 0 0; Lz*Cz -Hz*kiz Gz-Hz*kz-Lz*Cz];
%calulamos feedforward (si metemos el mismo valor no calculado en continuo
%y en discreto, las din�micas no seran las mismas aunque si el resultado
%final. Habria que ajustar la relacion si se quiere reproducir un
%comportamiento del modelo continuo al discreto
%f = inv(Cz*inv(eye(size(Gz))-(Gz-Hz*kz))*Hz);
%Forma alternativa basada en obtenre f para que iguale la salida del modelo
%continuo. La similitud se perdera si el muestreo es muy lento...
f= - inv(Cz*inv(eye(size(Gz))-(Gz-Hz*kz))*Hz)*C*inv(A-B*k)*B*F;
Gam =[Hz*f;-T;Hz*f]; 
Camz =[Cz 0 0 0];


sysobsz = ss(Fam,Gam,Camz,D,T);
[yz,tz,xz]=step(sysobsz);
plot(tz,xz)








