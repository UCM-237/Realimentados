clc
clear all
p = 55
k_e = 100
A=[0,1;0,-55];B=[0;100];C=[1,0];D=0;
n=length(A);OB=obsv(A,C);CO=ctrb(A,B);
if rank(OB)==n && rank(CO)==n
    K=acker(A,B,[-25,-25]);L=acker(A',C',[-60,-60])';F=inv(-C*inv(A-B*K)*B);
end

Gp=tf(ss(A,B,C,D));[numGp,denGp]=tfdata(Gp,'v');
Gc=tf(ss(A-B*K-L*C,L,K,0));[numGc,denGc]=tfdata(Gc,'v');
Gr=tf(ss(A-B*K-L*C,B*F,-K,F));[numGr,denGr]=tfdata(Gr,'v');
Gr2=K*inv(-A+B*K+L*C)*L;

Gcd=c2d(Gc,0.0001);[numGcd,denGcd]=tfdata(Gcd,'v');
Gpd=c2d(Gp,0.0001);[numGpd,denGpd]=tfdata(Gpd,'v');