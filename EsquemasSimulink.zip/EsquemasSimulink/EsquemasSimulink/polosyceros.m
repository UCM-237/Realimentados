%motor versi�n simple para lugar de las raices
km = 100;
p = 55;
vmotor = tf(km,[1 p]); %velocidad simple
pmotor = tf(1,[1 0])*vmotor;  %posicion motor

%PID (estructura)
syms k Ti s N Td
controler = k*(1 + 1/(Ti*s)+Td*s/(1+Td/N*s));
controler2 = k*((Ti*Td/N+Td*Ti)*s^2+(Ti+Td/N)*s+1)/(Ti*Td*s^2/N+Ti*s);
%Todas las constantes a 1

%PID
c1 = 1+tf(1,[1 0])+tf([1 0],[1 1]);
%PD
c2 = 1+tf([1 0],[1 1]);
% se emplea el lugar de las raices (rltool)para obtener un nuevo c1 y c2. 
%se exporta el controlador ajustado (En mi caso se han exprtado como c1aj
% y c2aj

% de aqu� para abajo deber�a ser una segunda funci�n
%rltools lo exporta en formato zpk lo pasamos a formato tf estandar para
%extraer los valores de nuestro controlador

c1tf =tf(c1aj);
%extraemos el numerador y el denominador
num = c1tf.numerator{1};
den = c1tf.denominator{1};
g = num(3)/den(2);
b2 = num(1)/num(3);
b1 = num(2)/num(3);
a2 = den(1)/den(2);

%valores del controlador PID
Ti = b1 - a2;
k = Ti*g;
Td = b2/Ti - a2;
N = Td/a2;

c2tf =tf(c2aj);
%extraemos el numerador y el denominador
num = c2tf.numerator{1};
den = c2tf.denominator{1};
k = num(2)/den(2);
b1 = num(1)/num(2);
a1 = den(1)/den(2);
Td = b1-a1;
N = Td/a1;


