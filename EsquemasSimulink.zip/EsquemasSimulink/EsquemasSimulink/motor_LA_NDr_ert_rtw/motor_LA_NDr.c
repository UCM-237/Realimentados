/*
 * motor_LA_NDr.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "motor_LA_NDr".
 *
 * Model version              : 1.36
 * Simulink Coder version : 9.1 (R2019a) 23-Nov-2018
 * C source code generated on : Thu Dec 17 09:20:55 2020
 *
 * Target selection: ert.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "motor_LA_NDr.h"
#include "motor_LA_NDr_private.h"

/* Block signals (default storage) */
B_motor_LA_NDr_T motor_LA_NDr_B;

/* Block states (default storage) */
DW_motor_LA_NDr_T motor_LA_NDr_DW;

/* Real-time model */
RT_MODEL_motor_LA_NDr_T motor_LA_NDr_M_;
RT_MODEL_motor_LA_NDr_T *const motor_LA_NDr_M = &motor_LA_NDr_M_;

/* Forward declaration for local functions */
static void motor_L_SystemCore_release_lqlq(const
  mbed_DigitalRead_motor_LA_NDr_T *obj);
static void motor_LA_SystemCore_delete_lqlq(const
  mbed_DigitalRead_motor_LA_NDr_T *obj);
static void matlabCodegenHandle_matlab_lqlq(mbed_DigitalRead_motor_LA_NDr_T *obj);
static void motor_LA_SystemCore_release_lql(const mbed_PWMOutput_motor_LA_NDr_T *
  obj);
static void motor_LA__SystemCore_delete_lql(const mbed_PWMOutput_motor_LA_NDr_T *
  obj);
static void matlabCodegenHandle_matlabC_lql(mbed_PWMOutput_motor_LA_NDr_T *obj);
static void motor_LA_NDr_SystemCore_release(const
  mbed_DigitalWrite_motor_LA_ND_T *obj);
static void motor_LA_NDr_SystemCore_delete(const mbed_DigitalWrite_motor_LA_ND_T
  *obj);
static void matlabCodegenHandle_matlabCodeg(mbed_DigitalWrite_motor_LA_ND_T *obj);
static void rate_monotonic_scheduler(void);

/*
 * Set which subrates need to run this base step (base rate always runs).
 * This function must be called prior to calling the model step function
 * in order to "remember" which rates need to run this base step.  The
 * buffering of events allows for overlapping preemption.
 */
void motor_LA_NDr_SetEventsForThisBaseStep(boolean_T *eventFlags)
{
  /* Task runs when its counter is zero, computed via rtmStepTask macro */
  eventFlags[1] = ((boolean_T)rtmStepTask(motor_LA_NDr_M, 1));
}

/*
 *   This function updates active task flag for each subrate
 * and rate transition flags for tasks that exchange data.
 * The function assumes rate-monotonic multitasking scheduler.
 * The function must be called at model base rate so that
 * the generated code self-manages all its subrates and rate
 * transition flags.
 */
static void rate_monotonic_scheduler(void)
{
  /* To ensure a deterministic data transfer between two rates,
   * data is transferred at the priority of a fast task and the frequency
   * of the slow task.  The following flags indicate when the data transfer
   * happens.  That is, a rate interaction flag is set true when both rates
   * will run, and false otherwise.
   */

  /* tid 0 shares data with slower tid rate: 1 */
  motor_LA_NDr_M->Timing.RateInteraction.TID0_1 =
    (motor_LA_NDr_M->Timing.TaskCounters.TID[1] == 0);

  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (motor_LA_NDr_M->Timing.TaskCounters.TID[1])++;
  if ((motor_LA_NDr_M->Timing.TaskCounters.TID[1]) > 99) {/* Sample time: [0.01s, 0.0s] */
    motor_LA_NDr_M->Timing.TaskCounters.TID[1] = 0;
  }
}

static void motor_L_SystemCore_release_lqlq(const
  mbed_DigitalRead_motor_LA_NDr_T *obj)
{
  if ((obj->isInitialized == 1) && obj->isSetupComplete) {
    MW_digitalIO_close(obj->MW_DIGITALIO_HANDLE);
  }
}

static void motor_LA_SystemCore_delete_lqlq(const
  mbed_DigitalRead_motor_LA_NDr_T *obj)
{
  motor_L_SystemCore_release_lqlq(obj);
}

static void matlabCodegenHandle_matlab_lqlq(mbed_DigitalRead_motor_LA_NDr_T *obj)
{
  if (!obj->matlabCodegenIsDeleted) {
    obj->matlabCodegenIsDeleted = true;
    motor_LA_SystemCore_delete_lqlq(obj);
  }
}

static void motor_LA_SystemCore_release_lql(const mbed_PWMOutput_motor_LA_NDr_T *
  obj)
{
  if ((obj->isInitialized == 1) && obj->isSetupComplete) {
    MW_PWM_Stop(obj->MW_PWM_HANDLE);
    MW_PWM_Close(obj->MW_PWM_HANDLE);
  }
}

static void motor_LA__SystemCore_delete_lql(const mbed_PWMOutput_motor_LA_NDr_T *
  obj)
{
  motor_LA_SystemCore_release_lql(obj);
}

static void matlabCodegenHandle_matlabC_lql(mbed_PWMOutput_motor_LA_NDr_T *obj)
{
  if (!obj->matlabCodegenIsDeleted) {
    obj->matlabCodegenIsDeleted = true;
    motor_LA__SystemCore_delete_lql(obj);
  }
}

static void motor_LA_NDr_SystemCore_release(const
  mbed_DigitalWrite_motor_LA_ND_T *obj)
{
  if ((obj->isInitialized == 1) && obj->isSetupComplete) {
    MW_digitalIO_close(obj->MW_DIGITALIO_HANDLE);
  }
}

static void motor_LA_NDr_SystemCore_delete(const mbed_DigitalWrite_motor_LA_ND_T
  *obj)
{
  motor_LA_NDr_SystemCore_release(obj);
}

static void matlabCodegenHandle_matlabCodeg(mbed_DigitalWrite_motor_LA_ND_T *obj)
{
  if (!obj->matlabCodegenIsDeleted) {
    obj->matlabCodegenIsDeleted = true;
    motor_LA_NDr_SystemCore_delete(obj);
  }
}

/* Model step function for TID0 */
void motor_LA_NDr_step0(void)          /* Sample time: [0.0001s, 0.0s] */
{
  real_T currentTime;

  {                                    /* Sample time: [0.0001s, 0.0s] */
    rate_monotonic_scheduler();
  }

  /* UnitDelay: '<S2>/Posicion (deg)' */
  motor_LA_NDr_B.Posiciondeg = motor_LA_NDr_DW.Posiciondeg_DSTATE;

  /* ZeroOrderHold: '<S2>/Zero-Order Hold' */
  if (motor_LA_NDr_M->Timing.RateInteraction.TID0_1) {
    motor_LA_NDr_B.ZeroOrderHold = motor_LA_NDr_B.Posiciondeg;
  }

  /* End of ZeroOrderHold: '<S2>/Zero-Order Hold' */
  /* MATLABSystem: '<S1>/Encoder A' */
  if (motor_LA_NDr_DW.obj.SampleTime != motor_LA_NDr_P.EncoderA_SampleTime) {
    motor_LA_NDr_DW.obj.SampleTime = motor_LA_NDr_P.EncoderA_SampleTime;
  }

  motor_LA_NDr_B.EncoderA = MW_digitalIO_read
    (motor_LA_NDr_DW.obj.MW_DIGITALIO_HANDLE);

  /* End of MATLABSystem: '<S1>/Encoder A' */

  /* MATLABSystem: '<S1>/EncoderB' */
  if (motor_LA_NDr_DW.obj_h.SampleTime != motor_LA_NDr_P.EncoderB_SampleTime) {
    motor_LA_NDr_DW.obj_h.SampleTime = motor_LA_NDr_P.EncoderB_SampleTime;
  }

  motor_LA_NDr_B.EncoderB = MW_digitalIO_read
    (motor_LA_NDr_DW.obj_h.MW_DIGITALIO_HANDLE);

  /* End of MATLABSystem: '<S1>/EncoderB' */
  /* Step: '<Root>/Step' */
  currentTime = motor_LA_NDr_M->Timing.taskTime0;
  if (currentTime < motor_LA_NDr_P.Step_Time) {
    currentTime = motor_LA_NDr_P.Step_Y0;
  } else {
    currentTime = motor_LA_NDr_P.Step_YFinal;
  }

  /* End of Step: '<Root>/Step' */

  /* MATLABSystem: '<S1>/PWDA' */
  MW_PWM_SetDutyCycle(motor_LA_NDr_DW.obj_dc.MW_PWM_HANDLE, currentTime);

  /* MATLABSystem: '<S1>/PHA' incorporates:
   *  Constant: '<Root>/giro'
   */
  MW_digitalIO_write(motor_LA_NDr_DW.obj_o.MW_DIGITALIO_HANDLE,
                     motor_LA_NDr_P.giro_Value != 0.0);

  /* MATLABSystem: '<S1>/ENA' incorporates:
   *  Constant: '<S1>/Constant'
   */
  MW_digitalIO_write(motor_LA_NDr_DW.obj_d.MW_DIGITALIO_HANDLE,
                     motor_LA_NDr_P.Constant_Value != 0.0);

  /* MATLABSystem: '<S1>/ENB' incorporates:
   *  Constant: '<S1>/Constant1'
   */
  MW_digitalIO_write(motor_LA_NDr_DW.obj_m.MW_DIGITALIO_HANDLE,
                     motor_LA_NDr_P.Constant1_Value != 0.0);

  /* LookupNDDirect: '<S2>/Direct Lookup Table (n-D)' incorporates:
   *  Gain: '<S2>/Gain'
   *  Gain: '<S2>/Gain1'
   *  Gain: '<S2>/Gain2'
   *  Gain: '<S2>/Gain3'
   *  Sum: '<S2>/Sum'
   *  UnitDelay: '<S2>/Unit Delay'
   *  UnitDelay: '<S2>/Unit Delay1'
   *
   * About '<S2>/Direct Lookup Table (n-D)':
   *  1-dimensional Direct Look-Up returning a Scalar,
   */
  currentTime = (((real_T)(motor_LA_NDr_DW.UnitDelay_DSTATE ? (int32_T)
    motor_LA_NDr_P.Gain3_Gain : 0) * 0.0625 + (real_T)(motor_LA_NDr_B.EncoderA ?
    (int32_T)motor_LA_NDr_P.Gain2_Gain : 0) * 0.03125) + (real_T)
                 (motor_LA_NDr_DW.UnitDelay1_DSTATE ? (int32_T)
                  motor_LA_NDr_P.Gain1_Gain : 0) * 0.015625) + (real_T)
    (motor_LA_NDr_B.EncoderB ? (int32_T)motor_LA_NDr_P.Gain_Gain : 0) *
    0.0078125;
  if (currentTime > 15.0) {
    currentTime = 15.0;
  }

  /* Update for UnitDelay: '<S2>/Posicion (deg)' incorporates:
   *  LookupNDDirect: '<S2>/Direct Lookup Table (n-D)'
   *  Sum: '<S2>/Sum1'
   *
   * About '<S2>/Direct Lookup Table (n-D)':
   *  1-dimensional Direct Look-Up returning a Scalar,
   */
  motor_LA_NDr_DW.Posiciondeg_DSTATE = motor_LA_NDr_P.DirectLookupTablenD_table
    [(int32_T)currentTime] + motor_LA_NDr_B.Posiciondeg;

  /* Update for UnitDelay: '<S2>/Unit Delay' */
  motor_LA_NDr_DW.UnitDelay_DSTATE = motor_LA_NDr_B.EncoderA;

  /* Update for UnitDelay: '<S2>/Unit Delay1' */
  motor_LA_NDr_DW.UnitDelay1_DSTATE = motor_LA_NDr_B.EncoderB;

  /* External mode */
  rtExtModeUploadCheckTrigger(2);
  rtExtModeUpload(0, (real_T)motor_LA_NDr_M->Timing.taskTime0);

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.0001s, 0.0s] */
    if ((rtmGetTFinal(motor_LA_NDr_M)!=-1) &&
        !((rtmGetTFinal(motor_LA_NDr_M)-motor_LA_NDr_M->Timing.taskTime0) >
          motor_LA_NDr_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(motor_LA_NDr_M, "Simulation finished");
    }

    if (rtmGetStopRequested(motor_LA_NDr_M)) {
      rtmSetErrorStatus(motor_LA_NDr_M, "Simulation finished");
    }
  }

  /* Update absolute time */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++motor_LA_NDr_M->Timing.clockTick0)) {
    ++motor_LA_NDr_M->Timing.clockTickH0;
  }

  motor_LA_NDr_M->Timing.taskTime0 = motor_LA_NDr_M->Timing.clockTick0 *
    motor_LA_NDr_M->Timing.stepSize0 + motor_LA_NDr_M->Timing.clockTickH0 *
    motor_LA_NDr_M->Timing.stepSize0 * 4294967296.0;
}

/* Model step function for TID1 */
void motor_LA_NDr_step1(void)          /* Sample time: [0.01s, 0.0s] */
{
  real_T rtb_TSamp;

  /* SampleTimeMath: '<S3>/TSamp'
   *
   * About '<S3>/TSamp':
   *  y = u * K where K = 1 / ( w * Ts )
   */
  rtb_TSamp = motor_LA_NDr_B.ZeroOrderHold * motor_LA_NDr_P.TSamp_WtEt;

  /* Sum: '<S3>/Diff' incorporates:
   *  UnitDelay: '<S3>/UD'
   */
  motor_LA_NDr_B.Diff = rtb_TSamp - motor_LA_NDr_DW.UD_DSTATE;

  /* Update for UnitDelay: '<S3>/UD' */
  motor_LA_NDr_DW.UD_DSTATE = rtb_TSamp;
  rtExtModeUpload(1, (real_T)(((motor_LA_NDr_M->Timing.clockTick1+
    motor_LA_NDr_M->Timing.clockTickH1* 4294967296.0)) * 0.01));

  /* Update absolute time */
  /* The "clockTick1" counts the number of times the code of this task has
   * been executed. The resolution of this integer timer is 0.01, which is the step size
   * of the task. Size of "clockTick1" ensures timer will not overflow during the
   * application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick1 and the high bits
   * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
   */
  motor_LA_NDr_M->Timing.clockTick1++;
  if (!motor_LA_NDr_M->Timing.clockTick1) {
    motor_LA_NDr_M->Timing.clockTickH1++;
  }
}

/* Model initialize function */
void motor_LA_NDr_initialize(void)
{
  /* Registration code */

  /* initialize real-time model */
  (void) memset((void *)motor_LA_NDr_M, 0,
                sizeof(RT_MODEL_motor_LA_NDr_T));
  rtmSetTFinal(motor_LA_NDr_M, 40.0);
  motor_LA_NDr_M->Timing.stepSize0 = 0.0001;

  /* External mode info */
  motor_LA_NDr_M->Sizes.checksums[0] = (3746004507U);
  motor_LA_NDr_M->Sizes.checksums[1] = (1430771930U);
  motor_LA_NDr_M->Sizes.checksums[2] = (113899068U);
  motor_LA_NDr_M->Sizes.checksums[3] = (594067083U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[7];
    motor_LA_NDr_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = &rtAlwaysEnabled;
    systemRan[3] = &rtAlwaysEnabled;
    systemRan[4] = &rtAlwaysEnabled;
    systemRan[5] = &rtAlwaysEnabled;
    systemRan[6] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(motor_LA_NDr_M->extModeInfo,
      &motor_LA_NDr_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(motor_LA_NDr_M->extModeInfo,
                        motor_LA_NDr_M->Sizes.checksums);
    rteiSetTPtr(motor_LA_NDr_M->extModeInfo, rtmGetTPtr(motor_LA_NDr_M));
  }

  /* block I/O */
  (void) memset(((void *) &motor_LA_NDr_B), 0,
                sizeof(B_motor_LA_NDr_T));

  /* states (dwork) */
  (void) memset((void *)&motor_LA_NDr_DW, 0,
                sizeof(DW_motor_LA_NDr_T));

  {
    mbed_DigitalRead_motor_LA_NDr_T *obj;
    uint32_T pinname;
    mbed_PWMOutput_motor_LA_NDr_T *obj_0;
    mbed_DigitalWrite_motor_LA_ND_T *obj_1;

    /* Start for MATLABSystem: '<S1>/Encoder A' */
    motor_LA_NDr_DW.obj.matlabCodegenIsDeleted = true;
    motor_LA_NDr_DW.obj.isInitialized = 0;
    motor_LA_NDr_DW.obj.SampleTime = -1.0;
    motor_LA_NDr_DW.obj.matlabCodegenIsDeleted = false;
    motor_LA_NDr_DW.objisempty = true;
    motor_LA_NDr_DW.obj.SampleTime = motor_LA_NDr_P.EncoderA_SampleTime;
    obj = &motor_LA_NDr_DW.obj;
    motor_LA_NDr_DW.obj.isSetupComplete = false;
    motor_LA_NDr_DW.obj.isInitialized = 1;
    pinname = A1;
    obj->MW_DIGITALIO_HANDLE = MW_digitalIO_open(pinname, 0);
    motor_LA_NDr_DW.obj.isSetupComplete = true;

    /* Start for MATLABSystem: '<S1>/EncoderB' */
    motor_LA_NDr_DW.obj_h.matlabCodegenIsDeleted = true;
    motor_LA_NDr_DW.obj_h.isInitialized = 0;
    motor_LA_NDr_DW.obj_h.SampleTime = -1.0;
    motor_LA_NDr_DW.obj_h.matlabCodegenIsDeleted = false;
    motor_LA_NDr_DW.objisempty_g = true;
    motor_LA_NDr_DW.obj_h.SampleTime = motor_LA_NDr_P.EncoderB_SampleTime;
    obj = &motor_LA_NDr_DW.obj_h;
    motor_LA_NDr_DW.obj_h.isSetupComplete = false;
    motor_LA_NDr_DW.obj_h.isInitialized = 1;
    pinname = A0;
    obj->MW_DIGITALIO_HANDLE = MW_digitalIO_open(pinname, 0);
    motor_LA_NDr_DW.obj_h.isSetupComplete = true;

    /* Start for MATLABSystem: '<S1>/PWDA' */
    motor_LA_NDr_DW.obj_dc.matlabCodegenIsDeleted = true;
    motor_LA_NDr_DW.obj_dc.isInitialized = 0;
    motor_LA_NDr_DW.obj_dc.matlabCodegenIsDeleted = false;
    motor_LA_NDr_DW.objisempty_p = true;
    obj_0 = &motor_LA_NDr_DW.obj_dc;
    motor_LA_NDr_DW.obj_dc.isSetupComplete = false;
    motor_LA_NDr_DW.obj_dc.isInitialized = 1;
    pinname = D5;
    obj_0->MW_PWM_HANDLE = MW_PWM_Open(pinname, 5000.0, 50.0);
    MW_PWM_Start(motor_LA_NDr_DW.obj_dc.MW_PWM_HANDLE);
    motor_LA_NDr_DW.obj_dc.isSetupComplete = true;

    /* Start for MATLABSystem: '<S1>/PHA' */
    motor_LA_NDr_DW.obj_o.matlabCodegenIsDeleted = true;
    motor_LA_NDr_DW.obj_o.isInitialized = 0;
    motor_LA_NDr_DW.obj_o.matlabCodegenIsDeleted = false;
    motor_LA_NDr_DW.objisempty_d = true;
    obj_1 = &motor_LA_NDr_DW.obj_o;
    motor_LA_NDr_DW.obj_o.isSetupComplete = false;
    motor_LA_NDr_DW.obj_o.isInitialized = 1;
    pinname = D3;
    obj_1->MW_DIGITALIO_HANDLE = MW_digitalIO_open(pinname, 1);
    motor_LA_NDr_DW.obj_o.isSetupComplete = true;

    /* Start for MATLABSystem: '<S1>/ENA' */
    motor_LA_NDr_DW.obj_d.matlabCodegenIsDeleted = true;
    motor_LA_NDr_DW.obj_d.isInitialized = 0;
    motor_LA_NDr_DW.obj_d.matlabCodegenIsDeleted = false;
    motor_LA_NDr_DW.objisempty_k = true;
    obj_1 = &motor_LA_NDr_DW.obj_d;
    motor_LA_NDr_DW.obj_d.isSetupComplete = false;
    motor_LA_NDr_DW.obj_d.isInitialized = 1;
    pinname = D2;
    obj_1->MW_DIGITALIO_HANDLE = MW_digitalIO_open(pinname, 1);
    motor_LA_NDr_DW.obj_d.isSetupComplete = true;

    /* Start for MATLABSystem: '<S1>/ENB' */
    motor_LA_NDr_DW.obj_m.matlabCodegenIsDeleted = true;
    motor_LA_NDr_DW.obj_m.isInitialized = 0;
    motor_LA_NDr_DW.obj_m.matlabCodegenIsDeleted = false;
    motor_LA_NDr_DW.objisempty_ks = true;
    obj_1 = &motor_LA_NDr_DW.obj_m;
    motor_LA_NDr_DW.obj_m.isSetupComplete = false;
    motor_LA_NDr_DW.obj_m.isInitialized = 1;
    pinname = D11;
    obj_1->MW_DIGITALIO_HANDLE = MW_digitalIO_open(pinname, 1);
    motor_LA_NDr_DW.obj_m.isSetupComplete = true;
  }

  /* InitializeConditions for UnitDelay: '<S2>/Posicion (deg)' */
  motor_LA_NDr_DW.Posiciondeg_DSTATE =
    motor_LA_NDr_P.Posiciondeg_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S3>/UD' */
  motor_LA_NDr_DW.UD_DSTATE = motor_LA_NDr_P.Velocidaddegs_ICPrevScaledInput;

  /* InitializeConditions for UnitDelay: '<S2>/Unit Delay' */
  motor_LA_NDr_DW.UnitDelay_DSTATE = motor_LA_NDr_P.UnitDelay_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S2>/Unit Delay1' */
  motor_LA_NDr_DW.UnitDelay1_DSTATE = motor_LA_NDr_P.UnitDelay1_InitialCondition;
}

/* Model terminate function */
void motor_LA_NDr_terminate(void)
{
  /* Terminate for MATLABSystem: '<S1>/Encoder A' */
  matlabCodegenHandle_matlab_lqlq(&motor_LA_NDr_DW.obj);

  /* Terminate for MATLABSystem: '<S1>/EncoderB' */
  matlabCodegenHandle_matlab_lqlq(&motor_LA_NDr_DW.obj_h);

  /* Terminate for MATLABSystem: '<S1>/PWDA' */
  matlabCodegenHandle_matlabC_lql(&motor_LA_NDr_DW.obj_dc);

  /* Terminate for MATLABSystem: '<S1>/PHA' */
  matlabCodegenHandle_matlabCodeg(&motor_LA_NDr_DW.obj_o);

  /* Terminate for MATLABSystem: '<S1>/ENA' */
  matlabCodegenHandle_matlabCodeg(&motor_LA_NDr_DW.obj_d);

  /* Terminate for MATLABSystem: '<S1>/ENB' */
  matlabCodegenHandle_matlabCodeg(&motor_LA_NDr_DW.obj_m);
}
