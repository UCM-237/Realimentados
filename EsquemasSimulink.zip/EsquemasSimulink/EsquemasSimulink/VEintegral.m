clc
clear all
k_e =100
p = 55
A=[0,1;0,-55];B=[0;100];C=[1,0];D=[0];n=length(A);
Am=[A,zeros(n,1);C,0];Bm=[B;0];
OB=obsv(A,C);CO=ctrb(Am,Bm);
if rank(OB)==n && rank(CO)==(n+1)
    K=acker(Am,Bm,[-15,-15,-20]);
    Ki=K(end);K=K(1:end-1);
    L=acker(A',C',[-30,-30])';
    F=20; 
end