/*
 * MotorLazoAbierto_NDr_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "MotorLazoAbierto_NDr".
 *
 * Model version              : 1.17
 * Simulink Coder version : 9.1 (R2019a) 23-Nov-2018
 * C source code generated on : Fri Oct 25 10:49:23 2019
 *
 * Target selection: ert.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_MotorLazoAbierto_NDr_types_h_
#define RTW_HEADER_MotorLazoAbierto_NDr_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"

/* Custom Type definition for MATLABSystem: '<S1>/Hall 1' */
#include "MW_SVD.h"
#ifndef typedef_mbed_DigitalWrite_MotorLazoAb_T
#define typedef_mbed_DigitalWrite_MotorLazoAb_T

typedef struct {
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  MW_Handle_Type MW_DIGITALIO_HANDLE;
} mbed_DigitalWrite_MotorLazoAb_T;

#endif                               /*typedef_mbed_DigitalWrite_MotorLazoAb_T*/

#ifndef typedef_mbed_PWMOutput_MotorLazoAbier_T
#define typedef_mbed_PWMOutput_MotorLazoAbier_T

typedef struct {
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  MW_Handle_Type MW_PWM_HANDLE;
} mbed_PWMOutput_MotorLazoAbier_T;

#endif                               /*typedef_mbed_PWMOutput_MotorLazoAbier_T*/

#ifndef typedef_mbed_DigitalRead_MotorLazoAbi_T
#define typedef_mbed_DigitalRead_MotorLazoAbi_T

typedef struct {
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  MW_Handle_Type MW_DIGITALIO_HANDLE;
  real_T SampleTime;
} mbed_DigitalRead_MotorLazoAbi_T;

#endif                               /*typedef_mbed_DigitalRead_MotorLazoAbi_T*/

/* Parameters (default storage) */
typedef struct P_MotorLazoAbierto_NDr_T_ P_MotorLazoAbierto_NDr_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_MotorLazoAbierto_NDr_T RT_MODEL_MotorLazoAbierto_NDr_T;

#endif                            /* RTW_HEADER_MotorLazoAbierto_NDr_types_h_ */
