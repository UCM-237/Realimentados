/*
 * MotorLazoAbierto_NDr_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "MotorLazoAbierto_NDr".
 *
 * Model version              : 1.17
 * Simulink Coder version : 9.1 (R2019a) 23-Nov-2018
 * C source code generated on : Fri Oct 25 10:49:23 2019
 *
 * Target selection: ert.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "MotorLazoAbierto_NDr.h"
#include "MotorLazoAbierto_NDr_private.h"

/* Block parameters (default storage) */
P_MotorLazoAbierto_NDr_T MotorLazoAbierto_NDr_P = {
  /* Mask Parameter: Velocidaddegs_ICPrevScaledInput
   * Referenced by: '<S4>/UD'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S1>/Constant2'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S1>/Constant3'
   */
  1.0,

  /* Expression: 0.0001
   * Referenced by: '<S1>/Hall 2'
   */
  0.0001,

  /* Expression: 0.0001
   * Referenced by: '<S1>/Hall 1'
   */
  0.0001,

  /* Computed Parameter: Tsing_Y0
   * Referenced by: '<S3>/T*sing '
   */
  0.0,

  /* Computed Parameter: dTultimop_Y0
   * Referenced by: '<S3>/dT ultimo p '
   */
  0.0,

  /* Computed Parameter: Tactual_Y0
   * Referenced by: '<S3>/T actual'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S3>/Memory1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S5>/Constant'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S3>/Memory'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S2>/Posicion (deg)'
   */
  0.0,

  /* Computed Parameter: TSamp_WtEt
   * Referenced by: '<S4>/TSamp'
   */
  100.0,

  /* Expression: [0,-1,1,0,1,0,0,-1,-1,0,0,1,0,1,-1,0]
   * Referenced by: '<S2>/Direct Lookup Table (n-D)'
   */
  { 0.0, -1.0, 1.0, 0.0, 1.0, 0.0, 0.0, -1.0, -1.0, 0.0, 0.0, 1.0, 0.0, 1.0,
    -1.0, 0.0 },

  /* Expression: 0
   * Referenced by: '<S2>/Constant2'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S2>/Switch1'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<Root>/Step'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<Root>/Step'
   */
  0.0,

  /* Expression: 50
   * Referenced by: '<Root>/Step'
   */
  50.0,

  /* Expression: 1
   * Referenced by: '<S1>/Constant'
   */
  1.0,

  /* Computed Parameter: UnitDelay_InitialCondition
   * Referenced by: '<S2>/Unit Delay'
   */
  0,

  /* Computed Parameter: UnitDelay1_InitialCondition
   * Referenced by: '<S2>/Unit Delay1'
   */
  0,

  /* Computed Parameter: Gain3_Gain
   * Referenced by: '<S2>/Gain3'
   */
  128U,

  /* Computed Parameter: Gain2_Gain
   * Referenced by: '<S2>/Gain2'
   */
  128U,

  /* Computed Parameter: Gain1_Gain
   * Referenced by: '<S2>/Gain1'
   */
  128U,

  /* Computed Parameter: Gain_Gain
   * Referenced by: '<S2>/Gain'
   */
  128U,

  /* Computed Parameter: ManualSwitch_CurrentSetting
   * Referenced by: '<S1>/Manual Switch'
   */
  1U
};
