/*
 * MotorLazoAbierto_NDr.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "MotorLazoAbierto_NDr".
 *
 * Model version              : 1.17
 * Simulink Coder version : 9.1 (R2019a) 23-Nov-2018
 * C source code generated on : Fri Oct 25 10:49:23 2019
 *
 * Target selection: ert.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_MotorLazoAbierto_NDr_h_
#define RTW_HEADER_MotorLazoAbierto_NDr_h_
#include <math.h>
#include <float.h>
#include <string.h>
#include <stddef.h>
#ifndef MotorLazoAbierto_NDr_COMMON_INCLUDES_
# define MotorLazoAbierto_NDr_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "ext_work.h"
#include "MW_MbedPinInterface.h"
#include "MW_digitalIO.h"
#include "MW_PWM.h"
#endif                               /* MotorLazoAbierto_NDr_COMMON_INCLUDES_ */

#include "MotorLazoAbierto_NDr_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "MW_target_hardware_resources.h"
#include "rt_zcfcn.h"
#include "rtGetNaN.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWExtModeInfo
# define rtmGetRTWExtModeInfo(rtm)     ((rtm)->extModeInfo)
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmStepTask
# define rtmStepTask(rtm, idx)         ((rtm)->Timing.TaskCounters.TID[(idx)] == 0)
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               ((rtm)->Timing.t)
#endif

#ifndef rtmTaskCounter
# define rtmTaskCounter(rtm, idx)      ((rtm)->Timing.TaskCounters.TID[(idx)])
#endif

/* Block signals (default storage) */
typedef struct {
  real_T Posiciondeg;                  /* '<S2>/Posicion (deg)' */
  real_T ZeroOrderHold;                /* '<S2>/Zero-Order Hold' */
  real_T Diff;                         /* '<S4>/Diff' */
  real_T Clock;                        /* '<S2>/Clock' */
  real_T Sign1;                        /* '<S2>/Sign1' */
  real_T Switch1;                      /* '<S2>/Switch1' */
  real_T In1;                          /* '<S3>/In1' */
  real_T Product2;                     /* '<S3>/Product2' */
  real_T Product;                      /* '<S3>/Product' */
  boolean_T Hall1;                     /* '<S1>/Hall 1' */
  boolean_T Hall2;                     /* '<S1>/Hall 2' */
} B_MotorLazoAbierto_NDr_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  mbed_DigitalRead_MotorLazoAbi_T obj; /* '<S1>/Hall 1' */
  mbed_DigitalRead_MotorLazoAbi_T obj_i;/* '<S1>/Hall 2' */
  mbed_DigitalWrite_MotorLazoAb_T obj_p;/* '<S1>/ENA' */
  mbed_DigitalWrite_MotorLazoAb_T obj_m;/* '<S1>/ENB ' */
  mbed_DigitalWrite_MotorLazoAb_T obj_g;/* '<S1>/DirA' */
  mbed_DigitalWrite_MotorLazoAb_T obj_k;/* '<S1>/DirB' */
  mbed_PWMOutput_MotorLazoAbier_T obj_b;/* '<S1>/PWM A//B (paralelo) ' */
  real_T Posiciondeg_DSTATE;           /* '<S2>/Posicion (deg)' */
  real_T UD_DSTATE;                    /* '<S4>/UD' */
  real_T Memory1_PreviousInput;        /* '<S3>/Memory1' */
  real_T Memory_PreviousInput;         /* '<S3>/Memory' */
  struct {
    void *AQHandles;
    void *SlioLTF;
  } HiddenToAsyncQueue_InsertedFor_;   /* synthesized block */

  struct {
    void *AQHandles;
    void *SlioLTF;
  } HiddenToAsyncQueue_InsertedFo_g;   /* synthesized block */

  struct {
    void *LoggedData;
  } Scope1_PWORK;                      /* '<Root>/Scope1' */

  struct {
    void *LoggedData;
  } Scope_PWORK;                       /* '<Root>/Scope' */

  struct {
    void *AQHandles;
    void *SlioLTF;
  } HiddenToAsyncQueue_InsertedFo_d;   /* synthesized block */

  struct {
    void *AQHandles;
    void *SlioLTF;
  } HiddenToAsyncQueue_InsertedFo_o;   /* synthesized block */

  struct {
    void *LoggedData;
  } Scope2_PWORK;                      /* '<Root>/Scope2' */

  boolean_T UnitDelay_DSTATE;          /* '<S2>/Unit Delay' */
  boolean_T UnitDelay1_DSTATE;         /* '<S2>/Unit Delay1' */
  int8_T TriggeredSubsystem_SubsysRanBC;/* '<S2>/Triggered Subsystem' */
  boolean_T objisempty;                /* '<S1>/Hall 1' */
  boolean_T objisempty_h;              /* '<S1>/Hall 2' */
  boolean_T objisempty_hs;             /* '<S1>/PWM A//B (paralelo) ' */
  boolean_T objisempty_k;              /* '<S1>/ENA' */
  boolean_T objisempty_j;              /* '<S1>/ENB ' */
  boolean_T objisempty_n;              /* '<S1>/DirA' */
  boolean_T objisempty_a;              /* '<S1>/DirB' */
} DW_MotorLazoAbierto_NDr_T;

/* Zero-crossing (trigger) state */
typedef struct {
  ZCSigState TriggeredSubsystem_Trig_ZCE;/* '<S2>/Triggered Subsystem' */
} PrevZCX_MotorLazoAbierto_NDr_T;

/* Parameters (default storage) */
struct P_MotorLazoAbierto_NDr_T_ {
  real_T Velocidaddegs_ICPrevScaledInput;
                              /* Mask Parameter: Velocidaddegs_ICPrevScaledInput
                               * Referenced by: '<S4>/UD'
                               */
  real_T Constant2_Value;              /* Expression: 0
                                        * Referenced by: '<S1>/Constant2'
                                        */
  real_T Constant3_Value;              /* Expression: 1
                                        * Referenced by: '<S1>/Constant3'
                                        */
  real_T Hall2_SampleTime;             /* Expression: 0.0001
                                        * Referenced by: '<S1>/Hall 2'
                                        */
  real_T Hall1_SampleTime;             /* Expression: 0.0001
                                        * Referenced by: '<S1>/Hall 1'
                                        */
  real_T Tsing_Y0;                     /* Computed Parameter: Tsing_Y0
                                        * Referenced by: '<S3>/T*sing '
                                        */
  real_T dTultimop_Y0;                 /* Computed Parameter: dTultimop_Y0
                                        * Referenced by: '<S3>/dT ultimo p '
                                        */
  real_T Tactual_Y0;                   /* Computed Parameter: Tactual_Y0
                                        * Referenced by: '<S3>/T actual'
                                        */
  real_T Memory1_InitialCondition;     /* Expression: 0
                                        * Referenced by: '<S3>/Memory1'
                                        */
  real_T Constant_Value;               /* Expression: 0
                                        * Referenced by: '<S5>/Constant'
                                        */
  real_T Memory_InitialCondition;      /* Expression: 0
                                        * Referenced by: '<S3>/Memory'
                                        */
  real_T Posiciondeg_InitialCondition; /* Expression: 0
                                        * Referenced by: '<S2>/Posicion (deg)'
                                        */
  real_T TSamp_WtEt;                   /* Computed Parameter: TSamp_WtEt
                                        * Referenced by: '<S4>/TSamp'
                                        */
  real_T DirectLookupTablenD_table[16];
                            /* Expression: [0,-1,1,0,1,0,0,-1,-1,0,0,1,0,1,-1,0]
                             * Referenced by: '<S2>/Direct Lookup Table (n-D)'
                             */
  real_T Constant2_Value_p;            /* Expression: 0
                                        * Referenced by: '<S2>/Constant2'
                                        */
  real_T Switch1_Threshold;            /* Expression: 0
                                        * Referenced by: '<S2>/Switch1'
                                        */
  real_T Step_Time;                    /* Expression: 1
                                        * Referenced by: '<Root>/Step'
                                        */
  real_T Step_Y0;                      /* Expression: 0
                                        * Referenced by: '<Root>/Step'
                                        */
  real_T Step_YFinal;                  /* Expression: 50
                                        * Referenced by: '<Root>/Step'
                                        */
  real_T Constant_Value_m;             /* Expression: 1
                                        * Referenced by: '<S1>/Constant'
                                        */
  boolean_T UnitDelay_InitialCondition;
                               /* Computed Parameter: UnitDelay_InitialCondition
                                * Referenced by: '<S2>/Unit Delay'
                                */
  boolean_T UnitDelay1_InitialCondition;
                              /* Computed Parameter: UnitDelay1_InitialCondition
                               * Referenced by: '<S2>/Unit Delay1'
                               */
  uint8_T Gain3_Gain;                  /* Computed Parameter: Gain3_Gain
                                        * Referenced by: '<S2>/Gain3'
                                        */
  uint8_T Gain2_Gain;                  /* Computed Parameter: Gain2_Gain
                                        * Referenced by: '<S2>/Gain2'
                                        */
  uint8_T Gain1_Gain;                  /* Computed Parameter: Gain1_Gain
                                        * Referenced by: '<S2>/Gain1'
                                        */
  uint8_T Gain_Gain;                   /* Computed Parameter: Gain_Gain
                                        * Referenced by: '<S2>/Gain'
                                        */
  uint8_T ManualSwitch_CurrentSetting;
                              /* Computed Parameter: ManualSwitch_CurrentSetting
                               * Referenced by: '<S1>/Manual Switch'
                               */
};

/* Real-time Model Data Structure */
struct tag_RTM_MotorLazoAbierto_NDr_T {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;
  RTWSolverInfo solverInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    uint32_T clockTick2;
    uint32_T clockTickH2;
    struct {
      uint8_T TID[3];
    } TaskCounters;

    struct {
      boolean_T TID1_2;
    } RateInteraction;

    time_T tFinal;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[3];
  } Timing;
};

/* Block parameters (default storage) */
extern P_MotorLazoAbierto_NDr_T MotorLazoAbierto_NDr_P;

/* Block signals (default storage) */
extern B_MotorLazoAbierto_NDr_T MotorLazoAbierto_NDr_B;

/* Block states (default storage) */
extern DW_MotorLazoAbierto_NDr_T MotorLazoAbierto_NDr_DW;

/* External data declarations for dependent source files */

/* Zero-crossing (trigger) state */
extern PrevZCX_MotorLazoAbierto_NDr_T MotorLazoAbierto_NDr_PrevZCX;

/* External function called from main */
extern void MotorLazoAbierto_NDr_SetEventsForThisBaseStep(boolean_T *eventFlags);

/* Model entry point functions */
extern void MotorLazoAbierto_NDr_SetEventsForThisBaseStep(boolean_T *eventFlags);
extern void MotorLazoAbierto_NDr_initialize(void);
extern void MotorLazoAbierto_NDr_step0(void);
extern void MotorLazoAbierto_NDr_step2(void);
extern void MotorLazoAbierto_NDr_terminate(void);

/* Real-time Model object */
extern RT_MODEL_MotorLazoAbierto_NDr_T *const MotorLazoAbierto_NDr_M;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S4>/Data Type Duplicate' : Unused code path elimination
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'MotorLazoAbierto_NDr'
 * '<S1>'   : 'MotorLazoAbierto_NDr/Motor'
 * '<S2>'   : 'MotorLazoAbierto_NDr/Motor/Subsystem'
 * '<S3>'   : 'MotorLazoAbierto_NDr/Motor/Subsystem/Triggered Subsystem'
 * '<S4>'   : 'MotorLazoAbierto_NDr/Motor/Subsystem/Velocidad (deg//s)'
 * '<S5>'   : 'MotorLazoAbierto_NDr/Motor/Subsystem/Triggered Subsystem/Compare To Zero'
 */
#endif                                 /* RTW_HEADER_MotorLazoAbierto_NDr_h_ */
