/*
 * MotorLazoAbierto_NDr.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "MotorLazoAbierto_NDr".
 *
 * Model version              : 1.17
 * Simulink Coder version : 9.1 (R2019a) 23-Nov-2018
 * C source code generated on : Fri Oct 25 10:49:23 2019
 *
 * Target selection: ert.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "MotorLazoAbierto_NDr.h"
#include "MotorLazoAbierto_NDr_private.h"

/* Block signals (default storage) */
B_MotorLazoAbierto_NDr_T MotorLazoAbierto_NDr_B;

/* Block states (default storage) */
DW_MotorLazoAbierto_NDr_T MotorLazoAbierto_NDr_DW;

/* Previous zero-crossings (trigger) states */
PrevZCX_MotorLazoAbierto_NDr_T MotorLazoAbierto_NDr_PrevZCX;

/* Real-time model */
RT_MODEL_MotorLazoAbierto_NDr_T MotorLazoAbierto_NDr_M_;
RT_MODEL_MotorLazoAbierto_NDr_T *const MotorLazoAbierto_NDr_M =
  &MotorLazoAbierto_NDr_M_;

/* Forward declaration for local functions */
static void MotorL_SystemCore_release_a0jjz(const
  mbed_DigitalRead_MotorLazoAbi_T *obj);
static void MotorLa_SystemCore_delete_a0jjz(const
  mbed_DigitalRead_MotorLazoAbi_T *obj);
static void matlabCodegenHandle_matla_a0jjz(mbed_DigitalRead_MotorLazoAbi_T *obj);
static void MotorLa_SystemCore_release_a0jj(const
  mbed_PWMOutput_MotorLazoAbier_T *obj);
static void MotorLaz_SystemCore_delete_a0jj(const
  mbed_PWMOutput_MotorLazoAbier_T *obj);
static void matlabCodegenHandle_matlab_a0jj(mbed_PWMOutput_MotorLazoAbier_T *obj);
static void MotorLazoAbi_SystemCore_release(const
  mbed_DigitalWrite_MotorLazoAb_T *obj);
static void MotorLazoAbie_SystemCore_delete(const
  mbed_DigitalWrite_MotorLazoAb_T *obj);
static void matlabCodegenHandle_matlabCodeg(mbed_DigitalWrite_MotorLazoAb_T *obj);
static void rate_monotonic_scheduler(void);

/*
 * Set which subrates need to run this base step (base rate always runs).
 * This function must be called prior to calling the model step function
 * in order to "remember" which rates need to run this base step.  The
 * buffering of events allows for overlapping preemption.
 */
void MotorLazoAbierto_NDr_SetEventsForThisBaseStep(boolean_T *eventFlags)
{
  /* Task runs when its counter is zero, computed via rtmStepTask macro */
  eventFlags[2] = ((boolean_T)rtmStepTask(MotorLazoAbierto_NDr_M, 2));
}

/*
 *   This function updates active task flag for each subrate
 * and rate transition flags for tasks that exchange data.
 * The function assumes rate-monotonic multitasking scheduler.
 * The function must be called at model base rate so that
 * the generated code self-manages all its subrates and rate
 * transition flags.
 */
static void rate_monotonic_scheduler(void)
{
  /* To ensure a deterministic data transfer between two rates,
   * data is transferred at the priority of a fast task and the frequency
   * of the slow task.  The following flags indicate when the data transfer
   * happens.  That is, a rate interaction flag is set true when both rates
   * will run, and false otherwise.
   */

  /* tid 1 shares data with slower tid rate: 2 */
  if (MotorLazoAbierto_NDr_M->Timing.TaskCounters.TID[1] == 0) {
    MotorLazoAbierto_NDr_M->Timing.RateInteraction.TID1_2 =
      (MotorLazoAbierto_NDr_M->Timing.TaskCounters.TID[2] == 0);
  }

  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (MotorLazoAbierto_NDr_M->Timing.TaskCounters.TID[2])++;
  if ((MotorLazoAbierto_NDr_M->Timing.TaskCounters.TID[2]) > 99) {/* Sample time: [0.01s, 0.0s] */
    MotorLazoAbierto_NDr_M->Timing.TaskCounters.TID[2] = 0;
  }
}

static void MotorL_SystemCore_release_a0jjz(const
  mbed_DigitalRead_MotorLazoAbi_T *obj)
{
  if ((obj->isInitialized == 1) && obj->isSetupComplete) {
    MW_digitalIO_close(obj->MW_DIGITALIO_HANDLE);
  }
}

static void MotorLa_SystemCore_delete_a0jjz(const
  mbed_DigitalRead_MotorLazoAbi_T *obj)
{
  MotorL_SystemCore_release_a0jjz(obj);
}

static void matlabCodegenHandle_matla_a0jjz(mbed_DigitalRead_MotorLazoAbi_T *obj)
{
  if (!obj->matlabCodegenIsDeleted) {
    obj->matlabCodegenIsDeleted = true;
    MotorLa_SystemCore_delete_a0jjz(obj);
  }
}

static void MotorLa_SystemCore_release_a0jj(const
  mbed_PWMOutput_MotorLazoAbier_T *obj)
{
  if ((obj->isInitialized == 1) && obj->isSetupComplete) {
    MW_PWM_Stop(obj->MW_PWM_HANDLE);
    MW_PWM_Close(obj->MW_PWM_HANDLE);
  }
}

static void MotorLaz_SystemCore_delete_a0jj(const
  mbed_PWMOutput_MotorLazoAbier_T *obj)
{
  MotorLa_SystemCore_release_a0jj(obj);
}

static void matlabCodegenHandle_matlab_a0jj(mbed_PWMOutput_MotorLazoAbier_T *obj)
{
  if (!obj->matlabCodegenIsDeleted) {
    obj->matlabCodegenIsDeleted = true;
    MotorLaz_SystemCore_delete_a0jj(obj);
  }
}

static void MotorLazoAbi_SystemCore_release(const
  mbed_DigitalWrite_MotorLazoAb_T *obj)
{
  if ((obj->isInitialized == 1) && obj->isSetupComplete) {
    MW_digitalIO_close(obj->MW_DIGITALIO_HANDLE);
  }
}

static void MotorLazoAbie_SystemCore_delete(const
  mbed_DigitalWrite_MotorLazoAb_T *obj)
{
  MotorLazoAbi_SystemCore_release(obj);
}

static void matlabCodegenHandle_matlabCodeg(mbed_DigitalWrite_MotorLazoAb_T *obj)
{
  if (!obj->matlabCodegenIsDeleted) {
    obj->matlabCodegenIsDeleted = true;
    MotorLazoAbie_SystemCore_delete(obj);
  }
}

/* Model step function for TID0 */
void MotorLazoAbierto_NDr_step0(void)  /* Sample time: [0.0s, 0.0s] */
{
  /* local block i/o variables */
  real_T rtb_Sum1;
  real_T rtb_Sum;
  real_T rtb_DirectLookupTablenD;
  ZCEventType zcEvent;

  {                                    /* Sample time: [0.0s, 0.0s] */
    rate_monotonic_scheduler();
  }

  /* Reset subsysRan breadcrumbs */
  srClearBC(MotorLazoAbierto_NDr_DW.TriggeredSubsystem_SubsysRanBC);

  /* UnitDelay: '<S2>/Posicion (deg)' */
  MotorLazoAbierto_NDr_B.Posiciondeg =
    MotorLazoAbierto_NDr_DW.Posiciondeg_DSTATE;

  /* ZeroOrderHold: '<S2>/Zero-Order Hold' */
  if (MotorLazoAbierto_NDr_M->Timing.RateInteraction.TID1_2) {
    MotorLazoAbierto_NDr_B.ZeroOrderHold = MotorLazoAbierto_NDr_B.Posiciondeg;
  }

  /* End of ZeroOrderHold: '<S2>/Zero-Order Hold' */
  /* MATLABSystem: '<S1>/Hall 1' */
  if (MotorLazoAbierto_NDr_DW.obj.SampleTime !=
      MotorLazoAbierto_NDr_P.Hall1_SampleTime) {
    MotorLazoAbierto_NDr_DW.obj.SampleTime =
      MotorLazoAbierto_NDr_P.Hall1_SampleTime;
  }

  MotorLazoAbierto_NDr_B.Hall1 = MW_digitalIO_read
    (MotorLazoAbierto_NDr_DW.obj.MW_DIGITALIO_HANDLE);

  /* End of MATLABSystem: '<S1>/Hall 1' */

  /* MATLABSystem: '<S1>/Hall 2' */
  if (MotorLazoAbierto_NDr_DW.obj_i.SampleTime !=
      MotorLazoAbierto_NDr_P.Hall2_SampleTime) {
    MotorLazoAbierto_NDr_DW.obj_i.SampleTime =
      MotorLazoAbierto_NDr_P.Hall2_SampleTime;
  }

  MotorLazoAbierto_NDr_B.Hall2 = MW_digitalIO_read
    (MotorLazoAbierto_NDr_DW.obj_i.MW_DIGITALIO_HANDLE);

  /* End of MATLABSystem: '<S1>/Hall 2' */

  /* LookupNDDirect: '<S2>/Direct Lookup Table (n-D)' incorporates:
   *  Gain: '<S2>/Gain'
   *  Gain: '<S2>/Gain1'
   *  Gain: '<S2>/Gain2'
   *  Gain: '<S2>/Gain3'
   *  Sum: '<S2>/Sum'
   *  UnitDelay: '<S2>/Unit Delay'
   *  UnitDelay: '<S2>/Unit Delay1'
   *
   * About '<S2>/Direct Lookup Table (n-D)':
   *  1-dimensional Direct Look-Up returning a Scalar,
   */
  rtb_DirectLookupTablenD = (((real_T)(MotorLazoAbierto_NDr_DW.UnitDelay_DSTATE ?
    (int32_T)MotorLazoAbierto_NDr_P.Gain3_Gain : 0) * 0.0625 + (real_T)
    (MotorLazoAbierto_NDr_B.Hall1 ? (int32_T)MotorLazoAbierto_NDr_P.Gain2_Gain :
     0) * 0.03125) + (real_T)(MotorLazoAbierto_NDr_DW.UnitDelay1_DSTATE ?
    (int32_T)MotorLazoAbierto_NDr_P.Gain1_Gain : 0) * 0.015625) + (real_T)
    (MotorLazoAbierto_NDr_B.Hall2 ? (int32_T)MotorLazoAbierto_NDr_P.Gain_Gain :
     0) * 0.0078125;
  if (rtb_DirectLookupTablenD > 15.0) {
    rtb_DirectLookupTablenD = 15.0;
  }

  rtb_DirectLookupTablenD = MotorLazoAbierto_NDr_P.DirectLookupTablenD_table
    [(int32_T)rtb_DirectLookupTablenD];

  /* End of LookupNDDirect: '<S2>/Direct Lookup Table (n-D)' */

  /* Sum: '<S2>/Sum1' */
  rtb_Sum1 = rtb_DirectLookupTablenD + MotorLazoAbierto_NDr_B.Posiciondeg;

  /* Clock: '<S2>/Clock' */
  MotorLazoAbierto_NDr_B.Clock = MotorLazoAbierto_NDr_M->Timing.t[0];

  /* Outputs for Triggered SubSystem: '<S2>/Triggered Subsystem' incorporates:
   *  TriggerPort: '<S3>/Trigger'
   */
  /* Abs: '<S2>/Abs1' */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                     &MotorLazoAbierto_NDr_PrevZCX.TriggeredSubsystem_Trig_ZCE,
                     (fabs(rtb_DirectLookupTablenD)));
  if (zcEvent != NO_ZCEVENT) {
    /* Inport: '<S3>/In1' */
    MotorLazoAbierto_NDr_B.In1 = MotorLazoAbierto_NDr_B.Clock;

    /* Sum: '<S3>/Sum' incorporates:
     *  Memory: '<S3>/Memory'
     */
    rtb_Sum = MotorLazoAbierto_NDr_B.In1 -
      MotorLazoAbierto_NDr_DW.Memory_PreviousInput;

    /* Product: '<S3>/Product2' incorporates:
     *  Constant: '<S5>/Constant'
     *  Memory: '<S3>/Memory1'
     *  Product: '<S3>/Product1'
     *  RelationalOperator: '<S5>/Compare'
     */
    MotorLazoAbierto_NDr_B.Product2 = (real_T)(rtb_DirectLookupTablenD *
      MotorLazoAbierto_NDr_DW.Memory1_PreviousInput >
      MotorLazoAbierto_NDr_P.Constant_Value) * rtb_Sum;

    /* Product: '<S3>/Product' */
    MotorLazoAbierto_NDr_B.Product = rtb_Sum * rtb_DirectLookupTablenD;

    /* Update for Memory: '<S3>/Memory1' */
    MotorLazoAbierto_NDr_DW.Memory1_PreviousInput = rtb_DirectLookupTablenD;

    /* Update for Memory: '<S3>/Memory' */
    MotorLazoAbierto_NDr_DW.Memory_PreviousInput = MotorLazoAbierto_NDr_B.In1;
    MotorLazoAbierto_NDr_DW.TriggeredSubsystem_SubsysRanBC = 4;
  }

  /* End of Outputs for SubSystem: '<S2>/Triggered Subsystem' */

  /* Signum: '<S2>/Sign1' */
  if (MotorLazoAbierto_NDr_B.Product < 0.0) {
    MotorLazoAbierto_NDr_B.Sign1 = -1.0;
  } else if (MotorLazoAbierto_NDr_B.Product > 0.0) {
    MotorLazoAbierto_NDr_B.Sign1 = 1.0;
  } else if (MotorLazoAbierto_NDr_B.Product == 0.0) {
    MotorLazoAbierto_NDr_B.Sign1 = 0.0;
  } else {
    MotorLazoAbierto_NDr_B.Sign1 = (rtNaN);
  }

  /* End of Signum: '<S2>/Sign1' */

  /* Switch: '<S2>/Switch1' incorporates:
   *  Constant: '<S2>/Constant2'
   *  Math: '<S2>/pul//s'
   *
   * About '<S2>/pul//s':
   *  Operator: reciprocal
   */
  if (MotorLazoAbierto_NDr_B.Product2 > MotorLazoAbierto_NDr_P.Switch1_Threshold)
  {
    /* Product: '<S2>/Product' incorporates:
     *  Sum: '<S2>/Sum2'
     */
    rtb_DirectLookupTablenD = (MotorLazoAbierto_NDr_B.Clock -
      MotorLazoAbierto_NDr_B.In1) * MotorLazoAbierto_NDr_B.Sign1;

    /* Switch: '<S2>/Switch' incorporates:
     *  Abs: '<S2>/Abs2'
     *  RelationalOperator: '<S2>/Relational Operator'
     */
    if (fabs(rtb_DirectLookupTablenD) < MotorLazoAbierto_NDr_B.Product2) {
      rtb_DirectLookupTablenD = MotorLazoAbierto_NDr_B.Product;
    }

    /* End of Switch: '<S2>/Switch' */
    MotorLazoAbierto_NDr_B.Switch1 = 1.0 / rtb_DirectLookupTablenD;
  } else {
    MotorLazoAbierto_NDr_B.Switch1 = MotorLazoAbierto_NDr_P.Constant2_Value_p;
  }

  /* End of Switch: '<S2>/Switch1' */
  /* Step: '<Root>/Step' */
  if ((((MotorLazoAbierto_NDr_M->Timing.clockTick1+
         MotorLazoAbierto_NDr_M->Timing.clockTickH1* 4294967296.0)) * 0.0001) <
      MotorLazoAbierto_NDr_P.Step_Time) {
    rtb_DirectLookupTablenD = MotorLazoAbierto_NDr_P.Step_Y0;
  } else {
    rtb_DirectLookupTablenD = MotorLazoAbierto_NDr_P.Step_YFinal;
  }

  /* End of Step: '<Root>/Step' */

  /* MATLABSystem: '<S1>/PWM A//B (paralelo) ' */
  MW_PWM_SetDutyCycle(MotorLazoAbierto_NDr_DW.obj_b.MW_PWM_HANDLE,
                      rtb_DirectLookupTablenD);

  /* MATLABSystem: '<S1>/ENA' incorporates:
   *  Constant: '<S1>/Constant'
   */
  MW_digitalIO_write(MotorLazoAbierto_NDr_DW.obj_p.MW_DIGITALIO_HANDLE,
                     MotorLazoAbierto_NDr_P.Constant_Value_m != 0.0);

  /* MATLABSystem: '<S1>/ENB ' incorporates:
   *  Constant: '<S1>/Constant'
   */
  MW_digitalIO_write(MotorLazoAbierto_NDr_DW.obj_m.MW_DIGITALIO_HANDLE,
                     MotorLazoAbierto_NDr_P.Constant_Value_m != 0.0);

  /* ManualSwitch: '<S1>/Manual Switch' incorporates:
   *  Constant: '<S1>/Constant2'
   *  Constant: '<S1>/Constant3'
   */
  if (MotorLazoAbierto_NDr_P.ManualSwitch_CurrentSetting == 1) {
    rtb_DirectLookupTablenD = MotorLazoAbierto_NDr_P.Constant3_Value;
  } else {
    rtb_DirectLookupTablenD = MotorLazoAbierto_NDr_P.Constant2_Value;
  }

  /* End of ManualSwitch: '<S1>/Manual Switch' */

  /* MATLABSystem: '<S1>/DirA' */
  MW_digitalIO_write(MotorLazoAbierto_NDr_DW.obj_g.MW_DIGITALIO_HANDLE,
                     rtb_DirectLookupTablenD != 0.0);

  /* MATLABSystem: '<S1>/DirB' */
  MW_digitalIO_write(MotorLazoAbierto_NDr_DW.obj_k.MW_DIGITALIO_HANDLE,
                     rtb_DirectLookupTablenD != 0.0);

  /* Update for UnitDelay: '<S2>/Posicion (deg)' */
  MotorLazoAbierto_NDr_DW.Posiciondeg_DSTATE = rtb_Sum1;

  /* Update for UnitDelay: '<S2>/Unit Delay' */
  MotorLazoAbierto_NDr_DW.UnitDelay_DSTATE = MotorLazoAbierto_NDr_B.Hall1;

  /* Update for UnitDelay: '<S2>/Unit Delay1' */
  MotorLazoAbierto_NDr_DW.UnitDelay1_DSTATE = MotorLazoAbierto_NDr_B.Hall2;

  /* External mode */
  rtExtModeUploadCheckTrigger(3);
  rtExtModeUpload(1, (real_T)MotorLazoAbierto_NDr_M->Timing.t[0]);

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.0s, 0.0s] */
    if ((rtmGetTFinal(MotorLazoAbierto_NDr_M)!=-1) &&
        !((rtmGetTFinal(MotorLazoAbierto_NDr_M)-MotorLazoAbierto_NDr_M->
           Timing.t[0]) > MotorLazoAbierto_NDr_M->Timing.t[0] * (DBL_EPSILON)))
    {
      rtmSetErrorStatus(MotorLazoAbierto_NDr_M, "Simulation finished");
    }

    if (rtmGetStopRequested(MotorLazoAbierto_NDr_M)) {
      rtmSetErrorStatus(MotorLazoAbierto_NDr_M, "Simulation finished");
    }
  }

  /* Update absolute time */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++MotorLazoAbierto_NDr_M->Timing.clockTick0)) {
    ++MotorLazoAbierto_NDr_M->Timing.clockTickH0;
  }

  MotorLazoAbierto_NDr_M->Timing.t[0] =
    MotorLazoAbierto_NDr_M->Timing.clockTick0 *
    MotorLazoAbierto_NDr_M->Timing.stepSize0 +
    MotorLazoAbierto_NDr_M->Timing.clockTickH0 *
    MotorLazoAbierto_NDr_M->Timing.stepSize0 * 4294967296.0;

  /* Update absolute time */
  /* The "clockTick1" counts the number of times the code of this task has
   * been executed. The resolution of this integer timer is 0.0001, which is the step size
   * of the task. Size of "clockTick1" ensures timer will not overflow during the
   * application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick1 and the high bits
   * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
   */
  MotorLazoAbierto_NDr_M->Timing.clockTick1++;
  if (!MotorLazoAbierto_NDr_M->Timing.clockTick1) {
    MotorLazoAbierto_NDr_M->Timing.clockTickH1++;
  }
}

/* Model step function for TID2 */
void MotorLazoAbierto_NDr_step2(void)  /* Sample time: [0.01s, 0.0s] */
{
  /* local block i/o variables */
  real_T rtb_TSamp;

  /* SampleTimeMath: '<S4>/TSamp'
   *
   * About '<S4>/TSamp':
   *  y = u * K where K = 1 / ( w * Ts )
   */
  rtb_TSamp = MotorLazoAbierto_NDr_B.ZeroOrderHold *
    MotorLazoAbierto_NDr_P.TSamp_WtEt;

  /* Sum: '<S4>/Diff' incorporates:
   *  UnitDelay: '<S4>/UD'
   */
  MotorLazoAbierto_NDr_B.Diff = rtb_TSamp - MotorLazoAbierto_NDr_DW.UD_DSTATE;

  /* Update for UnitDelay: '<S4>/UD' */
  MotorLazoAbierto_NDr_DW.UD_DSTATE = rtb_TSamp;
  rtExtModeUpload(2, (real_T)(((MotorLazoAbierto_NDr_M->Timing.clockTick2+
    MotorLazoAbierto_NDr_M->Timing.clockTickH2* 4294967296.0)) * 0.01));

  /* Update absolute time */
  /* The "clockTick2" counts the number of times the code of this task has
   * been executed. The resolution of this integer timer is 0.01, which is the step size
   * of the task. Size of "clockTick2" ensures timer will not overflow during the
   * application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick2 and the high bits
   * Timing.clockTickH2. When the low bit overflows to 0, the high bits increment.
   */
  MotorLazoAbierto_NDr_M->Timing.clockTick2++;
  if (!MotorLazoAbierto_NDr_M->Timing.clockTick2) {
    MotorLazoAbierto_NDr_M->Timing.clockTickH2++;
  }
}

/* Model initialize function */
void MotorLazoAbierto_NDr_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)MotorLazoAbierto_NDr_M, 0,
                sizeof(RT_MODEL_MotorLazoAbierto_NDr_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&MotorLazoAbierto_NDr_M->solverInfo,
                          &MotorLazoAbierto_NDr_M->Timing.simTimeStep);
    rtsiSetTPtr(&MotorLazoAbierto_NDr_M->solverInfo, &rtmGetTPtr
                (MotorLazoAbierto_NDr_M));
    rtsiSetStepSizePtr(&MotorLazoAbierto_NDr_M->solverInfo,
                       &MotorLazoAbierto_NDr_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&MotorLazoAbierto_NDr_M->solverInfo,
                          (&rtmGetErrorStatus(MotorLazoAbierto_NDr_M)));
    rtsiSetRTModelPtr(&MotorLazoAbierto_NDr_M->solverInfo,
                      MotorLazoAbierto_NDr_M);
  }

  rtsiSetSimTimeStep(&MotorLazoAbierto_NDr_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetSolverName(&MotorLazoAbierto_NDr_M->solverInfo,"FixedStepDiscrete");
  rtmSetTPtr(MotorLazoAbierto_NDr_M, &MotorLazoAbierto_NDr_M->Timing.tArray[0]);
  rtmSetTFinal(MotorLazoAbierto_NDr_M, 40.0);
  MotorLazoAbierto_NDr_M->Timing.stepSize0 = 0.0001;

  /* External mode info */
  MotorLazoAbierto_NDr_M->Sizes.checksums[0] = (2728648932U);
  MotorLazoAbierto_NDr_M->Sizes.checksums[1] = (2816888231U);
  MotorLazoAbierto_NDr_M->Sizes.checksums[2] = (3231859524U);
  MotorLazoAbierto_NDr_M->Sizes.checksums[3] = (3482691424U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[12];
    MotorLazoAbierto_NDr_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = &rtAlwaysEnabled;
    systemRan[3] = &rtAlwaysEnabled;
    systemRan[4] = &rtAlwaysEnabled;
    systemRan[5] = &rtAlwaysEnabled;
    systemRan[6] = &rtAlwaysEnabled;
    systemRan[7] = &rtAlwaysEnabled;
    systemRan[8] = &rtAlwaysEnabled;
    systemRan[9] = &rtAlwaysEnabled;
    systemRan[10] = &rtAlwaysEnabled;
    systemRan[11] = (sysRanDType *)
      &MotorLazoAbierto_NDr_DW.TriggeredSubsystem_SubsysRanBC;
    rteiSetModelMappingInfoPtr(MotorLazoAbierto_NDr_M->extModeInfo,
      &MotorLazoAbierto_NDr_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(MotorLazoAbierto_NDr_M->extModeInfo,
                        MotorLazoAbierto_NDr_M->Sizes.checksums);
    rteiSetTPtr(MotorLazoAbierto_NDr_M->extModeInfo, rtmGetTPtr
                (MotorLazoAbierto_NDr_M));
  }

  /* block I/O */
  (void) memset(((void *) &MotorLazoAbierto_NDr_B), 0,
                sizeof(B_MotorLazoAbierto_NDr_T));

  /* states (dwork) */
  (void) memset((void *)&MotorLazoAbierto_NDr_DW, 0,
                sizeof(DW_MotorLazoAbierto_NDr_T));

  {
    mbed_DigitalRead_MotorLazoAbi_T *obj;
    uint32_T pinname;
    mbed_PWMOutput_MotorLazoAbier_T *obj_0;
    mbed_DigitalWrite_MotorLazoAb_T *obj_1;

    /* Start for MATLABSystem: '<S1>/Hall 1' */
    MotorLazoAbierto_NDr_DW.obj.matlabCodegenIsDeleted = true;
    MotorLazoAbierto_NDr_DW.obj.isInitialized = 0;
    MotorLazoAbierto_NDr_DW.obj.SampleTime = -1.0;
    MotorLazoAbierto_NDr_DW.obj.matlabCodegenIsDeleted = false;
    MotorLazoAbierto_NDr_DW.objisempty = true;
    MotorLazoAbierto_NDr_DW.obj.SampleTime =
      MotorLazoAbierto_NDr_P.Hall1_SampleTime;
    obj = &MotorLazoAbierto_NDr_DW.obj;
    MotorLazoAbierto_NDr_DW.obj.isSetupComplete = false;
    MotorLazoAbierto_NDr_DW.obj.isInitialized = 1;
    pinname = D13;
    obj->MW_DIGITALIO_HANDLE = MW_digitalIO_open(pinname, 0);
    MotorLazoAbierto_NDr_DW.obj.isSetupComplete = true;

    /* Start for MATLABSystem: '<S1>/Hall 2' */
    MotorLazoAbierto_NDr_DW.obj_i.matlabCodegenIsDeleted = true;
    MotorLazoAbierto_NDr_DW.obj_i.isInitialized = 0;
    MotorLazoAbierto_NDr_DW.obj_i.SampleTime = -1.0;
    MotorLazoAbierto_NDr_DW.obj_i.matlabCodegenIsDeleted = false;
    MotorLazoAbierto_NDr_DW.objisempty_h = true;
    MotorLazoAbierto_NDr_DW.obj_i.SampleTime =
      MotorLazoAbierto_NDr_P.Hall2_SampleTime;
    obj = &MotorLazoAbierto_NDr_DW.obj_i;
    MotorLazoAbierto_NDr_DW.obj_i.isSetupComplete = false;
    MotorLazoAbierto_NDr_DW.obj_i.isInitialized = 1;
    pinname = D12;
    obj->MW_DIGITALIO_HANDLE = MW_digitalIO_open(pinname, 0);
    MotorLazoAbierto_NDr_DW.obj_i.isSetupComplete = true;

    /* Start for MATLABSystem: '<S1>/PWM A//B (paralelo) ' */
    MotorLazoAbierto_NDr_DW.obj_b.matlabCodegenIsDeleted = true;
    MotorLazoAbierto_NDr_DW.obj_b.isInitialized = 0;
    MotorLazoAbierto_NDr_DW.obj_b.matlabCodegenIsDeleted = false;
    MotorLazoAbierto_NDr_DW.objisempty_hs = true;
    obj_0 = &MotorLazoAbierto_NDr_DW.obj_b;
    MotorLazoAbierto_NDr_DW.obj_b.isSetupComplete = false;
    MotorLazoAbierto_NDr_DW.obj_b.isInitialized = 1;
    pinname = D5;
    obj_0->MW_PWM_HANDLE = MW_PWM_Open(pinname, 5000.0, 50.0);
    MW_PWM_Start(MotorLazoAbierto_NDr_DW.obj_b.MW_PWM_HANDLE);
    MotorLazoAbierto_NDr_DW.obj_b.isSetupComplete = true;

    /* Start for MATLABSystem: '<S1>/ENA' */
    MotorLazoAbierto_NDr_DW.obj_p.matlabCodegenIsDeleted = true;
    MotorLazoAbierto_NDr_DW.obj_p.isInitialized = 0;
    MotorLazoAbierto_NDr_DW.obj_p.matlabCodegenIsDeleted = false;
    MotorLazoAbierto_NDr_DW.objisempty_k = true;
    obj_1 = &MotorLazoAbierto_NDr_DW.obj_p;
    MotorLazoAbierto_NDr_DW.obj_p.isSetupComplete = false;
    MotorLazoAbierto_NDr_DW.obj_p.isInitialized = 1;
    pinname = D2;
    obj_1->MW_DIGITALIO_HANDLE = MW_digitalIO_open(pinname, 1);
    MotorLazoAbierto_NDr_DW.obj_p.isSetupComplete = true;

    /* Start for MATLABSystem: '<S1>/ENB ' */
    MotorLazoAbierto_NDr_DW.obj_m.matlabCodegenIsDeleted = true;
    MotorLazoAbierto_NDr_DW.obj_m.isInitialized = 0;
    MotorLazoAbierto_NDr_DW.obj_m.matlabCodegenIsDeleted = false;
    MotorLazoAbierto_NDr_DW.objisempty_j = true;
    obj_1 = &MotorLazoAbierto_NDr_DW.obj_m;
    MotorLazoAbierto_NDr_DW.obj_m.isSetupComplete = false;
    MotorLazoAbierto_NDr_DW.obj_m.isInitialized = 1;
    pinname = D11;
    obj_1->MW_DIGITALIO_HANDLE = MW_digitalIO_open(pinname, 1);
    MotorLazoAbierto_NDr_DW.obj_m.isSetupComplete = true;

    /* Start for MATLABSystem: '<S1>/DirA' */
    MotorLazoAbierto_NDr_DW.obj_g.matlabCodegenIsDeleted = true;
    MotorLazoAbierto_NDr_DW.obj_g.isInitialized = 0;
    MotorLazoAbierto_NDr_DW.obj_g.matlabCodegenIsDeleted = false;
    MotorLazoAbierto_NDr_DW.objisempty_n = true;
    obj_1 = &MotorLazoAbierto_NDr_DW.obj_g;
    MotorLazoAbierto_NDr_DW.obj_g.isSetupComplete = false;
    MotorLazoAbierto_NDr_DW.obj_g.isInitialized = 1;
    pinname = D3;
    obj_1->MW_DIGITALIO_HANDLE = MW_digitalIO_open(pinname, 1);
    MotorLazoAbierto_NDr_DW.obj_g.isSetupComplete = true;

    /* Start for MATLABSystem: '<S1>/DirB' */
    MotorLazoAbierto_NDr_DW.obj_k.matlabCodegenIsDeleted = true;
    MotorLazoAbierto_NDr_DW.obj_k.isInitialized = 0;
    MotorLazoAbierto_NDr_DW.obj_k.matlabCodegenIsDeleted = false;
    MotorLazoAbierto_NDr_DW.objisempty_a = true;
    obj_1 = &MotorLazoAbierto_NDr_DW.obj_k;
    MotorLazoAbierto_NDr_DW.obj_k.isSetupComplete = false;
    MotorLazoAbierto_NDr_DW.obj_k.isInitialized = 1;
    pinname = D7;
    obj_1->MW_DIGITALIO_HANDLE = MW_digitalIO_open(pinname, 1);
    MotorLazoAbierto_NDr_DW.obj_k.isSetupComplete = true;
  }

  MotorLazoAbierto_NDr_PrevZCX.TriggeredSubsystem_Trig_ZCE = UNINITIALIZED_ZCSIG;

  /* InitializeConditions for UnitDelay: '<S2>/Posicion (deg)' */
  MotorLazoAbierto_NDr_DW.Posiciondeg_DSTATE =
    MotorLazoAbierto_NDr_P.Posiciondeg_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S4>/UD' */
  MotorLazoAbierto_NDr_DW.UD_DSTATE =
    MotorLazoAbierto_NDr_P.Velocidaddegs_ICPrevScaledInput;

  /* InitializeConditions for UnitDelay: '<S2>/Unit Delay' */
  MotorLazoAbierto_NDr_DW.UnitDelay_DSTATE =
    MotorLazoAbierto_NDr_P.UnitDelay_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S2>/Unit Delay1' */
  MotorLazoAbierto_NDr_DW.UnitDelay1_DSTATE =
    MotorLazoAbierto_NDr_P.UnitDelay1_InitialCondition;

  /* SystemInitialize for Triggered SubSystem: '<S2>/Triggered Subsystem' */
  /* InitializeConditions for Memory: '<S3>/Memory1' */
  MotorLazoAbierto_NDr_DW.Memory1_PreviousInput =
    MotorLazoAbierto_NDr_P.Memory1_InitialCondition;

  /* InitializeConditions for Memory: '<S3>/Memory' */
  MotorLazoAbierto_NDr_DW.Memory_PreviousInput =
    MotorLazoAbierto_NDr_P.Memory_InitialCondition;

  /* SystemInitialize for Outport: '<S3>/T*sing ' */
  MotorLazoAbierto_NDr_B.Product = MotorLazoAbierto_NDr_P.Tsing_Y0;

  /* SystemInitialize for Outport: '<S3>/dT ultimo p ' */
  MotorLazoAbierto_NDr_B.Product2 = MotorLazoAbierto_NDr_P.dTultimop_Y0;

  /* SystemInitialize for Outport: '<S3>/T actual' */
  MotorLazoAbierto_NDr_B.In1 = MotorLazoAbierto_NDr_P.Tactual_Y0;

  /* End of SystemInitialize for SubSystem: '<S2>/Triggered Subsystem' */
}

/* Model terminate function */
void MotorLazoAbierto_NDr_terminate(void)
{
  /* Terminate for MATLABSystem: '<S1>/Hall 1' */
  matlabCodegenHandle_matla_a0jjz(&MotorLazoAbierto_NDr_DW.obj);

  /* Terminate for MATLABSystem: '<S1>/Hall 2' */
  matlabCodegenHandle_matla_a0jjz(&MotorLazoAbierto_NDr_DW.obj_i);

  /* Terminate for MATLABSystem: '<S1>/PWM A//B (paralelo) ' */
  matlabCodegenHandle_matlab_a0jj(&MotorLazoAbierto_NDr_DW.obj_b);

  /* Terminate for MATLABSystem: '<S1>/ENA' */
  matlabCodegenHandle_matlabCodeg(&MotorLazoAbierto_NDr_DW.obj_p);

  /* Terminate for MATLABSystem: '<S1>/ENB ' */
  matlabCodegenHandle_matlabCodeg(&MotorLazoAbierto_NDr_DW.obj_m);

  /* Terminate for MATLABSystem: '<S1>/DirA' */
  matlabCodegenHandle_matlabCodeg(&MotorLazoAbierto_NDr_DW.obj_g);

  /* Terminate for MATLABSystem: '<S1>/DirB' */
  matlabCodegenHandle_matlabCodeg(&MotorLazoAbierto_NDr_DW.obj_k);
}
