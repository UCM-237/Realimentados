clear all
close all
%script para resolver los ejercicios uno y dos
mu = 1 %coeficiente de rozamiento 
k=3 %constante de los resortes

%x1 desplazazamiento bloque 1 bloque 1
%x2 desplazamiento  bloque 2
%x3 velocidad bloque 1
%x4 velocidad bloque 2
 
A=[0 0 1 0
   0 0 0 1
   -2*k k -mu 0
   k -2*k 0 -mu]
B=[0 0 1 0]'
C = [0 1 0 0]
%Controlabilidad
co =ctrb(A,B)
rco=rank(co)
%observabilidad
ob = obsv(A,C)
%% 
rob=rank(ob)


%polos en lazo abierto
[avec,lambda]=eig(A)
%Consideramos unas condiciones iniciales arbitrarias pero compatibles con
%el sistema,
x0 = [-0.5,0.7,0.2,0.3]
u = 0
tf = 15
sys = @(t,x)bloques(t,x,A,B,u,x0)
[t,x] = ode45(sys,[0,tf],x0);
plot(t,x+kron(ones(size(x,1),1),[1 2 0 0]))

%Los polos del sistema original son complejos conjugados
k = acker(A,B,[-2 -2 -5 -5])
%construimos el sistema realimentado
Ac = A-B*k
x0 = [-0.5,0.7,0.2,0.3]
u = 0
tf = 15
sys = @(t,x)bloques(t,x,Ac,B,u,x0)
[t,x] = ode45(sys,[0,tf],x0);
hold on
plot(t,x+kron(ones(size(x,1),1),[1 2 0 0]))

%vamos a añadir control integral
%en primer intentamos ver si es posible controlar los dos bloques
C2 = [1 0 0 0; 0 1 0 0]

Aamp = [A zeros(4,2)
        C2 zeros(2)]
Bamp = [B; 0; 0]
Cint = C2; zeros(2,4)
%analizamos controlabilidad del ampliado
rcoI = rank(ctrb(Aamp,Bamp))

% recalculamos ahora la posición de los polos añadiendo 1 a la izquierda de
% los anteriores pero conservando la posición de los que ya tenemos
kamp = acker(Aamp,Bamp,[-1 -1 -2 -2 -10])

%recosntruimos el sistema
A_int = [A-B*kamp(1:4)  -B*kamp(5)
         C                0]
B_int = [B*F;-1] %suponemos feedforward unitario
C_int = Camp
D = 0
sys_int =ss(A_int,B_int,C_int,D)
%figure()
[yi,ti,xi]=step(sys_int,10);
subplot(2,1,1)
hold on
plot(ti,xi(:,1:2))
subplot(2,1,2)
hold on
plot(ti,xi(:,3:4))

%estimador de estados
%debemos calcular ahora unos polos para el observador
L = acker(A',C',[-5 -5 -6 -6])'
%reconstruimos el sistema incluyendo el observador. Incluimos ya todos los
%valores calculado en las secciones anteriores. El principio de separación
%hace que no tengamos que recalcular nada más
A_obs = [A, -B*kamp(1:4), -B*kamp(5)
         L*C, A-B*kamp(1:4)-L*C,-B*kamp(5)
         C, zeros(1,5)]
F = 0 %ojo estoy quitando aqui la accione feedforward         
B_obs = [B*F;B*F;-1]
C_obs = [C zeros(1,5)]
sys_obs = ss(A_obs,B_obs,C_obs,D)
%Uso lsim para combinar escalon con condiciones iniciales
t=0:0.01:15;
step = ones(length(t),1);
[y,t,x]=lsim(sys_obs,step,t,[0.5,-1,0,0,0,0,0,0,0]);
figure()
subplot(2,1,1)
hold on
plot(t,x(:,[1 2 5 6]))
subplot(2,1,2)
hold on
plot(t,x(:,[3 4 7 8]))

function dotx = bloques(t,x,A,B,u,x0)
dotx = A*x+ B*u;
end
%Para dibujar los bloques, no es parte del examen
%pongo arbitrariamente la posición de reposo de los bloques en 2 y 5
% x1 = x(:,1)+3
% x2 = x(:,2)+6
% figure()
% for i = 1:length(x1)kron(ones(1,size(x,2)),[1,2,0,0])
%     plot(linspace(0,x1(i),30),0.025*ones(1,30),'.k')
%     hold on
%     plot(linspace(x1(i),x2(i),30),0.025*ones(1,30),'.k')
%     plot(linspace(x2(i),9,30),0.025*ones(1,30),'.k')
%     rectangle('position',[x1(i)-0.3 0 0.6 0.05],'FaceColor','b')
%     rectangle('position',[x2(i)-0.3 0 0.6 0.05],'FaceColor','r')
%     axis([0 9 0 0.5])
%     drawnow
%     hold off
% end
